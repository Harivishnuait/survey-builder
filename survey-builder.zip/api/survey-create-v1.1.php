<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

///////////////////////////////////////////////////////// Prep
include "_includes.php";

$out = new DataPacket();

$auth = new Auth();

$auth->fromSession($conn);

$dataOut = new stdClass();

///////////////////////////////////////////////////////// Prep

$debug = "Y";

$survey = new Survey();
$survey->debug = $debug;

$params = $_POST["survey-params"];

//print "RAW PARAMS:";
//print_r($params);

//$params = json_decode_nice($params);
$params = json_decode($params);

//print "LOADED PARAMS";
//print_r($params);
//die("HERE");


$survey->createSurvey($conn, $auth, $params);

$dataOut->survey = $survey->getSurveyDataObj();

///////////////////////////////////////////////////////// Send Data

$out->data = $dataOut;

header('Content-type: application/json');

echo $out->generateOutput($auth);

/////////////////////////////////////////////////////////

function json_decode_nice($json, $assoc = TRUE){
    $json = str_replace("\n","\\n",$json);
    $json = str_replace("\r","",$json);
    $json = preg_replace('/([{,]+)(\s*)([^"]+?)\s*:/','$1"$3":',$json);
    $json = preg_replace('/(,)\s*}$/','}',$json);
    return json_decode($json,$assoc);
}
?>