<?php
session_start(); 

$data = json_decode(file_get_contents("php://input"), true);

$userID = $data['userID'];
$roleID = $data['roleID'];

$response = [];

if ($roleID == 1) {
    $_SESSION['userID'] = $userID;

    $response = array();
    $response['message'] = 'Successfully logged in as Super Admin.';
    $response['redirect'] = '/survey-builder/super-admin/admin-dashboard.php';
} else {
    $response['message'] = 'Successfully logged in as Client.';
    $response['redirect'] = '/survey-builder/client/index.html';    
}

echo json_encode($response);
exit;
?>
