<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

///////////////////////////////////////////////////////// Prep
include "_includes.php";

$out = new DataPacket();

$auth = new Auth();

$auth->fromSession($conn);

$dataOut = new stdClass();

///////////////////////////////////////////////////////// Prep

$survey = new Survey();
$survey->setAuth($auth);
$survey->debug = $debug;

$params = new stdClass();
$params->surveyName = clean($conn, getVar("surveyName"));
$params->researchGoals = clean($conn, getVar("researchGoals"));
$params->surveyType = clean($conn, getVar("surveyType"));

if($debug == "Y")
{
    debug("Debugging is on");
    debug("SurveyName: $params->surveyName");
    debug("researchGoals: $params->researchGoals");
    debug("surveyType: $params->surveyType");

}

$survey->createSurvey($conn, $auth, $params);

if($debug == "Y") debug("Saving Survey to Session");

$_SESSION["lastSurveyID"] = $survey->surveyID;

$dataOut->survey = $survey->getSurveyDataObj();

///////////////////////////////////////////////////////// Send Data

$out->data = $dataOut;

header('Content-type: application/json');

echo $out->generateOutput($auth);

/////////////////////////////////////////////////////////

function json_decode_nice($json, $assoc = TRUE){
    $json = str_replace("\n","\\n",$json);
    $json = str_replace("\r","",$json);
    $json = preg_replace('/([{,]+)(\s*)([^"]+?)\s*:/','$1"$3":',$json);
    $json = preg_replace('/(,)\s*}$/','}',$json);
    return json_decode($json,$assoc);
}
?>