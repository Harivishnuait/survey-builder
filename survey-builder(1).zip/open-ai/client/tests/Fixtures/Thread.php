<?php

/**
 * @return array<string, mixed>
 */
function threadResource(): array
{
    return [
        'id' => 'thread_agvtHUGezjTCt4SKgQg0NJ2Y',
        'object' => 'thread',
        'created_at' => 1699621778,
        'tool_resources' => [],
        'metadata' => [],
    ];
}

/**
 * @return array<string, mixed>
 */
function threadDeleteResource(): array
{
    return [
        'id' => 'thread_agvtHUGezjTCt4SKgQg0NJ2Y',
        'object' => 'thread.deleted',
        'deleted' => true,
    ];
}
