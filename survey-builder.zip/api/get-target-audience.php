<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

///////////////////////////////////////////////////////// Prep
include "_includes.php";

$out = new DataPacket();

$auth = new Auth();

$auth->fromSession($conn);

$dataOut = new stdClass();

///////////////////////////////////////////////////////// Prep
$params = new stdClass();

$surveyID = clean($conn, getVar("surveyID"));
$params->numQuestions = clean($conn, getVar("numQuestions"));
$params->targetAudienceDesc = clean($conn, getVar("targetAudienceDesc"));

if($surveyID <= 0) $surveyID = $_SESSION["lastSurveyID"];


if($debug == "Y") 
{
    debug("Gen Screener Section");
    debug("surveyID = $surveyID");
    debug("numQuestions = $params->numQuestions");
    debug("targetAudienceDesc = " . $params->targetAudienceDesc);
}

$survey = new Survey();
$survey->debug = $debug;
$survey->setConn($conn);
$survey->setAuth($auth);
$survey->loadFromDatabase($conn, $surveyID);


$dataOut = $survey->genScreenSection($params);


///////////////////////////////////////////////////////// Send Data

$out->data = $dataOut;

header('Content-type: application/json');

echo $out->generateOutput($auth);

/////////////////////////////////////////////////////////


?>