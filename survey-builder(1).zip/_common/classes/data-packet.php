<?php
class DataPacket
{
    public $errorID = 0;
    public $errorMsg = "";
    public $userAlerts = [];
    public $debug = [];
    public $auth = "";
    public $data = "";
    public $growlMsg="";
    
    function __construct() 
    {
        $this->data = new stdClass();
        $this->auth = new stdClass();
        $this->auth->userID = -1;
        $this->auth->userGuid = "xxx";
    }    

    function addAuth($conn, $userID) 
    {
        $sql = "select * from mb_user where userID = $userID";

        $u = getDataObject($conn, $sql);
        $this->auth = new stdClass();
        $this->auth->userID = $u->userID;
        $this->auth->userGuid = $u->userGuid;
    }


    public function log($msg)
    {
        array_push($this->debug, $msg);
    }

    public function logError($msg)
    {
        $this->errorID = 14;
        $this->errorMsg = $msg;
    }

    public function logUserAlert($msg)
    {
        array_push($this->userAlerts, $msg);
    }

    public function logUserAlertAndError($msg)
    {
        $this->logUserAlert($msg);
        $this->logError($msg);
    }



    public function hadError() 
    {
        return $this->errorID > 0;
    }

    public function merge($out)
    {

        $this->debug = array_merge($this->debug, $out->debug);
        $this->userAlerts = array_merge($this->userAlerts, $out->userAlerts);

        if($this->errorID == 0)
        {
            $this->errorID  = $out->errorID;
            $this->errorMsg = $out->errorMsg;
        }

    }

    public function addGrowl($msg)
    {
        $this->growlMsg = $msg;
    }


    public function generateOutput($auth)
    {
        $out = new stdClass();

        $out->error = new stdClass();
        $out->error->errorID = 0;
        $out->error->errorMsg = "";

        if($this->errorID <= 0)
        {
            if(isset($this->data->error) && $this->data->error != "")
            {
                $out->error->errorID = 1;
                $out->error->errorMsg = $this->data->error;
            }
        }
        else
        {
            $out->error->errorID = $this->errorID;
            
            $out->error->errorMsg = $this->errorMsg;
        }

        $out->hadError = "";

        if($out->error->errorID > 0)
        {
            $out->hadError = "Y";
        }

        $out->auth = $auth->getCreds();

        $out->data = $this->data;
    
        $out->debug = $this->debug;
        
        $out->userAlerts = $this->userAlerts;

        $out->growl = $this->growlMsg;

        $out->debug = new stdClass();

        return json_encode($out);
    }
}
?>