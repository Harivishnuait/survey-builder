
// $(document).ready(function () {

// $('#companiesTable').DataTable({
//     "paging": false,
//     "searching": false,
//     "ordering": false,
//    "lengthChange": false,
//    "pageLength": 10
// });
// });
    $(document).ready(function () {
        $(".edit-btn").click(function () {
            const company = $(this).data();
            $('#company-id').val(company.id);
            $('#company-name').val(company.name);
            $('#company-email').val(company.email);
            $('#company-project_folder').val(company.project_folder);
            $('#company-type').val(company.type);
            $('#company-domain').val(company.domain);
            $('#company-org_size').val(company.org_size);
            $('#modalTitle').text('Edit Company');
            $('#submitBtn').text('Update');
            $('#addCompanyModal1').modal('show');

        }); 


        
        $("#companyForm_add").submit(function (e) {
e.preventDefault();

const formData = $(this).serialize();

$.post("company-actions.php", formData + "&action=create" , function (response) {
    if (response.success) {
        toastr.success(response.message, "Success");
        setTimeout(function () {
            location.reload();
        }, 2000);
    } else {
        // toastr.error("This email is already registered.", "Note");
const emailInput = document.getElementById('company-email');
const errorMessage = document.getElementById('email-error');

errorMessage.style.display = "block";  
errorMessage.innerHTML = "This email is already registered."; 

emailInput.style.borderColor = "red";

emailInput.focus();
    }
}, "json");
});


        $("#companyForm1").submit(function (e) {
e.preventDefault();

const formData = $(this).serialize();
const action = $('#company-id').val() ? 'edit' : 'create';

$.post("company-actions.php", formData + "&action=" + action, function (response) {
    if (response.success) {
        toastr.success(response.message, "Success");
        setTimeout(function () {
            location.reload();
        }, 2000);
    } else {
        toastr.error(response.message, "Error");
        
    }
}, "json");
}); 


$("#change_status").submit(function (e) {
e.preventDefault();

const formData = $(this).serialize();
const action = $('#company-id').val() ? 'edit' : 'create';

$.post("company-actions.php", formData + "&action=" + action, function (response) {
    if (response.success) {
        toastr.success(response.message, "Success");
        setTimeout(function () {
            location.reload();
        }, 2000);
    } else {
        toastr.error(response.message, "Error");
        
    }
}, "json");
});
   
        $("#deleteCompanyForm").submit(function (e) {
            e.preventDefault();
            const id = $("#delete-id").val();
            $.post("company-actions.php", { id: id, action: 'delete' }, function (response) {
                if (response.success) {
                    toastr.success(response.message, "Success");
                    setTimeout(function () {
            location.reload();
        });
                } else {
        toastr.error(response.message, "Error");
    }
            }, "json");
        });
    });
var user = {
        logout: function (redirectUrl) {

            sessionStorage.removeItem('userSession');
            localStorage.removeItem('userSession');
            window.location.href = redirectUrl;
        }
    };


function closemodel() {
    $("#addCompanyModal").modal("hide");
    $("#addCompanyModal1").modal("hide");
    $("#deleteCompanyModal").modal("hide");
}

document.addEventListener("DOMContentLoaded", function () {
let username = document.getElementById("lbl-username").innerText.trim();
if (username) {
    document.getElementById("profile-circle").innerText = username.charAt(0);
}
});

