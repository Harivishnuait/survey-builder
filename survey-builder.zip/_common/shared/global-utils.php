<?php

function getExtension($fileInfo)
{
	$Filename = $fileInfo->GetFilename();
	$FileExtension = strrpos($Filename, ".", 1) + 1;
	if ($FileExtension != false)
		return strtolower(substr($Filename, $FileExtension, strlen($Filename) - $FileExtension));
	else
		return "";
}

function saveMetric($conn, $dateID, $timeID, $name, $val)
{
	$sql = "delete from pat_etl_metric where dateID= $dateID and timeID = $timeID and metricName = '$name'";
	//print $sql;
	executeQuery($conn, $sql);

	$sql = "insert into pat_etl_metric (dateID, timeID, metricName, metricVal) values ($dateID, $timeID, '$name','$val')";
	executeQuery($conn, $sql);
}


function callAPI($method, $url, $params)
{
    $opts = array('http' =>
      array(
          'method'  => $method,
          'header'  => 'Content-type: application/x-www-form-urlencoded',

      )
    );
  
    $opts['http']['content'] = http_build_query($params);
    $context  = stream_context_create($opts);
	$response = file_get_contents($url, false, $context);
	//logIt("----------------------API Details----------------------");logIt("callAPI:CONTEXT"); print_r($context);logIt("callApi:RESPONSE"); print_r($response);logIt("----------------------API Details----------------------");

    return $response;
}

function getPriorDateID($conn, $currDateID, $numDays)
{
   $sql = "select min(dateID) as numDBDays from (select dateID from dim_date where dateID < $currDateID and isTradeDay = 'Y' order by dateID desc limit $numDays) as a";
   
   $dateID = getKey($conn, $sql);
   
   return $dateID;
}

function getFutureDateID($conn, $currDateID, $numDays)
{
   $sql = "select max(dateID) as numDBDays from (select dateID from dim_date where dateID > $currDateID and isTradeDay = 'Y' order by dateID limit $numDays) as a";
   
   $dateID = getKey($conn, $sql);
   
   return $dateID;
}




?>