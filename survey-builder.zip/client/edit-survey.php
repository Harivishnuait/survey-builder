
<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- CSRF Token -->
  <meta name="csrf-token" content="4VMbuedn0WNMiqVpYXjtBqfFJi5copR6ChWxKW3c">
  <title>Surveys and Beyond</title>
  
  <link href="./css/loader.css" rel="stylesheet">  
  <link href="./css/app.css" rel="stylesheet">

  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css">
  <link rel="stylesheet" href="./css/adminlte.min.css">
  <link rel="stylesheet" href="./css/customstyle.css">
  <link rel="stylesheet" href="./css/responsive-style.css">
  <link rel="stylesheet" href="./css/icheck-bootstrap.min.css">
  <link rel="stylesheet" href="./css/base-style.css">
  <link rel="stylesheet" href="./css/popup-menu.css">
  <link rel="stylesheet"href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css">

  <script src="./js/jquery.min.js"></script>
  <script src="./js/adminlte.min.js"></script>
  <script src="./js/app.js"></script>
  <script src="./js/bootstrap.bundle.min.js"></script>
  
  <script src="https://unpkg.com/xlsx/dist/xlsx.full.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.68/pdfmake.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.68/vfs_fonts.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/PapaParse/5.4.0/papaparse.min.js"></script>
  <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>

</head>

<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
  <div class="wrapper">

    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
      </ul>

      <!-- Right navbar links -->
      <ul class="navbar-nav ml-auto">

        <li class="nav-item user-settings dropdown show">
          <a class="nav-link" data-toggle="dropdown" href="#" aria-expanded="true">
            <div class="user-panel d-flex">
              <div class="image">
                <img src="./img/gear-settings.svg" class="img-circle" alt="User Image">
              </div>
              <div class="info">
                <p class="d-block" id="lbl-username">user</p>
              </div>
            </div>
          </a>

          <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right" style="left: inherit; right: 0px;">
            <span class="dropdown-item dropdown-header">User Settings</span>
            <div class="dropdown-divider"></div>
            <a href="javascript:alert('Coming Soon');void(0);" class="dropdown-item">
              <i class="fas fa-user mr-2"></i> Account
            </a>
            <a href="javascript:user.logout('login.html');void(0);" class="dropdown-item">
              <i class="fas fa-toggle-on mr-2"></i> Logout
            </a>
            <a href="javascript:alert('Coming Soon');void(0);" class="dropdown-item">
              <i class="fas fa-question mr-2"></i> Help
            </a>
            <a href="javascript:alert('Coming Soon');void(0);" class="dropdown-item">
              <i class="fas fa-address-book mr-2"></i> Contact Us
            </a>
          </div>
        </li>

      </ul>
    </nav>
      <!-- /.navbar -->    
      
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
      <!-- Brand Logo -->
      <a href="index.html" class="brand-link">
        <img src="./img/perficient.png" alt="Perficent" class="brand-image" style="opacity: .8">
        
      </a>

      <!-- Sidebar -->
      <div class="sidebar">
        
        <!-- Sidebar Menu -->
        <nav class="mt-2">
          <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
            <!-- Add icons to the links using the .nav-icon class
                  with font-awesome or any other icon font library -->
            <li class="nav-item menu-open">
              
              <ul class="nav nav-treeview" id="side-menu-nav">
                <li class="nav-item">
                  <a href="index.html" class="nav-link active">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Home</p>
                  </a>
                </li>

                <li class="nav-item">
                  <a href="index.html" class="nav-link active">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Your Surveys</p>
                  </a>
                </li>   

                <li class="nav-item">
                  <a href="javascript: surveyApp.newSurvey();void(0);" class="nav-link active">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Create Survey</p>
                  </a>
                </li>   

              </ul>


              <ul class="nav nav-treeview" id="section-table-of-contents">
                
              </ul>
            </li>
            
          </ul>
        </nav>
        <!-- /.sidebar-menu -->

        <!-- Main Footer -->
    <footer class="side-main-footer">
      <!-- To the right -->
      <div class="float-right d-none d-sm-inline">
        <p>Surveys Made Simple</span></p>
        <p><a href="tos.html" target=_new>Terms of Service</a></span></p>
        <p><a href="privacy-statement.html" target=_new>Privacy Statement</a></span></p>

      </div>
      <!-- Default to the left -->
      <span class="copy-sec">
      <strong>Copyright &copy; <span id="currentYear"></span> <a href="#">Perficient Insights LLC</a></strong> All rights reserved.
      </span>
    </footer>
      </div>
      
      <!-- /.sidebar -->
    </aside>    

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper survey-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
          <div class="container-fluid">
            <div class="row">
              <div class="col-6">
                <h1 class="m-0">Home</h1>
              </div><!-- /.col -->
              <div class="col-6 d-flex align-items-center justify-content-end">
                <ol class="breadcrumb float-sm-right">
                  <li class="breadcrumb-item active"><a href="index.html">Home</a></li>
                </ol>
              </div><!-- /.col -->
            </div><!-- /.row -->
          </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <div class="content">
          <div class="container-fluid">
            <div class="row">
              <div class="col-lg-12">
                






              <!---------------------------------------------------loader----------------------------------------------------->

              <div class="view" id="view-spanner" style="text-align: center;">
                  <span class="loader"></span>
                  <br><span id="loader-text">We're putting the survey together, this might take a min...</span>
                </div>

              <!------------------------------------------------------------------------------------------------------------->

              

              <!------------------------------------------------- New Survey ------------------------------------------------------>

              
                <div class="card view"  id="view-edit-research-goals" >


                  <div class="">
                    <div class="card col-lg-12">
                      <div class="card-body">
                        <h4 class="card-title">Survey Name</h4>
                        <input class="form-control" 
                              type="text" 
                              id="survey-name" 
                              value="" 
                              required="" placeholder="Enter Survey Name">
                        
                        <div id="survey_name-error" class="survey_name-error" >Survey Name required</div>
                      </div>
                    </div>
                  </div>




                    <div class="">
                      <div class="card">
                        <div class="card-body">
                          <h4 class="card-title mb-2">Research Goals</h4>
                          <textarea class="form-control resize-none"  
                                    id="research-goals" 
                                    placeholder="Research goals are the intended outcomes of a research project. They should be specific, clear, and achievable. Ex. To examine the casual relationship between un-healthy eating and the development of diabetes "
                                    ></textarea>
                          <span class="research-goals-error" id="research-goals-error">
                                        Research goal is required
                          </span>
                        </div>
                      </div>
                    </div>



                    <div class="">
                  
                      <div class="card">
                        <div class="card-body">
                          <h4 class="card-title">Survey Type</h4>
                          <br>&nbsp;<br>
                          <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="survey-type" id="survey-type" value="qualitative" checked>
                            <label class="form-check-label" for="perform-type-option1">
                              Qualitative Research
                            </label>
                        </div>

                        <div style="padding-left:25px;font-size:11px;color:#333;">
                          Method of collecting and analyzing non-numerical data (text, video, or audio) to understand concepts, opinions, or experiences). It focuses on obtaining data through open-ended and conversational communication.
                        </div>

                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="survey-type" id="survey-type" value="quantitative">
                            <label class="form-check-label" for="perform-type-option2">
                              Quantitative Research
                            </label>
                        </div>
                        
                        <div style="padding-left:25px;font-size:11px;color:#333;">
                          Method of collecting and analyzing numerical data to answer questions, make predictions, and establish general laws. It focuses on obtaining data through a numbers-based, countable, or measurable communication.
                        </div>
                      </div>          
                      </div>
                  
                    </div>




                    <div class="" style="text-align:center">
                    
                      <a class="btn btn-primary" style="display:inline-block;width:125px" href="javascript:surveyApp.saveGeneralInfo();void(0);">Next</a>
                  
                    </div>


                </div> <!-- / end view -->





              <!------------------------------------------------- New Survey ------------------------------------------------------>

              
              <div class="card view"  id="view-add-section" >


                <div class="">
                  <div class="card col-lg-12">
                    <div class="card-body">
                      <h4 class="card-title">Add a Section</h4>
                    </div>
                  </div>
                </div>

                <div id="view-add-section-contents">

                </div>
              
              
              </div> <!-- / end view -->














                <!------------------------------------------------- Edit survey ------------------------------------------------------>
              
              <div class="card view" id="view-edit-survey">
                <div class="edit-survey-qus overflow-x-auto">
                  <div class="col-md-12">
                    <div class="content-area" id="view-edit-survey-content">
                    </div>
                  </div>
                </div>
              </div>
              <!---------------------------------------------------------------------------------------------------------------------------------->



              
              <!------------------------------------------------- Edit Facts ------------------------------------------------------>
              
              <div class="card view" id="view-edit-facts">
                <div class="card-body">
                  <div class="text-center survey-background" >
                      <div class="p-2 rounded">
                        <h5 class="text-center survey-background" >You Said...</h5>
                      </div>
                  </div>
                </div>            
                <div class="edit-survey-qus overflow-x-auto">
                  <div class="col-md-12">
                    <div class="content-area" id="view-edit-facts-content">
                    </div>
                  </div>
                </div>
              </div>
              <!---------------------------------------------------------------------------------------------------------------------------------->






              
                <!------------------------------------------------- Edit Screener Section ------------------------------------------------------>
              
                <div class="card view" id="view-screener-section-edit">

                
                  <div class="card-body">
                    <div class="text-center survey-background">
                        <div class="p-2 rounded">
                            <h5 class="text-center survey-background">Choose your Target audience</h5>
                        </div>
                    </div>
                    </div>
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12 col-md-12">
                                <div class="card">
                                    <div class="card-body">
                                      <p class="text-center font-weight-bold pt-2 pb-2 survey-interface" >Tell Us About Your Target Audience</p>
                                        <textarea class="form-control resize-none" 
                                                  id="target-audience-field" 
                                        placeholder="A target audience for a diabetes drug candidate would be: men and women in the USA, between the ages of 25 and 55 years old, have health insurance, and who are interested in medications to help control their insulin levels along with diet and exercise."></textarea>
                                        
                                        <span id="target-audience-error" class="target-audience-error" >
                                          Target Audience field is required</span>

                                        <div style="padding-left:25px;font-size:11px;color:#333;">
                                          A target audience is the demographic cut of a specific group. It is defined by elements such as age range, gender, geographical location, education level, purchasing power, social class and consumption habits.
                                        </div>
                                    </div>
                                </div>
                            </div>
                
                            
                        </div>
                    </div>
              
                    <div class="card">
                      <div class="card-body">
                          <div class="card-footer">
                              <div0 class="row">
                                  <div class="col-lg-6 col-md-6 actionbuttons prev-nxt-btns text-right">
                                      <button class="btn-primary " type="button" id="createNextBtn" onclick="surveyApp.saveTargetAudience();">Save</button>
                                  </div>
                              </div>
                          </div>
                    </div>

                  </div>
              </div> <!--/ .close view-screener-edit-->  
              <!---------------------------------------------------------------------------------------------------------------------------------->




              <!------------------------------------------------- Select Domains ------------------------------------------------------>
              
              <div class="card view" id="view-domain-select">
                <div class="card-body">
                  <div class="text-center survey-background" >
                      <div class="p-2 rounded">
                        <h5 class="text-center survey-background" >Select your Domain</h5>
                      </div>
                  </div>
                </div>            
                <div class="edit-survey-qus overflow-x-auto">
                  <div class="col-md-12">
                    <div class="content-area" id="view-domain-select-contents">
                    </div>
                  </div>
                </div>
              </div>
              <!---------------------------------------------------------------------------------------------------------------------------------->






              </div> <!--/ .container-->           
          </div> <!-- /.row -->
        </div><!-- /.container-fluid -->
      </div> <!-- /.content -->

      <!---------------------------------------------------------------------------------------------------------------------------------->



        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
          <!-- Control sidebar content goes here -->
          <div class="p-3">
            <h5>Title</h5>
            <p>Sidebar content</p>
          </div>
        </aside>
        <!-- /.control-sidebar -->


    </div>
    <!-- ./wrapper -->

      <!-- Main Footer -->
    <footer class="main-footer" style="display:none;">
        <!-- To the right -->
        <div class="float-right d-none d-sm-inline">
          <p>Page Load Time: <span>3.5 seconds</span></p>
        </div>
        <!-- Default to the left -->
        <strong>Copyright &copy; <span id="currentYear"></span> <a href="#">Survey Builder</a>.</strong> All rights reserved.
    </footer>
 
 
    
  
 
  <div id="modal" class="modal">
    <div class="modal-content">
      <span class="close">&times;</span>
      <label for="newQuestion">Edit the question:</label>
      <input type="text" id="newQuestion" />
      <input type="hidden" id="newQuestionNo" />
      <button class="btn btn-primary modal-button" id="saveQuestion">Save</button>
    </div>
  </div>



</div>














<div id="templates" style="display:none;">

  <div id="template-fact">
    
    <div style='font-weight:bold;'>[QUESTION]</div>

    <textarea class='txt-field-edit' 
        style="width:100%;height:100px;"
          id='answer-[FACT_ID]'
          >[ANSWER]</textarea>

    <div style='margin-bottom:25px;'>
      <a class="btn btn-primary" style='width:150px;' href="javascript:surveyApp.updateFact([FACT_ID]);void(0);">Update</a>
    </div>
  </div>


  <div id="template-domain">
      <div class="card">
        
        <div class="card-body">
          <h4 class="card-title mb-2">[LABEL]</h4>
        </div>

        <div class="card-body">
          <table style="width:100%">
          <tr>
            <td id="add-domain-[ID]" style="    vertical-align: top;
                                                          width: 50%;
                                                          padding: 25px;
                                                          font-size: 21px;
                                                          font-weight: bold;
                                                          padding-top: 45px;
                                                          font-style: italic;">
              [DESC]
            </td>
            <td>
              <textarea class="form-control resize-none"  
                  id="domain-input-[ID]" 
                  placeholder="[SUGGESTION]"
                  ></textarea>
            </td>
          </tr>
          </table>
        </div>


        <div class="card-body" style='text-align:right;'>
            <a class="btn btn-primary" style='width:150px;display:inline-block;' href="javascript:[ACTION];void(0);">Select</a>
        </div>


      </div>
  </div>

  <div id="template-add-section">
      <div class="card">
        
        <div class="card-body">
          <h4 class="card-title mb-2">[LABEL]</h4>
        </div>

        <div class="card-body">
          <table style="width:100%">
          <tr>
            <td id="add-section-question-[ID]" style="    vertical-align: top;
                                                          width: 50%;
                                                          padding: 25px;
                                                          font-size: 21px;
                                                          font-weight: bold;
                                                          padding-top: 45px;
                                                          font-style: italic;">
              [SECTION_HUMAN_PROMPT]
            </td>
            <td>
              <textarea class="form-control resize-none"  
                  id="section-input-[ID]" 
                  placeholder="[SUGGESTION]"
                  ></textarea>
            </td>
          </tr>
          </table>
        </div>


        <div class="card-body">
          [MODULE_LIST]
        </div>

        <div class="card-body" style='text-align:right;'>
            <a class="btn btn-primary" style='width:150px;display:inline-block;' href="javascript:surveyApp.addModule([CATEGORY_IDX]);void(0);">Add Module</a>
        </div>


      </div>
  </div>


    <div id="template-survey-header">
        <div class="card-body">
              <table border=0 style='width:100%'>
                <tr>
                  <td align=left>
                    <button type="button" class="reword-btn mx-1" style="width:100px;">
                        LOI: [LOI]
                    </button>
                  </td>
                  <td align=right>                     
                    <button type="button" class="reword-btn mx-1" style="width:100px;">
                        RI: [RI]
                    </button></td>
                </tr>
              </table>
              
        </div>      
    </div>



    <div id="template-statement-section">
      
      <div id="[ANCHOR]"></div>
      
      <input class="header-edit"
                id="[TITLE_ID]"
                onchange="[TITLE_EDIT_ACTION]"
                value="[TITLE]">

        <textarea class='txt-field-edit' 
            style="width:100%;height:[TEXT_BOX_HEIGHT];"
            id='[DESC_ID]'
            onchange="[DESC_EDIT_ACTION]"
            >[BODY]</textarea>
    </div>

    <div id="template-default-section">
    
        <div id="[ANCHOR]"></div>

        <input class="header-edit"
                id="[TITLE_ID]"                
                onchange="[EDIT_ACTION]"
                value="[TITLE]">

        <textarea class='txt-field-edit' 
            style="width:100%;height:[TEXT_BOX_HEIGHT];"
            id='[DESC_ID]'
            onchange="[EDIT_ACTION]"
            >[DESC]</textarea>
        <hr>
        [QUESTIONS]
    </div>

    <div id="template-single-choice-question">

      <div class="survey-question" style="padding:10px;border-bottom:5px solid #DDDDDD;">
        <table style="width:100%;">
        <tr>
          <td colspan=2>
            <b>[QUESTION_TYPE] Question [QUESTION_NUM]</b>
          </td>
        </tr>
        <tr>
          <td style="width:150px;">
              <button class="btn" id="section-btn-[IDX]"
                    onclick="toggleDropMenu('dropdown-options-[IDX]')">
                    Actions
                    <i class="bx bx-chevron-down" id="dropdown-popup-arrow"></i>
                </button>
              

              <div class="dropdown-popup" id="dropdown-options-[IDX]">
                <a href="javascript:surveyApp.addQuestion([SECTION_IDX], 'Yes or No');">
                  <i class="bx bx-cog"></i>
                  Add Yes or No Question
                </a>

                <a href="javascript:surveyApp.addQuestion([SECTION_IDX], 'Multiple Choice');">
                  <i class="bx bx-cog"></i>
                  Add a Multi-Choice Question
                </a>

                
                <a href="javascript:surveyApp.addQuestion([SECTION_IDX], 'Rating Scale');">
                  <i class="bx bx-cog"></i>
                  Add a Rating Scale Question
                </a>

                
                <a href="javascript:surveyApp.addQuestion([SECTION_IDX], 'Ranking');">
                  <i class="bx bx-cog"></i>
                  Add a Ranking Question
                </a>
                
                <a href="javascript:surveyApp.addAnswer([SECTION_IDX], [QUESTION_IDX]);">
                  <i class="bx bx-cog"></i>
                  Add Answer
                </a>

                <a href="javascript:[REWORD_ACTION]">
                  <i class="bx bx-cog"></i>
                  Reword
                </a>
                <a href="javascript:[REMOVE_ACTION]">
                  <i class="bx bx-cog"></i>
                  Delete
                </a>
              </div>

          </td>

          <td>

            <input type="text" 
            class="question-edit" 
            id="[ID]" 
            value="[QUESTION_TEXT]" 
            onchange="[EDIT_ACTION]">


          </td>
        </tr>
        </table>
        
        [ANSWERS]
      </div>
    </div>

    <div id="template-single-choice-answer">
        
      <table style="width:100%;">
        <tr>
  
            <td>
              <input type="text" class="answer-edit" id="[ANSWER_ID]" value="[ANSWER_TEXT]" onchange="[ANSWER_EDIT_ACTION]">
            </td>
    
            <td  style="width:25px;">

              <div class="col-lg-12 d-flex flex-column flex-sm-row gap-2 gap-sm-0 justify-content-end align-items-center mb-3"> 
                <span class="button-spacing">
                    <button type="button" class="reword-btn mx-1" onclick="[ANSWER_DELETE_ACTION]">
                        Delete
                    </button>
                </span>
                <span class="button-spacing">
                    <button type="button" class="reword-btn mx-1" style="width:200px;" onclick="surveyApp.showProgrammingNotes('answer-note-wrapper-[ANSWER_ID]')">
                        Programming Notes
                    </button>
                </span>                
                <p>
                
                
            </div>
            
          </td>

        </tr>
        <tr style="display:none;visibility:hidden" id="answer-note-wrapper-[ANSWER_ID]">
          <td style="width:100%;">&nbsp;</td>
          <td>
          Programming Notes: 
          <br>
          <textarea id="[ANSWER_NOTE_ID]" style="width:300px;height:150px;border:1px solid #333333;" onchange="[ANSWER_EDIT_NOTE_ACTION]">[ANSWER_NOTE_TEXT]</textarea>
          </td>
        </tr>
      </table>
        
        


    </div>

    
    <div id="template-side-menu-item-small">
      <li class="nav-item toc-item">
          <a href="[LINK]" style="color:#555555;font-weight: bold;">
            [LABEL]
          </a>
        </li>
    </div>

    <div id="template-side-menu-item">
      <li class="nav-item">
          <a href="[LINK]" class="nav-link active">
            <i class="far fa-circle nav-icon"></i>
            <p>[LABEL]</p>
          </a>
        </li>
    </div>


    <div id="template-free-text-answer">

        <textarea class='txt-field-edit' 
                style="width:100%;"
                id=''
                placeholder='User enters answer here...'
                ></textarea>
    </div>


    <div id="template-yes-no-question">

        [QUESTION_NUM] <input type="text" 
                class="question-edit" 
                id="[ID]" 
                value="[QUESTION_TEXT]" 
                onchange="[EDIT_ACTION]">

        <div class="col-lg-12 d-flex flex-column flex-sm-row gap-2 gap-sm-0 justify-content-end align-items-center mb-3">
            <button type="button" class="reword-btn mx-1" onclick="[REWORD_ACTION]">Reword</button> 
            <span class="button-spacing">
                <button type="button" class="reword-btn mx-1" onclick="[REMOVE_ACTION]">Delete</button>
            </span> 
        </div>

        <input type="text" class="answer-edit" id="" value="Yes" disabled">
        <input type="text" class="answer-edit" id="" value="No" disabled">


    </div>

</div>



  <script src="https://code.jquery.com/jquery-1.9.1.min.js"></script>      
  <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/css/toastr.css" rel="stylesheet"/>      
  <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/js/toastr.js"></script>
      
  <script src='js/beamer-lib/data.class.js?ver=2024.12.04'></script>
  <script src='js/beamer-lib/user.class.js?ver=2024.12.04'></script>
  <script src='js/beamer-lib/utils.class.js?ver=2024.12.04'></script>

  <script src='js/config.js?ver=2024.12.04'></script>
  <script src='js/custom.js?ver=2024.12.04'></script>  
  <script src='js/survey-app.class.js?ver=2024.12.04'></script>

  <script>
        var config = new Config();
        var utils = new BeamerUtils();
        var user = new User(config);
        var dataHandler = new Data();
        var surveyApp = new SurveyApp();

        user.init(surveyApp.start);

        function startAppAfterLogin()
        {
          surveyApp.startNewSurvey(); 
        }
        
    
  </script>
  <script>
  
  const dropdownBtn = document.getElementById("btn");
const dropdownMenu = document.getElementById("dropdown");
const toggleArrow = document.getElementById("arrow");

function toggleDropMenu(id)
{
  var d = document.getElementById(id);
  d.classList.toggle("dropdown-popup-show");
  console.log("Opening menu:" + id);

}
/*
const toggleDropdown = function () {
  dropdownMenu.classList.toggle("show");
  toggleArrow.classList.toggle("arrow");
console.log("Toggling");
};
*/


    /*
    window.onload = function() {
      

      sessionStorage.clear();

      const urlParams = new URLSearchParams(window.location.search);
    
      var type = urlParams.get('type');
    
      if (type == 'survey') 
      {
        surveyApp.loadCreateNewSurvey()
      }

      document.getElementById("currentYear").innerText = new Date().getFullYear();
      
    }
    */
  </script>

</body>

</html>