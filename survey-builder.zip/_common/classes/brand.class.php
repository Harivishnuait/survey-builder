<?php
class Brand
{
    public $data = "";


    function __construct()
    {
        $this->data = new stdClass();
    }

    function loadBrand($conn, $userID, $brandID)
    {

        $sql = "select * from related_brands where brandID = $brandID and userID = $userID";

        $this->data = getDataObject($conn, $sql);
    }

    function createBrand($conn, $auth, $params)
    {

        // Get the current user ID
        $userID = $auth->getUserID();

        // Prepare the SQL query
        $sql = "INSERT INTO survey.related_brands (userID, brandName, createdDate, modifiedDate)
                VALUES ( '$userID', '$params->brandName', NOW(), NOW())";

        // Execute the SQL query
        executeQuery($conn, $sql);
        $brandID = getKey($conn, "select max(brandID) from survey.related_brands where userID = " . $auth->getUserID());
        return $brandID;
    }


    function getBrandData($conn, $brandID)
    {
        $out = new stdClass();

        $sql = "select *
        from related_brands 
        where brandID = $brandID
        ";

        $out = getDataObject($conn, $sql);

        return $out;
    }

    function removeBrand($conn, $userID, $brandID)
    {
        $sql = "delete from related_brands where brandID = $brandID and userID = $userID";

        executeQuery($conn, $sql);
    }

    function brandDataExist($conn, $brandName)
    {
        $out = new stdClass();

        $sql = "select *
        from related_brands 
        where brandName = '$brandName'
        ";

        $out = getDataObject($conn, $sql);

        return $out;
    }
}
