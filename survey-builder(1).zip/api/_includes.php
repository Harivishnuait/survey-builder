<?php
if(!isset($globalFilesHaveBeenLoaded))
{
    $rootIncludePath = "../";
    include_once($rootIncludePath . "_common/shared/global-includes.php");
  
}

include_once "../_common/classes/survey.class.php";

include_once "../_common/classes/surveyDataObj.class.php";

include_once "../_common/classes/surveyPrompts.class.php";

include_once "../_common/classes/surveyValidator.class.php";

include_once "../_common/classes/open-ai.class.php";

require_once('../vendor/autoload.php');

?>