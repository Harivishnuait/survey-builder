function Data()
{
    this.config = {rootUrl:config.rootUrl};

    this.debugAjax = false;

    this.loadingDivID = "";
    
    this.save = function(key,value){this.saveData(key,value);}

    this.saveData = function(key, value)
    {
        localStorage.setItem(key, JSON.stringify(value));
    }

    this.get = function(key) {return this.getData(key);}
    this.getData = function(key)
    {
        var val = localStorage.getItem(key);

        if(this.isJsonString(val))
        {      
          return JSON.parse(val)
        }
        else
        {
          return val;
        }
    }

    this.clearAllData = function()
    {
        localStorage.clear();
    }

    this.generateGuid = function() 
    {
        function s4() {
          return Math.floor((1 + Math.random()) * 0x10000)
            .toString(16)
            .substring(1);
        }
        return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
    }
  
    this.ajaxOff = function()
    {
        //place holder
    }
  
    this.addUserAuth = function(data)
    {
      data.userGuid = user.userGuid;
      data.authToken = user.authToken;

      return data;
    }

    this.startAjax = function()
    {
      this.numRunningAjax++;

      var d = document.getElementById("ajax-ind-img");
      
      if(d != undefined) 
      {
        d.style.visibility = "visible";
      }
    }


    this.endAjax = function()
    {
      this.numRunningAjax--;
      
      if(this.numRunningAjax <= 0) this.numRunningAjax = 0;

      
      var d = document.getElementById("ajax-ind-img");
      
      if(d != undefined) 
      {
        d.style.visibility = "hidden";
      }


      //document.getElementById("div-ajax-indicator").innerHTML = "Request: " + data.numRunningAjax;
    }


    this.loadDiv = function(url, urlData, divID)
    {
      if(data.loadingDivID != "")
      {
        console.error(data.loadingDivID + " is waiting to be loaded");
        return;
      }
      else
      {
        data.loadingDivID = divID;
      }


      var requestUrl = this.config.rootUrl + url;

      urlData = this.addUserAuth(urlData);

      if(data.debugAjax) console.log("data.loadDiv(): sending", data, url);

      data.startAjax();

      $.ajax({
        type: "GET",
        url: requestUrl,
        data:urlData,
        complete: function () {
            data.ajaxOff();
        },
        success: function(dataPacket) {
              

              document.getElementById(data.loadingDivID).innerHTML = dataPacket;

              data.loadingDivID = "";
              
              data.endAjax();
        
            }
        ,error: function(jqXHR, exception) {
            console.error("AJAX Issue:" + jqXHR.responseText);
            }
      });

    }



    this.sendPostData = function(url, urlData, callBack)
    {
      var requestUrl = url;
        
      if(!requestUrl.includes("http"))
      {
        requestUrl = this.config.rootUrl + url;
      }
      

      urlData = this.addUserAuth(urlData);

      if(dataHandler.debugAjax) console.log("data.sendDataAndCallBack(): sending", urlData, url);

      dataHandler.startAjax();

      $.ajax({
        type: "POST",
        url: requestUrl,
        data:urlData,
        complete: function () {
            dataHandler.ajaxOff();
        },
        success: function(dataPacket) {
        
              if(dataHandler.debugAjax) console.log("data.sendDataAndCallBack(): returned", dataPacket);

              if(dataPacket.hadError)
              {
                console.warn("WARNING: " + dataPacket.error.errorMsg);
                utils.growl(dataPacket.error.errorMsg, 3);
                return;
              }

              if(dataPacket.userAlerts.length > 0)
              {
                utils.growl(dataPacket.userAlerts[0], 3);
              }


              callBack(dataPacket.data);


              dataHandler.endAjax();
        
            }
        ,error: function(jqXHR, exception) {
            console.error("AJAX Issue:" + jqXHR.responseText);
            }
      });

    }





    this.sendDataAndCallBack = function(url, urlData, callBack)
    {
      var requestUrl = url;
        
      if(!requestUrl.includes("http"))
      {
        requestUrl = this.config.rootUrl + url;
      }
      

      urlData = this.addUserAuth(urlData);

      if(dataHandler.debugAjax) console.log("data.sendDataAndCallBack(): sending", urlData, url);

      dataHandler.startAjax();

      $.ajax({
        type: "GET",
        url: requestUrl,
        data:urlData,
        complete: function () {
            dataHandler.ajaxOff();
        },
        success: function(dataPacket) {
        
          //try{
                if(dataHandler.debugAjax) console.log("data.sendDataAndCallBack(): returned", dataPacket);
               
                if(dataPacket.hadError)
                {
                  console.warn("WARNING: " + dataPacket.error.errorMsg);
                  beamerGui.growl(dataPacket.error.errorMsg, 3);
                }
               
                if(dataPacket.userAlerts.length > 0)
                {
                  beamerGui.growl(dataPacket.userAlerts[0], 3);
                }

                
                callBack(dataPacket.data);

                
                dataHandler.endAjax();
          //}
          //catch(err) {
          //  console.log(dataPacket);
          //  console.log(err.message);            
          //  surveyApp.showError("Oh no, something went wrong.");
          //}
          
        }
        ,error: function(jqXHR, exception) {
            console.error("AJAX Issue:" + jqXHR.responseText);
            }
      });

    }




      this.sendData = function(url, urlData)
      {

        var requestUrl = url;
        
        if(!requestUrl.includes("http"))
        {
          requestUrl = this.config.rootUrl + url;
        }


        if(data.debugAjax) console.log("data.sendData(): sending", urlData);

        data.startAjax();

        urlData = this.addUserAuth(urlData);

        $.ajax({
          type: "GET",
          url: requestUrl,
          data:urlData,
          complete: function () {
              data.ajaxOff();
          },
         success: function(data) {
                  
                if(data.debugAjax) console.log(data);

                if(data.error.errorMsg != "")
                {
                  console.error(data.error.errorMsg);
                }
           
                 data.endAjax();
              }
          ,error: function(jqXHR, exception) {
             console.error("AJAX Issue:" + jqXHR.responseText);
              }
        });

      }


      this.isJsonString = function(str) {
        try {
            JSON.parse(str);
        } catch (e) {
            return false;
        }
        return true;
    }

}