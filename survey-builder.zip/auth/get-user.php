<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

///////////////////////////////////////////////////////// Prep
include "_includes.php";

$out = new DataPacket();

$dataOut = new stdClass();

$auth = new Auth();

$userGuid = clean($conn, getVar("userGuid"));

$out->data = $auth->fromGuid($conn,$userGuid);

header('Content-type: application/json');

echo $out->generateOutput($auth);

/////////////////////////////////////////////////////////


?>