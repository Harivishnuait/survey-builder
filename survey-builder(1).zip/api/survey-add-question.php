<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

///////////////////////////////////////////////////////// Prep
include "_includes.php";

$out = new DataPacket();

$auth = new Auth();

$auth->fromSession($conn);

$dataOut = new stdClass();

///////////////////////////////////////////////////////// Prep

$survey = new Survey();

$survey->debug = $debug;

$surveyID = clean($conn, getVar("survey-id"));
$sectionIdx = clean($conn, getVar("section-idx"));
$questionType = clean($conn, getVar("question-type"));

$survey->loadFromDatabase($conn, $surveyID);
$survey->setAuth($auth);

$survey->addQuestion($conn, $sectionIdx, $questionType);

$survey->saveSurvey($conn, $auth);

$dataOut->survey = $survey->getSurveyData($conn, $surveyID);

///////////////////////////////////////////////////////// Send Data

$out->data = $dataOut;

header('Content-type: application/json');

echo $out->generateOutput($auth);

/////////////////////////////////////////////////////////


?>