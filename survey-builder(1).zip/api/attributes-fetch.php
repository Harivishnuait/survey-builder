<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

///////////////////////////////////////////////////////// Prep
include "_includes.php";

$out = new DataPacket();

$auth = new Auth();

$auth->fromSession($conn);

$dataOut = new stdClass();

///////////////////////////////////////////////////////// Prep

include "../_common/classes/attributes.class.php";

$attributes = new Attributes();

$sql = "select attributesID
                ,attributesName
        from attributes where userID = " . $auth->getUserID() . "
        ";
        
$dataOut->attributes = getDataObjects($conn, $sql);

///////////////////////////////////////////////////////// Send Data

$out->data = $dataOut;

header('Content-type: application/json');

echo $out->generateOutput($auth);

/////////////////////////////////////////////////////////


?>
