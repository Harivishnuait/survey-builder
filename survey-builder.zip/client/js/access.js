function maintainFiveRows() {
    let tableBody = document.getElementById("userTableBody");
    let currentRows = tableBody.children.length;
    let emptyRows = document.querySelectorAll(".empty-row");
    
    // Remove any previously added empty rows
    emptyRows.forEach(row => row.remove());

    // Add empty rows until there are 10 rows in total
    for (let i = currentRows; i < 10; i++) {
        let emptyRow = document.createElement("tr");
        emptyRow.classList.add("empty-row");
        emptyRow.innerHTML = `
            <td colspan="7" style="text-align: center; background-color: white; border-top: 1px solid white ; height: 1px;"> </td>
        `;
        tableBody.appendChild(emptyRow);
    }
}

// Call the function once the DOM is fully loaded
window.onload = function() {
    maintainFiveRows();
};