<?php

declare(strict_types=1);

namespace OpenAI\Exceptions;

use Exception;

final class InvalidArgumentException extends Exception {}
