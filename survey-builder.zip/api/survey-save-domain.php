<?php
///////////////////////////////////////////////////////// Prep
include "_includes.php";

$out = new DataPacket();

$auth = new Auth();

$auth->fromSession($conn);

$dataOut = new stdClass();

///////////////////////////////////////////////////////// Prep

$surveyID = clean($conn, getVar("surveyID"));
$domainKey = clean($conn, getVar("domainKey"));
$desc = clean($conn, getVar("desc"));

if($surveyID <= 0) $surveyID = $_SESSION["lastSurveyID"];

if($debug == "Y")
{
    debug("survey-save-domain.php");
    debug("surveyID=$surveyID");
    debug("desc=$desc");
}

$survey = new Survey();
$survey->debug = $debug;
$survey->setAuth($auth);

$survey->loadFromDatabase($conn, $surveyID);

$survey->updateDomain($domainKey, $desc);

$dataOut = $survey->getSurveyData($conn, $surveyID);

///////////////////////////////////////////////////////// Send Data

$out->data = $dataOut;

header('Content-type: application/json');

echo $out->generateOutput($auth);

/////////////////////////////////////////////////////////


?>