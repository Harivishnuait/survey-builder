<?php
///////////////////////////////////////////////////////// Prep
include "_includes.php";

$out = new DataPacket();

$auth = new Auth();

$auth->fromSession($conn);

$dataOut = new stdClass();

///////////////////////////////////////////////////////// Prep

$surveyID = clean($conn, getVar("surveyID"));
$factID = clean($conn, getVar("factID"));
$answer = clean($conn, getVar("answer"));

$survey = new Survey();
$survey->loadFromDatabase($conn, $surveyID);

$survey->updateFact($factID, $answer);

$dataOut = $survey->getSurveyData($conn, $surveyID);

///////////////////////////////////////////////////////// Send Data

$out->data = $dataOut;

header('Content-type: application/json');

echo $out->generateOutput($auth);

/////////////////////////////////////////////////////////


?>