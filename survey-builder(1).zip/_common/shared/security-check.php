<?php

if(!isset($userGuid)) $userGuid = clean($conn, getVar("userGuid"));
if(!isset($userToken)) $userToken = clean($conn, getVar("userToken"));

$out = new DataPacket();
$auth = new Auth();
$user = $auth->getUser($conn, $userGuid, $userToken);

if($user == "" && !$excludeSecurityCheck)
{
    $out->errorID = -1;
    
    $out->errorMsg = "Not authorized.";

    $out->debug = ["not authorized"];
        
    header('Content-type: application/json');

    echo $out->generateOutput();
    
    die();
}

if($excludeSecurityCheck)
{
    $user = new stdClass();
    
    $user->userID = -1;

}
?>