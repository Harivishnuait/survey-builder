// function Config() {
//   this.rootUrl = "";
//   this.authUrl = this.rootUrl + "";
//   this.apiUrl = this.rootUrl + "/api/";
//   this.dataUrl = this.rootUrl + "/data/";
//   this.openAIUrl = this.rootUrl + "/open-ai/";
// }
function Config() {
  this.rootUrl =
    window.location.hostname === "localhost"
      ? "http://localhost/survey-builder"
      : "https://your-production-url.com";
  this.authUrl = this.rootUrl + "/auth/";
  this.apiUrl = this.rootUrl + "/api/";
  this.dataUrl = this.rootUrl + "/data/";
  this.openAIUrl = this.rootUrl + "/open-ai/";
}
