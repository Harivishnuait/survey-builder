<?php
///////////////////////////////////////////////////////// Prep
include "_includes.php";

$out = new DataPacket();

$auth = new Auth();

$auth->fromSession($conn);

$dataOut = new stdClass();

///////////////////////////////////////////////////////// Prep
$surveyID = clean($conn, getVar("surveyID"));

if($surveyID <= 0) $surveyID = $_SESSION["lastSurveyID"];

$survey = new Survey();

$survey->loadFromDatabase($conn, $surveyID);


$sql = "select smc.moduleCategoryID
                ,smc.moduleCategoryName as moduleCategoryName
                ,smc.moduleCategoryTitle as moduleCategoryTitle
                ,smc.moduleCategoryDesc as moduleCatetgoryDescription
                ,smc.promptForHuman as moduleCategoryPromptForHuman
                ,smc.suggestion as moduleCategorySuggestion
        from survey_modules_category smc
        left outer join survey_sections ss on ss.moduleCategoryID = smc.moduleCategoryID
                                                    and ss.surveyID = $surveyID
        where smc.isActive = 'Y'
        and smc.moduleCategoryName NOT in ('Objective','Screener')
        and ss.moduleCategoryID is null
        order by smc.defaultDisplayOrder,smc.moduleCategoryName";

if($debug == "Y") debug($sql);

$surveySections = getDataObjects($conn, $sql);

$q = executeQuery($conn, $sql);

$i=0;

while($cat = mysqli_fetch_object($q))
{
    $sql = "select moduleID, moduleTitle, questionTypes, moduleDesc from survey_modules where moduleCategory = '$cat->moduleCategoryName' order by defaultDisplayOrder";

    $surveySections[$i]->modules = getDataObjects($conn, $sql);

    $i++;
}

$dataOut = new stdClass();

$dataOut->surveySections = $surveySections;

///////////////////////////////////////////////////////// Send Data

$out->data = $dataOut;

header('Content-type: application/json');

echo $out->generateOutput($auth);

/////////////////////////////////////////////////////////
?>