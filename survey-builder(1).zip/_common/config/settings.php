<?php

date_default_timezone_set("America/New_York");

function getAppConfig()
{
    $config = [];

    $config["environment-name"] = "beta";

    $config["schema"] = "survey_db";
    $config["database"] = "survey_db";
    $config["table-prefix"] = "survey";
    $config["db_host"] = "localhost";
    $config["db_user"] = "root";
    $config["db_passwd"] = "";
    $config["db_schema_name"] = "survey_db";
    $config["userSessionVarName"] = "surveyDataUserID";

    $config["openAiKey"] = "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";

    return $config;
}

?>