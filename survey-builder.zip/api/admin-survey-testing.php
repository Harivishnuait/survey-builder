<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

///////////////////////////////////////////////////////// Prep
include "_includes.php";

$out = new DataPacket();

$auth = new Auth();

$auth->fromSession($conn);

$dataOut = new stdClass();

///////////////////////////////////////////////////////// Prep

$survey = new Survey();
$survey->debug = $debug;

$action = getVar("action");
$prompt = getVar("prompt");

if($action == "load-last-survey")
{
    $surveyID = getKey($conn, "select max(surveyID) from survey.survey");

    $sql = "select * from survey.survey where surveyID = $surveyID";
    $surveyObj = getDataObject($conn, $sql);

    
    $surveyData = json_decode($surveyObj->surveyJson);

    $surveyParams = json_decode($surveyObj->surveyParams);

    $survey->loadSurvey($surveyID, $surveyData, $surveyParams);


    print_r($surveyObj);
}



if($action == "create-test-survey")
{
    debug("Creating Test Survey");

    include "../test/test-survey-json-objs.php";

    
    $testSetName = getVar("test-set-name");
    
    if($testParams[$testSetName])
    {
        //$surveyObj = json_decode($testSurveyObjs[$testSetName]);
        $userParams = json_decode($testParams[$testSetName]);
        
        //$userParams = json_decode($testParams["elevate"]);
        
        if(!isset($userParams))
        {
            debug("Error: Params did not parse");
            exit();
        }

        $survey->createSurvey($conn, $auth, $userParams);
        
        print_r($survey->surveyDataObj);
    
        $survey->saveSurvey($conn, $auth);
    
    }
    else
    {
        debug("Test Set: $testSet does not exits");
    }
    
    die("done");
}


if($action == "gen-test-survey")
{
    debug("Generating Test Survey");

    include "test-json-obj.php";

    
    $surveyObj = json_decode($testSurveyObjs["know-won"]);
    $userParams = json_decode($testParams["know-won"]);

    $survey->loadSurvey(0, $surveyObj, $userParams);

    print_r($survey->surveyDataObj);

    $survey->saveSurvey($conn, $auth);


    die("done");
}

if($action == "get-response")
{
    if ($debug)
    {
        debug("-----------------Survey Parameters------------------------------------");
        print_r($params);
        debug("-----------------------------------------------------");
    }
   

    $reply = $survey->askChatGpt($prompt);

    if ($debug)
    {
        debug("-----------------Main REPLY------------------------------------");
        print_r($reply);
        debug("-----------------------------------------------------");
        //die();
    }

    $surveyObj = json_decode($reply);

    $surveyJson = json_encode($surveyObj, JSON_HEX_APOS);

    $out->data->response = $surveyJson;
}


///////////////////////////////////////////////////////// Send Data


header('Content-type: application/json');

echo $out->generateOutput($auth);

/////////////////////////////////////////////////////////


?>