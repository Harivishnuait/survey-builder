<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

///////////////////////////////////////////////////////// Prep
include "_includes.php";

$out = new DataPacket();

$auth = new Auth();

$auth->fromSession($conn);

$dataOut = new stdClass();

///////////////////////////////////////////////////////// Prep

include "../_common/classes/brand.class.php";

$brandID = clean($conn, getVar("brand-id"));
$action = clean($conn, getVar("action"));

$brand = new Brand();

$brand->removeBrand($conn, $auth->userID, $brandID);

$dataOut = new stdClass();

///////////////////////////////////////////////////////// Send Data

$out->data = $dataOut;

header('Content-type: application/json');

echo $out->generateOutput($auth);

/////////////////////////////////////////////////////////
