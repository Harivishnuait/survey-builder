    <?php
    ///////////////////////////////////////////////////////// Prep
    include "_includes.php";

    require_once '../vendor/autoload.php';
    
    $out = new DataPacket();

    $auth = new Auth();

    $auth->fromSession($conn);

    $dataOut = new stdClass();

    ///////////////////////////////////////////////////////// Prep

    $surveyID = clean($conn, getVar("surveyID"));

    $survey = new Survey();

    $survey->loadFromDatabase($conn, $surveyID);

    header("Content-type:application/json");

    print json_encode($survey->surveyDataObj, JSON_PRETTY_PRINT);
    
    ?>