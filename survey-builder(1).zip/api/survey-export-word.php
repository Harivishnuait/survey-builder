    <?php
    ///////////////////////////////////////////////////////// Prep
    include "_includes.php";

    require_once '../vendor/autoload.php';
    
    $out = new DataPacket();

    $auth = new Auth();

    $auth->fromSession($conn);

    $dataOut = new stdClass();

    ///////////////////////////////////////////////////////// Prep

    $surveyID = clean($conn, getVar("surveyID"));

    $survey = new Survey();

    $survey->loadFromDatabase($conn, $surveyID);

    $fileName = "survey-" . $survey->getSurveyGuid() . ".docx";
   
    ob_clean();
    
    $phpWord = new \PhpOffice\PhpWord\PhpWord();

    $wordSection = $phpWord->addSection();

    
    $sections = $survey->surveyDataObj->sections;

    #$styleBold = array('bold'=>true, 'size' => 12);
    #$wordSection->addFontStyle('rStyle', array('bold'=>true, 'italic'=>true, 'size'=>16));
    #todo - proper spacing, set up table for "rating scale" check

    foreach ($sections as $section) {
        $title = $section->title;
        $desc = $section->description;

        $wordSection->addText($title, array('bold'=>true, 'size'=>12));
        $wordSection->addText('');
        $wordSection->addText($desc);
        #lazy
        $wordSection->addText('');

        foreach ($section->questions as $question) {
            #check if bork
            $txt = $question->question_type . " Question " . $question->question_num + 1 . ": " . $question->question_text;
            $wordSection->addText('');
            $wordSection->addText($txt, array('italic' =>true));
            
            if($debug)
            {
                debug("Adding $txt");
            }
            
            if (property_exists($question, 'answers')) {

                if($question->question_type == 'Rating Scale')
                {
                    #unable to debug properly, line 71 seems to be the issue off a glance
                    $tableStyle = array(
                        'borderColor' => '006699',
                        'borderSize'  => 10,
                        'cellMargin'  => 50,
                        'valign' => 'center'
                    );
                    $firstRowStyle = array('bgColor' => '66BBFF');
                    $phpWord->addTableStyle('myTable', $tableStyle, $firstRowStyle);
                    
                    $wordSection->addText('rating');
                    $table = $wordSection->addTable('myTable');
                    $table->addRow();

                    foreach($question->answers as $answer){
                        $answerTxt = $answer->answer_text;
                        $table->addCell(1000)->addText($answerTxt);
                        
                        if(strlen($answer->answer_note) > 0)
                        {
                            $wordSection->addText("                       Programming Notes: " . $answer->answer_note);
                        }
                    }
                }
                else{
                    foreach ($question->answers as $answer) {

                        $answerTxt = $answer->answer_text;
                        
                        if($answer->terminate_survey) 
                        {
                            $answerTxt.=" [TERMINATE SURVEY]";
                            }
    
                        if($debug)
                        {
                            debug("Adding $answerTxt");
                        }

                        $wordSection->addListItem($answerTxt, 0, [3], [3]);

                        if(strlen($answer->answer_note) > 0)
                        {
                            $wordSection->addText("                      Programming Notes: " . $answer->answer_note);
                        }

                    }
                }
            }
                
            $wordSection->addText('');
            
        }
    }


    $objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($phpWord, 'Word2007');
    header('Content-Type: application/octet-stream');
    header("Content-Disposition: attachment; filename=$fileName");
    $objWriter->save('php://output');
    exit;
    ?>