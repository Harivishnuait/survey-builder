<?php
require_once __DIR__ . '/../../vendor/autoload.php';  

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
function setJsonResponseHeader() {
    header('Content-Type: application/json');
}

class Auth
{
    public $debug = false;
    public $userID = 0;
    public $userGuid = "";
    public $username = "Unknown User";
    public $email = "Unknown";

    public $lastErrorMsg = "";
    public $config = "";

    function __construct()
    {
        $this->config = getAppConfig();
    }

    public function getUserID()
    {
        return $this->userID;
    }
    public function getUserGuid()
    {
        return $this->userGuid;
    }

    public function fromSession($conn)
    {
        $instance = new self();

        if (isset($_SESSION["userGuid"])) {
            $this->getUserFromGuid($conn, $_SESSION["userGuid"]);
        }
    }

    public function fromGuid($conn, $guid)
    {
        return $this->getUserFromGuid($conn, $guid);
    }

    public function getUser($conn, $userGuid, $tokenGuid)
    {
        $sql = "select userID from " . $this->config["schema"] . "." . $this->config["table-prefix"] . "_user where userGuid = '$userGuid'";

        $this->userID = getKey($conn, $sql);


        if ($this->userID > 0) {
            $this->userGuid = $userGuid;

            $sql = "select userID, userName, isGuestAccount, authToken, securityLevel from " . $this->config["schema"] . "." . $this->config["table-prefix"] . "_user where userID = $this->userID";

            return getDataObject($conn, $sql);
        }

        return "";
    }

    public function isLoggedIn()
    {
        return $this->userID > 0;
    }

    public function logout()
    {
        $this->userID = 0;
        $this->userGuid = "";
        $_SESSION["userGuid"] = "";
        $_SESSION["username"] = "";
        return true;
    }

    public function getUserIDFromGuid($conn, $userGuid)
    {
        $sql = "select userID, userGuid, username, email from " . $this->config["schema"] . "." . $this->config["table-prefix"] . "_user where userGuid = '$userGuid'";

        // print $sql . "/n/r";

        $data = getDataObject($conn, $sql);

        return $data->userID;
    }


    public function getUserFromGuid($conn, $userGuid): bool|object|null
    {
        $sql = "select userID, userGuid, username, email from " . $this->config["schema"] . "." . $this->config["table-prefix"] . "_user where userGuid = '$userGuid'";

        //print $sql . "/n/r";

        $data = getDataObject($conn, $sql);

        if (isset($data->userID)) {

            $this->userID = $data->userID;

            $this->userGuid = $data->userGuid;

            $this->username = $data->username;

            $this->email = $data->email;

            $_SESSION["userGuid"] = $data->userGuid;
            $_SESSION["username"] = $data->username;
        }

        return $data;
    }

    public function securityCheck($conn, $area)
    {
        $sql = "select count(*) from pat_user_security where userID = $this->userID and securityKey = '$area' and hasAccess='Y'";

        $count = getKey($conn, $sql);

        if ($count > 0) {
            return true;
        }

        return false;
    }


    public function loginUser($conn, $userData)
    {
        $out = new stdClass();
        $out->error = "";
        $out->userID = 0;
        $out->userGuid = "";
        $out->roleID = 0;

        $this->lastErrorMsg = "";
        $this->userID = 0;
        $this->userGuid = "";

        if ($userData->username == "")
            $out->error = "Invalid Username";
        if ($userData->password == "")
            $out->error = "Invalid Password";

        if ($userData->username == "")
            $this->lastErrorMsg = "Invalid Username";
        if ($userData->password == "")
            $this->lastErrorMsg = "Invalid Password";


        $sql = "select userGuid , role_id 
                        from  " . $this->config["schema"] . "." . $this->config["table-prefix"] . "_user  
                        where (BINARY username='$userData->username' or email = '$userData->username')
                        and password = MD5('$userData->password')";

        $userGuid = getDataObject($conn, $sql);

        if ($userGuid == "") {
            $out->error = "Invalid login";
        } else {

            $this->getUserFromGuid($conn, $userGuid->userGuid);
            $out->roleID = $userGuid->role_id;
        }

        $out->userID = $this->userID;
        $out->userGuid = $this->userGuid;

        return $out;
    }


    public function login($conn, $username, $password)
    {
        $this->lastErrorMsg = "";
        $this->userID = 0;
        $this->userGuid = "";

        if ($username == "")
            $this->lastErrorMsg = "Invalid Username";
        if ($password == "")
            $this->lastErrorMsg = "Invalid Password";

        $sql = "select count(*) from  " . $this->config["schema"] . "." . $this->config["table-prefix"] . "_user  where username='$username' and userPass = MD5('$password')";
        //print $sql;

        if (getKey($conn, $sql) <= 0) {
            $this->lastErrorMsg = "Invalid login";
        }

        if ($this->lastErrorMsg == "") {
            $sql = "select * from  " . $this->config["schema"] . "." . $this->config["table-prefix"] . "_user  where username='$username' and userPass = MD5('$password')";

            $user = getDataObject($conn, $sql);

            $this->userID = $user->userID;

            $this->userGuid = $user->userGuid;
        }


        return $this->userID;
    }

    public function getCreds()
    {
        $auth = new stdClass();
        $auth->userID = $this->getUserID();
        $auth->userGuid = $this->getUserGuid();

        return $auth;
    }


    public function registerUser($conn, $userData)
    {
        $out = new stdClass();
        $out->error = "";
        $out->userID = 0;
        $out->userGuid = "";

        if ($this->debug)
            print "creating account\r";

        $this->lastErrorMsg = "";
        $this->userID = 0;
        $this->userGuid = "";

        if ($userData->username == "")
            $out->error = "Invalid Username";
        if ($userData->email == "")
            $out->error = "Invalid Email address";
        if (!filter_var($userData->email, FILTER_VALIDATE_EMAIL)) {
            $out->error = "Invalid Email address";
        }
        if ($userData->password == "")
            $out->error = "Invalid Password";
        if ($userData->confirmPassword == "")
            $out->error = "Invalid Confirm Password";

        if ($userData->password != $userData->confirmPassword)
            $out->error = "Passwords do not match";

        $sql = "select count(*) 
                    from  " . $this->config["schema"] . "." . $this->config["table-prefix"] . "_user  
                    where username = '$userData->username'";

        if (getKey($conn, $sql) > 0) {
            $out->error = "User already exists";
        }

        $sql = "select count(*) 
                    from  " . $this->config["schema"] . "." . $this->config["table-prefix"] . "_user  
                    where email = '$userData->email'";

        if (getKey($conn, $sql) > 0) {
            $out->error = "Email allready exists";
        }



        if ($out->error == "") {


            $sql = "insert into " . $this->config["schema"] . "." . $this->config["table-prefix"] . "_user 
                    (userGuid, authToken, userName, password, email, createdDate, modifiedDate) 
                    values (
                        UUID()
                        ,UUID()
                        ,'$userData->username'
                        ,MD5('$userData->password')
                        ,'$userData->email'
                        ,NOW()
                        ,NOW()
                    )";

            if ($this->debug)
                print "SQL: $sql\r";

            executeQuery($conn, $sql);

            $sql = "select * 
                        from " . $this->config["schema"] . "." . $this->config["table-prefix"] . "_user 
                        where userName = '$userData->username' 
                        order by userID desc";

            $user = getDataObject($conn, $sql);

            $out->userID = $user->userID;

            $out->userGuid = $user->userGuid;

            $_SESSION["userGuid"] = $user->userGuid;

            $this->getUserFromGuid($conn, $user->userGuid);
        }


        return $out;
    }


    public function createAccount($conn, $username, $email, $mobile, $password)
    {
        if ($this->debug)
            print "creating account\r";

        $this->lastErrorMsg = "";
        $this->userID = 0;
        $this->userGuid = "";

        if ($username == "")
            $this->lastErrorMsg = "Invalid Username";
        if ($email == "")
            $this->lastErrorMsg = "Invalid Email address";
        if ($mobile == "")
            $this->lastErrorMsg = "Invalid Mobile";
        if ($password == "")
            $this->lastErrorMsg = "Invalid Password";

        if (getKey($conn, "select count(*) from  " . $this->config["schema"] . "." . $this->config["table-prefix"] . "_user  where username = '$username'") > 0) {
            $this->lastErrorMsg = "User already exists";
        }

        if (getKey($conn, "select count(*) from  " . $this->config["schema"] . "." . $this->config["table-prefix"] . "_user  where mobile = '$mobile'") > 0) {
            $this->lastErrorMsg = "Mobile allready exists";
        }


        if (getKey($conn, "select count(*) from  " . $this->config["schema"] . "." . $this->config["table-prefix"] . "_user  where email = '$email'") > 0) {
            $this->lastErrorMsg = "Email allready exists";
        }



        if ($this->lastErrorMsg == "") {


            $sql = "insert into " . $this->config["schema"] . "." . $this->config["table-prefix"] . "_user 
                    (userGuid, userName, userPass, email, mobile, isGuestAccount) 
                    values (
                        UUID()
                        ,'$username'
                        ,MD5('$password')
                        ,'$email'
                        ,'$mobile'
                        ,'N'
                    )";

            if ($this->debug)
                print "SQL: $sql\r";

            executeQuery($conn, $sql);

            $user = getDataObject($conn, "select * from " . $this->config["schema"] . "." . $this->config["table-prefix"] . "_user where userName = '$username' order by userID desc");

            $this->userID = $user->userID;

            $this->userGuid = $user->userGuid;
        }


        return $this->userID;
    }


    public function createGuestAccount($conn, $userGuid)
    {
        if ($this->debug)
            $this->debug("creating guest account\r\n<br>");

        $numGuests = getKey($conn, "select count(*) from " . $this->config["schema"] . "." . $this->config["table-prefix"] . "_user where isGuestAccount = 'Y'");

        $userName = "Guest." . date("Ymd") . "." . $numGuests;

        $sql = "insert into " . $this->config["schema"] . "." . $this->config["table-prefix"] . "_user (userGuid, userName, isGuestAccount) values ('$userGuid', '$userName', 'Y')";

        executeQuery($conn, $sql);

        $sql = "select userID, userGuid, username from " . $this->config["schema"] . "." . $this->config["table-prefix"] . "_user where userGuid = '$userGuid'";

        if ($this->debug)
            $this->debug($sql);

        $data = getDataObject($conn, $sql);

        $this->userID = $data->userID;

        $this->userGuid = $data->userGuid;

        $this->username = $data->username;

        if ($this->debug) {
            $this->debug("Found UserID: $this->userID");
            $this->debug("Found userGuid: $this->userGuid");
            $this->debug("Found username: $this->username");
        }

        return $this->userID;
    }

    public function debug($msg)
    {
        print $msg . "\r\n<br>";
    }


    public function guidInUse($conn, $userGuid)
    {
        $sql = "select userID from " . $this->config["schema"] . ".mb_user where userGuid = '$userGuid'";

        $userID = getKey($conn, $sql);

        return $userID > 0;
    }

    public function standardReply($conn, $logSessionID, $out)
    {
        $sql = "select userID, userName, lastLogin,lastActivityDate from mb_user where userID = " . $out->auth->userID;

        $userObj = getDataObject($conn, $sql);

        $out->data->user = $userObj;

        header('Content-type: application/json');

        echo $out->generateOutput();
    }

    public function markActive($conn)
    {
        if ($this->userID > 0) {
            $sql = "update w_user set lastActivityDate = NOW() where userID = $this->userID";
            executeQuery($conn, $sql);
        }
    }


    public function generateOutput($conn)
    {
        $out = new stdClass();

        $sql = "select userID, userGuid, username, email, isGuestAccount 
                    from " . $this->config["schema"] . "." . $this->config["table-prefix"] . "_user 
                    where userGuid = '$this->userGuid'";

        $out = getDataObject($conn, $sql);

        $sql = "select * from pat_user_security where userID = $out->userID";
        $out->security = getDataObjects($conn, $sql);

        $sql = "select portfolioID from pat_trader_portfolio where userID = $out->userID";
        $out->portfolios = getDataObjects($conn, $sql);

        return $out;
    }


    public function resetPass($conn, $userData)
    {
        $out = new stdClass();
        $out->error = "";
        $out->message = "";
    
        // Validate Email
        if (empty($userData->email) || !filter_var($userData->email, FILTER_VALIDATE_EMAIL)) {
            $out->error = "Invalid Email address";
            return $out;    
        }
    
        // Check if email exists in the database
        $userExists = getKey($conn, "SELECT COUNT(*) FROM " . $this->config["schema"] . "." . $this->config["table-prefix"] . "_user WHERE email = '$userData->email'");
        if ($userExists == 0) {
            $out->error = "User Email not found";
            return $out;
        }
    
        try {


            include './super-admin/includes/mailconfig.php';

            // Email Settings
            $phpmailer->setFrom('survey@mg.surveysandbeyond.com', 'Survey Builder');
            $phpmailer->addAddress($userData->email);
            $phpmailer->addReplyTo('support@yourdomain.com', 'Support Team');
            $phpmailer->addCustomHeader("Return-Path: survey@mg.surveysandbeyond.com");
            
            // Generate Password Reset Link dynamically
            $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
            $host = $_SERVER['HTTP_HOST']; // get the host dynamically
            $base_url = $protocol . "://" . $host;
            $reset_password_path = "/survey-builder/client/update-password.html";
            
            // Generate full URL for password reset
            $password_reset_url = $base_url . $reset_password_path;
            
            $email = base64_encode($userData->email);
    
            // Email Content
            $phpmailer->isHTML(true);
            $phpmailer->Subject = 'Password Reset Link';
            $phpmailer->Body = "Dear {$userData->email},<br><br> 
                You have requested to reset your password. 
                <a href='$password_reset_url?email=$email'>Click here to reset your password.</a><br><br>
                If you did not request this, please ignore this email.<br><br>
                Regards,<br>
                Survey Builder";
    
            if ($phpmailer->send()) {
                $out->message = "Password reset link sent to {$userData->email}. Please check your email.";
            } else {
                $out->error = "Email could not be sent. Error: " . $phpmailer->ErrorInfo;
            }
    
        } catch (Exception $e) {
            $out->error = "PHPMailer Error: " . $phpmailer->ErrorInfo;
        }
    
        return $out;
    }


    public function forgotPasswordUser($conn, $userData)
    {
        $out = new stdClass();
        $out->error = "";
        $out->userID = 0;
        $out->userGuid = "";

        $this->lastErrorMsg = "";
        $this->userID = 0;
        $this->userGuid = "";


        if ($userData->email == "")
            $out->error = "Invalid Email address";
        if (!filter_var($userData->email, FILTER_VALIDATE_EMAIL)) {
            $out->error = "Invalid Email address";
        }
        $query = "SELECT count(*) FROM " . $this->config["schema"] . "." . $this->config["table-prefix"] . "_user WHERE email = ?";
        $stmt = $conn->prepare($query);
    
        if ($stmt === false) {
            $out->error = "Database query error";
            return $out;
        }

        if ($out->error == "") {
            $out->error = "";
            $phpmailer = new PHPMailer(true);

            setJsonResponseHeader(); // Set response as JSON

            // $response = [];
            
            try {
                 include '../super-admin/includes/mailconfig.php';

                
                // Enable debugging (only for troubleshooting)
                // $phpmailer->SMTPDebug = 2; // Uncomment for debugging
                // $phpmailer->Debugoutput = 'html';
                if (empty($userData->email) || !filter_var($userData->email, FILTER_VALIDATE_EMAIL)) {
                    $response = ['status' => 'error', 'message' => 'Invalid email address.'];
                    echo json_encode($response);
                    exit;
                }
            
                $phpmailer->setFrom('survey@mg.surveysandbeyond.com', 'Survey Builder');
                $phpmailer->addAddress($userData->email);
                $phpmailer->addReplyTo('support@yourdomain.com', 'Support Team');
                $phpmailer->addCustomHeader("Return-Path: survey@mg.surveysandbeyond.com");
            
                $base_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'];
                $reset_password_path = "/survey-builder/client/update-password.html";
                $password_reset_url = $base_url . $reset_password_path;
                $email = base64_encode($userData->email);
            
                $phpmailer->isHTML(true);
                $phpmailer->Subject = 'Password Reset Link';
                $phpmailer->Body = "Dear {$userData->email},<br><br> 
                    You have requested to reset your password. 
                    <a href='$password_reset_url?email=$email'>Click here to reset your password.</a><br><br>
                    If you did not request this, please ignore this email.<br><br>
                    Regards,<br>
                    Survey Builder";
            
                // Send Email
                
                $phpmailer->send();

                $out->message = "Password reset link sent to {$userData->email}. Please check your email.";
            } catch (Exception $e) {
                echo "Message could not be sent. Mailer Error: {$phpmailer->ErrorInfo}";
            }
            
            // Return response as JSON
            // echo json_encode($response);

        }
        return $out;
    }


    
    public function resetUser($conn, $userData)
    {
        $out = new stdClass();
        $out->error = "";
        $out->userID = 0;
        $out->userGuid = "";

        if ($this->debug)
            print "creating account\r";

        $this->lastErrorMsg = "";
        $this->userID = 0;
        $this->userGuid = "";
        $email = base64_decode($userData->email);


        if ($userData->newPassword == "")
            $out->error = "Invalid Password";
        if ($userData->confirmPassword == "")
            $out->error = "Invalid Confirm Password";

        if ($userData->newPassword != $userData->confirmPassword)
            $out->error = "Passwords do not match";


        if ($out->error == "") {

            $sql = "UPDATE " . $this->config["schema"] . "." . $this->config["table-prefix"] . "_user 
                        SET password = MD5('$userData->newPassword'),
                            modifiedDate = NOW()
                        WHERE email = '$email' ";

            if ($this->debug)
                print "SQL: $sql\r";

            executeQuery($conn, $sql);
        }

        return $out;
    }
    
}
