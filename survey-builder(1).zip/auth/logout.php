
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

///////////////////////////////////////////////////////// Prep
include "_includes.php";

$out = new DataPacket();

$auth = new Auth();

$out->data =  $auth->logout();

header('Content-type: application/json');

header('Content-type: application/json');

echo $out->generateOutput($auth);

/////////////////////////////////////////////////////////
?>