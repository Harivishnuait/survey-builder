function TestingApp()
{

  this.start = function()
  {
    utils.showView("view-home");
  }

  
  this.sendPrompt = function()
  {
    
    let prompt = document.getElementById("txt-prompt").value;

    var url = config.apiUrl + "survey-testing.php?action=get-response";
    url+="&prompt=" + prompt;

    utils.showView("view-spanner");
   
    dataHandler.sendDataAndCallBack(url, {},
      function(data)
      {
          console.log(data);

          var json = JSON.parse(data.response);

          var prettyJson = JSON.stringify(json, null, 2);

          document.getElementById("txt-response").value = prettyJson;

          utils.showView("view-home");

      });
  }

}

