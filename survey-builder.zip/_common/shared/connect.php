<?php
session_start();

$config = getAppConfig();

$_SESSION["prefix"] = $config["db_schema_name"];
$_SESSION["databaseName"] = $config["database"];
$_SESSION["userVarName"] = $config["userSessionVarName"];
$_SESSION["dbSchema"] = $config["database"];

if (array_key_exists($_SESSION["userVarName"], $_SESSION)) {
	$userID = $_SESSION[$_SESSION["userVarName"]];
} else {
	$userID = "";
}


$conn = @mysqli_connect($config["db_host"], $config["db_user"], $config["db_passwd"]);

if (@mysqli_connect_errno()) {
	$valid = "N";
	$errMsg = "There was an issue connecting with the database server";
	die($errMsg . " on " . basename(__FILE__) . "\r\n<br>");
} else {
	mysqli_select_db($conn, $config["database"]);

	if (@mysqli_connect_errno()) {
		$valid = "N";
		$errMsg = "There was an issue connecting with the database";
		die($errMsg . " on " . basename(__FILE__) . "\r\n<br>");
	}
}


function getUserID()
{
	return $_SESSION[$_SESSION["userVarName"]];
}


function executeQuery($con, $sql)
{
	$q = mysqli_query($con, switchTables($sql)) or die($sql . "<P>" . mysqli_error($con) . " on " . basename(__FILE__) . "\r\n<br>");

	return $q;
}


function getKey($con, $sql)
{
	$q = mysqli_query($con, switchTables($sql)) or die($sql . "<P>" . mysqli_error($con) . " on " . basename(__FILE__) . "\r\n<br>");

	$row = mysqli_fetch_row($q);

	if ($row) {
		return $row[0];
	}

	return "";
}


function getDataObject($con, $sql)
{
	$q = mysqli_query($con, switchTables($sql)) or die($sql . "<P>" . mysqli_error($con) . " on " . basename(__FILE__) . "\r\n<br>");

	$row = mysqli_fetch_object($q);

	return $row;
}


function switchTables($sql)
{
	return str_replace("mb_", $_SESSION["prefix"] . "_", $sql);
}

function varClean($value)
{
	$value = trim($value);

	$value = strip_tags($value);

	//$value = mysql_real_escape_string($value);

	return $value;
}


function dbClean($con, $value)
{
	$value = varClean($value);

	$value = mysqli_real_escape_string($con, $value);

	return $value;
}

function clean($conn, $value)
{
	return dbClean($conn, $value);
}


function cleanBreaks($value)
{
	$value = str_replace("\r\n", "", $value);
	$value = str_replace("\n", "", $value);
	return $value;
}

function getVar($varName)
{
	$val = "";

	if (array_key_exists($varName, $_GET)) {
		$val = $_GET[$varName];
	}

	if ($val == "" && array_key_exists($varName, $_POST)) {
		$val = $_POST[$varName];
	}

	if ($val == "" && isset($argv) && array_key_exists($varName, $argv)) {
		$val = $argv[1];
	}

	return $val;

}

function getSchema()
{
	return $_SESSION["dbSchema"];
}

function getDataArray($conn, $sql)
{

	$q = executeQuery($conn, $sql);

	$results = array();

	while ($line = mysqli_fetch_array($q)) {
		$results[] = $line;
	}

	return $results;
}


function getDataObjects($conn, $sql)
{

	$q = executeQuery($conn, $sql);

	$results = array();

	while ($line = mysqli_fetch_object($q)) {
		$results[] = $line;
	}

	return $results;
}

?>