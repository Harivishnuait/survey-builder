<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

///////////////////////////////////////////////////////// Prep
include "_includes.php";

$out = new DataPacket();

$dataOut = new stdClass();

$auth = new Auth();
$auth->fromSession($conn);

if($auth->isLoggedIn())
{
    $auth->logout();
}

$userData = new stdClass();

$userData->username = clean($conn, getVar("username"));
$userData->password = clean($conn, getVar("password"));
$userData->remember = clean($conn, getVar("remember"));

$out->data = $auth->loginUser($conn,$userData);

header('Content-type: application/json');

echo $out->generateOutput($auth);

/////////////////////////////////////////////////////////


?>