    <?php
    ///////////////////////////////////////////////////////// Prep
    include "_includes.php";

    require_once '../vendor/autoload.php';
    
    $out = new DataPacket();

    $auth = new Auth();

    $auth->fromSession($conn);

    $dataOut = new stdClass();

    ///////////////////////////////////////////////////////// Prep

    $surveyID = clean($conn, getVar("surveyID"));

    $survey = new Survey();

    $survey->loadFromDatabase($conn, $surveyID);

    $fileName = "survey-" . $survey->getSurveyGuid() . ".docx";
   
    ob_clean();
    
    $phpWord = new \PhpOffice\PhpWord\PhpWord();

    $wordSection = $phpWord->addSection();
    
    $wordSection->addText("Prompts", array('bold'=>true, 'size'=>12));

    $sql = "select * from survey_prompts_sent where surveyID = $surveyID order by surveyPromptID";

    $q = executeQuery($conn, $sql);

    while($prompt = mysqli_fetch_object($q))
    {
        $wordSection->addText($prompt->surveyPrompt);
        $wordSection->addText('');
        $wordSection->addText('');
    }


    $objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($phpWord, 'Word2007');
    header('Content-Type: application/octet-stream');
    header("Content-Disposition: attachment; filename=$fileName");
    $objWriter->save('php://output');
    exit;
    ?>