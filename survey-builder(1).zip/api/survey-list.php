<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

///////////////////////////////////////////////////////// Prep
include "_includes.php";

$out = new DataPacket();

$auth = new Auth();

$auth->fromSession($conn);

$dataOut = new stdClass();

///////////////////////////////////////////////////////// Prep

$survey = new Survey();

$sql = "select s.surveyID
                ,s.surveyName
                ,s.surveyDesc       
                ,s.modifiedDate
                ,IFNULL(hist.numVersions,1) as numVersions    
        from survey s
        left outer join (select surveyID, count(*) as numVersions from survey_history group by surveyID) as hist on hist.surveyID = s.surveyID
        where s.userID = " . $auth->getUserID() . "
        order by s.surveyID desc
        ";
        
$dataOut->surveys = getDataObjects($conn, $sql);

///////////////////////////////////////////////////////// Send Data

$out->data = $dataOut;

header('Content-type: application/json');

echo $out->generateOutput($auth);

/////////////////////////////////////////////////////////


?>