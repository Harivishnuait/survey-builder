<?php
if(!isset($globalFilesHaveBeenLoaded))
{
    $rootIncludePath = "../";
    include_once($rootIncludePath . "_common/shared/global-includes.php");
  
}
?>