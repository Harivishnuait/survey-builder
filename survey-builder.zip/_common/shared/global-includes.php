<?php

header('Access-Control-Allow-Origin: *');

header('Access-Control-Allow-Methods: GET, POST');

header("Access-Control-Allow-Headers: X-Requested-With");


$excludeSecurityCheck = true;

$rootPath = getcwd();
$idx = strpos($rootPath, "apps/");
$rootPath = substr($rootPath, 0, $idx);
$rootPath .= "../";

$executionStartTime = microtime(true);

include_once $rootPath . "_common/config/settings.php";

include_once $rootPath . "_common/shared/connect.php";

include_once $rootPath . "_common/classes/data-packet.php";

include_once $rootPath . "_common/classes/auth.class.php";

include_once $rootPath . "_common/classes/utils.class.php";

include_once $rootPath . "_common/shared/security-check.php";

include_once $rootPath . "_common/shared/logger.php";

include_once $rootPath . "_common/shared/global-actions.php";

include_once $rootPath . "_common/shared/global-utils.php";

$logSessionID = newLogSession($conn, $user->userID);

$debug = getVar(clean($conn, "debug"));

$debugKey = "app";

$action = getVar(clean($conn, "action"));


if ($debug != "" || $debug == "N") {
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);

} else {
    //$debug = "silent";
}

function debugIsOn($debug)
{
    if ($debug == "silent" || $debug == "")
        return false;

    return true;
}







$utils = new Utils();
$out = new DataPacket();
$auth = new Auth();

$auth->getUserFromGuid($conn, getVar(clean($conn, "userGuid")));

if ($userGuid) {
    $auth->getUserFromGuid($conn, $userGuid);

}

$auth->debug = $debug;
$config = getAppConfig();
//print_r($config);

$globalFilesHaveBeenLoaded = true;

if (@$debug) {
    debug("global-includes");
}


?>