<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

///////////////////////////////////////////////////////// Prep
include "_includes.php";

$out = new DataPacket();

$dataOut = new stdClass();

$auth = new Auth();
$auth->fromSession($conn);

if ($auth->isLoggedIn()) {
    $auth->logout();
}

$userData = new stdClass();
 
$userData->email = clean($conn, getVar("email"));
$userData->newPassword = clean($conn, getVar("newPassword"));
$userData->confirmPassword = clean($conn, getVar("confirmPassword"));

$out->auth->userID = $auth->getUserID();

$out->auth->userGuid = $auth->getUserGuid();

$out->data = $auth->resetUser($conn, $userData);

header('Content-type: application/json');

echo $out->generateOutput($auth);

/////////////////////////////////////////////////////////
