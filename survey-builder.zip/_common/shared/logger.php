<?php



function debug($msg)
{
  print $msg . "<br>\r\n";
}

function debugIt( $msg)
{
  print "$msg<P>\r\n"; 
}

function newLogSession($conn, $userID)
{

  if($userID > 0)
  {
    $sql = "insert into " . getSchema() . ".mb_log_session (userID) values ('$userID')";

    executeQuery($conn, $sql);

    $logSessionID = getKey($conn, "select max(logSessionID) from mb_log_session where userID = $userID");

  }
  else
  {
    $logSessionID = -1;
  }

  
  return $logSessionID;
}

function logIt($conn, $logSessionID, $printIt, $userID, $msg)
{
  if($printIt == true)
  {
    print "$msg<P>\r\n";
    $debugLevel = "verbose";
  }

  $sql = "insert into " . getSchema() . ".mb_log (logSessionID, debugLevel, userID, msg) values ('$logSessionID','$debugLevel','$userID','$msg')";
  
  executeQuery($conn, $sql);

  //print $sql;




}


function getLogs($conn, $logSessionID)
{
  $sql = "select logID, debugLevel, msg from " . getSchema() . ".mb_log where logSessionID = $logSessionID";
  $q = executeQuery($conn, $sql);
  $out = [];
  while($data = $q->fetch_object())
  {
      array_push($out, $data->msg);
  }

  return $out;
}
?>