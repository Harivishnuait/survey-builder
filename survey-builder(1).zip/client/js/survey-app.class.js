function SurveyApp()
{
  this.currSurveyID = 0;

  this.maxNumSections = 10;

  this.surveyParams = {}; //see clearAllFields()

  this.screenOrder = ["view-create-survey"
                    ,"view-pharse-survey"
                    ,"view-domain-survey"
                    ,"view-survey-type"
                    ,"view-loi-calc"
                    ,"view-target-audience"];
  this.currScreenIdx = 0;

  this.staticLists = {};

  this.survey ={};


  /////////////////////////////////////////////////////////////////////////////////////////////////////////
  //
  // Main Action Functions
  //
  /////////////////////////////////////////////////////////////////////////////////////////////////////////
  this.start = function()
  {
    document.getElementById("lbl-username").innerHTML = user.username;
    
    this.currScreenIdx = 0;

    var goStrightToSurvey = this.autoLoadSurvey();
    
    if(!goStrightToSurvey)
    {
      this.loadSurveyList();
    }

    console.log("Ready...");
  }

  
  this.autoLoadSurvey = function()
  {
    var url = new URL(window.location);

    var surveyID = url.searchParams.get("surveyID");

    if(surveyID == null || surveyID == undefined)
    {
      surveyID = "";
    }

    if(surveyID != "")
    {

      console.log("Survey ID found in url - Loading");

      this.loadSurvey(surveyID);
      

      return true;
    }

    return false;

  }
  
  
  this.startNewSurvey = function()
  { 
    document.getElementById("lbl-username").innerHTML = user.username;
    
    this.currScreenIdx = 0;
    
    var goStrightToSurvey = this.autoLoadSurvey();
    
    if(!goStrightToSurvey)
    {
      utils.showView("view-edit-research-goals");
    }

    console.log("Ready...");
  }

    
  this.loadSurvey = function(surveyID)
  {
        console.log("Loading Survey: " + surveyID);
        
        var url = config.apiUrl + "survey-get.php?surveyID=" + surveyID;
   
        utils.showView("view-edit-survey");

        document.getElementById("view-edit-survey-content").innerHTML = "";
        
        dataHandler.sendDataAndCallBack(url, {},
            function(data) {
                surveyApp.survey = data.survey;
                
                surveyApp.currSurveyID = surveyID;

                console.log("survey",data.survey);

                surveyApp.checkSurveyStatus();
                
                surveyApp.refreshSurveyView();

                
      });
  }

 
  this.loadSurveyList = function()
  {
    var url = config.apiUrl + "survey-list.php?";

    utils.showView("view-survey-list");

    dataHandler.sendDataAndCallBack(url, {},
      function(data)
      {
        
          
        var html = "<table class='table table-hover' style='width:100%;'>";
        html+="<tbody>";

        for(var i=0;i<data.surveys.length;i++)
        {
            var row = data.surveys[i];

            html+="<tr onclick=\"window.location.href='edit-survey.php?surveyID=" + row["surveyID"] + "'\">";
            html+="<td><b>" + row["surveyName"]  + "</b>";
            html+="<div class='survey-desc'>" + row["surveyDesc"] + "</div>";   
            html+="<div class='survey-info'>Versions: " + row["numVersions"] + " | Last Updated: " + utils.formatSqlDate(row["modifiedDate"]) + "</div>";   
            html+="</td>";
            html+="</tr>";

            html+="<tr><td>";
            html+="<table style='border:0px'><tr>";
            html+="<td><div style='width:100px;'><a class='btn btn-primary' href='edit-survey.php?surveyID=" + row["surveyID"] + "'>Edit</a></div></td>";
            //html+="<td><div style='width:100px;'><a class='btn btn-primary' href='javascript:surveyApp.shareSurvey(" + row["surveyID"] + ")''>Share</a></div></td>";
            html+="<td><div style='width:100px;'><a class='btn btn-primary' href='javascript:surveyApp.exportToHtml(" + row["surveyID"] + ")''>Share</a></div></td>";
            html+="</tr></table>";
            html+="</td></tr>";
        }

        html+="</tbody>";
        html+="</table>";
        
        document.getElementById("div-survey-list").innerHTML = html;

      });

  }



  this.saveObjective = function()
  {
    var url = config.apiUrl + "survey-edit.php?";
    url+="action=save-objective";
    url+="&survey-id=" + this.currSurveyID;
    url+="&objective-text=" + document.getElementById("txt-survey-objective-desc").value;
    url+="&objective-title=" + document.getElementById("txt-survey-objective-title").value;

    dataHandler.sendDataAndCallBack(url, {},
      function(data)
      {          
          //surveyApp.loadEditSurvey(surveyApp.currSurveyID);

          toastr.success("Answer was updated!");
      });
  
  }


  ////////////////////////////////////////////////////////////////////////////////////////////////
  //
  //              Refreshing and Showing Views
  //
  ////////////////////////////////////////////////////////////////////////////////////////////////
  

  this.refreshSurveyView = function()
  {
    var finalHtml = '<div>';

    finalHtml+= surveyApp.genHeaderHtml();
    
    finalHtml+= surveyApp.genObjectiveHtml();

    for(var i=1;i<surveyApp.survey.sections.length;i++)
    {
      var section = surveyApp.survey.sections[i];

      finalHtml+= surveyApp.genViewSection(surveyApp.survey.surveyID, i, section);
    }

    finalHtml+="</div>";  //close accordian div

    document.getElementById("view-edit-survey-content").innerHTML = finalHtml;

    surveyApp.loadMenu();

    
  }

  this.showFacts = function()
  {
    utils.showView("view-edit-facts");

    var url = config.apiUrl + "survey-get-facts.php?surveyID=" + this.currSurveyID;


    dataHandler.sendDataAndCallBack(url, {},
      function(data)
      {          
         var finalHtml = "";

         for(var i=0;i<data.facts.length;i++)
         {
            var fact = data.facts[i];

            var html = document.getElementById("template-fact").innerHTML;

            html = html.replaceAll("[FACT_ID]",fact.factID);
            html = html.replaceAll("[QUESTION]",fact.factQuestion);
            html = html.replaceAll("[ANSWER]",fact.factAnswer);

            finalHtml+=html;
         }

         
         document.getElementById("view-edit-facts-content").innerHTML = finalHtml;

      });
  }

  this.updateFact = function(factID)
  {
    var url = config.apiUrl + "survey-update-fact.php?surveyID=" + this.currSurveyID;
    url+="&factID=" + factID;
    url+="&answer=" + document.getElementById("answer-" + factID).value;

    dataHandler.sendDataAndCallBack(url, {},
      function(data)
      {          
        toastr.success("Input updated!");

      });
  }

  this.loadMenu = function()
  {
    var finalHtml = "";

    var html = document.getElementById("template-side-menu-item").innerHTML;
    html = html.replaceAll("[LINK]","index.html");
    html = html.replaceAll("[LABEL]","Home");
    finalHtml+=html;

    html = document.getElementById("template-side-menu-item").innerHTML;
    html = html.replaceAll("[LINK]","javascript:surveyApp.showFacts();");
    html = html.replaceAll("[LABEL]","You Said...");
    finalHtml+=html;

    html = document.getElementById("template-side-menu-item").innerHTML;
    html = html.replaceAll("[LINK]","javascript:surveyApp.openAddSection();");
    html = html.replaceAll("[LABEL]","Add Section");
    finalHtml+=html;

    html = document.getElementById("template-side-menu-item").innerHTML;
    html = html.replaceAll("[LINK]","javascript:surveyApp.exportToHtml(" + this.currSurveyID + ");");
    html = html.replaceAll("[LABEL]","Export");
    finalHtml+=html;

    
    
    for(var i=0;i<this.survey.sections.length;i++)
    {
        var section = this.survey.sections[i];

        var label = section.moduleTitle.substring(0,30);

        html = document.getElementById("template-side-menu-item-small").innerHTML;
        html = html.replaceAll("[LINK]","#section-" + i);
        html = html.replaceAll("[LABEL]", label);
        finalHtml+=html;

    }

    finalHtml+="";

    document.getElementById("side-menu-nav").innerHTML = finalHtml;

  

  }
  

  
  this.genHeaderHtml = function(survey)
  {

    var html = document.getElementById("template-survey-header").innerHTML;

    html = html.replace("[LOI]", this.survey.loi + " Min");

    html = html.replace("[RI]","60%");
    
    return html;
  }


  this.genObjectiveHtml = function()
  {

    var html = document.getElementById("template-statement-section").innerHTML;

    var editAction = "surveyApp.saveObjective()";

    var textBoxHeight = "40px";

    if(this.survey.description.length >=200)
    {
      textBoxHeight = "150px;"
    }

    html = html.replace("[ANCHOR]","section-0");
    html = html.replace("[TEXT_BOX_HEIGHT]",textBoxHeight);
    html = html.replace("[TITLE_ID]","txt-survey-objective-title");
    html = html.replace("[DESC_ID]","txt-survey-objective-desc");
    html = html.replace("[TITLE]",this.survey.title);
    html = html.replace("[BODY]", this.survey.description);
    html = html.replace("[DESC_EDIT_ACTION]", editAction);
    html = html.replace("[TITLE_EDIT_ACTION]", editAction);

    return html;
  }

  
  this.genViewSection = function(surveyID, sectionIdx, section)
  {
    console.log("Section-" + sectionIdx, section);

    var html = document.getElementById("template-default-section").innerHTML;

    if(section.title == null)
    {
      section.title="Section";
    }


    if(section.description == null)
    {
      section.description = "Please answer the following questions:";
    }

    var textBoxHeight = "40px";

    if(section.description.length >=200)
    {
      textBoxHeight = "80px;"
    }

    html = html.replaceAll("[SECTION_IDX]",sectionIdx);
    
    html = html.replaceAll("[IDX]","section-" + sectionIdx);

    html = html.replace("[ANCHOR]","section-" + sectionIdx);
    
    html = html.replace("[TITLE_ID]","section-title-" + sectionIdx);
    
    html = html.replace("[TITLE]",section.title);

    html = html.replace("[DESC_ID]","section-desc-" + sectionIdx);

    html = html.replace("[DESC]", section.description);

    html = html.replace("[TEXT_BOX_HEIGHT]",textBoxHeight);
    

    var editAction = "surveyApp.saveSectionHeader(" + sectionIdx + ")";
    
    html = html.replaceAll("[EDIT_ACTION]",editAction);

    var questionHtml = "";

    var questions = section.questions;



    for (var questionIdx = 0; questionIdx < questions.length; questionIdx++) 
    {
      var q = questions[questionIdx];

      var qHtml = "";

      var qHtml = document.getElementById("template-single-choice-question").innerHTML;
      
      var editAction = "surveyApp.saveQuestion(" + surveyID + "," + sectionIdx + "," + questionIdx + ");";
      var rewordAction = "surveyApp.rewordQuestion(" + surveyID + "," + sectionIdx + "," + questionIdx + ");";
      var removeAction = "surveyApp.removeQuestion(" + surveyID + "," + sectionIdx + "," + questionIdx + ");";
      qHtml = qHtml.replaceAll("[SECTION_IDX]",sectionIdx);
      qHtml = qHtml.replaceAll("[QUESTION_IDX]",questionIdx);
      qHtml = qHtml.replaceAll("[QUESTION_TYPE]",q.question_type);
      qHtml = qHtml.replaceAll("[IDX]", "question-" + sectionIdx + "-" + questionIdx);
      qHtml = qHtml.replaceAll("[ID]", "question_" + surveyID + "_" + sectionIdx + "_" + questionIdx);
      qHtml = qHtml.replaceAll("[QUESTION_NUM]", q.question_num + 1);
      qHtml = qHtml.replaceAll("[QUESTION_TEXT]", q.question_text);
      qHtml = qHtml.replaceAll("[EDIT_ACTION]", editAction);
      qHtml = qHtml.replaceAll("[REWORD_ACTION]", rewordAction);
      qHtml = qHtml.replaceAll("[REMOVE_ACTION]", removeAction);
      

      if(q.question_type == "Free Text")
      {
        var aHtml = document.getElementById("template-free-text-answer").innerHTML;
        
        qHtml+=aHtml;
      }

      if(q.answers.length <= 0)
      {
        qHtml = qHtml.replaceAll("[ANSWERS]", "");
      }


      if(["Rating Scale","Ranking"].includes(q.question_type))
      {
        //var aHtml = document.getElementById("template-rating-scale-answer").innerHTML;

        var scaleHtml = "<table style='width:100%'>";
        scaleHtml+="</tr>";

        for(var j=0;j<q.answers.length;j++)
        {
          var answer = q.answers[j];
          scaleHtml+="<td style=\"text-align:'center';\"><a class='btn btn-primary' href=''>" + answer.answer_text + "</a></td>";
          
          
        }

        scaleHtml+="</tr></table>";

        qHtml = qHtml.replaceAll("[ANSWERS]", scaleHtml);
      }


      if(["Yes or No","","Multiple Choice","Single Choice"].includes(q.question_type))
      {
        var aHtml = "";

        for(var j=0;j<q.answers.length;j++)
        {
          var answer = q.answers[j];

          aHtml+= document.getElementById("template-single-choice-answer").innerHTML;

          var editAction = "surveyApp.saveAnswer(" + surveyID + "," + sectionIdx + "," + questionIdx + "," + j + ");";
          var removeAction = "surveyApp.removeAnswer(" + surveyID + "," + sectionIdx + "," + questionIdx + "," + j + ");";
          var notesAction = "surveyApp.saveNotes(" + surveyID + "," + sectionIdx + "," + questionIdx + "," + j + ");";
      
          var programmingNotes = "";
          for(var k=0;k<answer.programming_notes.length;k++)
          {
            programmingNotes+=answer.programming_notes[k] + "\r\n";
          }

          aHtml = aHtml.replaceAll("[IDX]", (i+j));
          aHtml = aHtml.replaceAll("[ANSWER_ID]", "answer-text-" + surveyID + "-" + sectionIdx + "-" + questionIdx + "-" + j);
          aHtml = aHtml.replaceAll("[ANSWER_NOTE_ID]", "answer-note-" + surveyID + "-" + sectionIdx + "-" + questionIdx + "-" + j);
          aHtml = aHtml.replaceAll("[ANSWER_TEXT]", answer.answer_text);
          aHtml = aHtml.replaceAll("[ANSWER_NOTE_TEXT]", programmingNotes);
          aHtml = aHtml.replaceAll("[ANSWER_EDIT_ACTION]", editAction);
          aHtml = aHtml.replaceAll("[ANSWER_DELETE_ACTION]", removeAction);
          aHtml = aHtml.replaceAll("[ANSWER_EDIT_NOTE_ACTION]", notesAction);
          
          
          
        }

        qHtml = qHtml.replaceAll("[ANSWERS]", aHtml);
      }

      questionHtml += qHtml;


      //surveyApp.saveAnswer(1,1,0,0);
      //surveyApp.removeAnswer(1,1,0,0)
    }

    html = html.replace("[QUESTIONS]", questionHtml);

    //for(var i=0;i<section.length)
    return html;
  }

  this.shareSurvey = function(surveyID)
  {
    this.currSurveyID = surveyID;

    utils.showView('view-survey-share');
  }


  this.createShareableLink = function()
  {
    var url = config.rootUrl + "/survey-display.php?id=" + this.currSurveyID;
    
    window.open(url, '_blank');
     
  }

  this.createExport = function(exportType)
  {
    var url = config.apiUrl + "/survey-export-pdf.php?surveyID=" + this.currSurveyID;;

    if(exportType == "HTML")
    {
      url = config.apiUrl + "/survey-export-html.php?surveyID=" + this.currSurveyID;
    }

    if(exportType == "PDF")
    {
      url = config.apiUrl + "/survey-export-pdf.php?surveyID=" + this.currSurveyID;
    }

    if(exportType == "WORD")
    {
      url = config.apiUrl + "/survey-export-word.php?surveyID=" + this.currSurveyID;
    }
      
    if(exportType == "EXCEL" || exportType == 'CSV')
    {
      url = config.apiUrl + "/survey-export-excel.php?surveyID=" + this.currSurveyID;
    }

    if(exportType == "JSON")
    {
      url = config.apiUrl + "/survey-export-json.php?surveyID=" + this.currSurveyID;
    }

    if(exportType == "PROMPTS")
    {
      url = config.apiUrl + "/survey-export-prompts.php?surveyID=" + this.currSurveyID;
    }    
      

    window.open(url, '_blank');

  }
 

  
  this.exportToHtml = function(surveyID)
  {
    var url = config.apiUrl + "/survey-export-html.php?surveyID=" + surveyID;

    window.open(url, '_blank');

  }
 


  this.showSpinner = function()
  {
    this.showLoading("Hang on, we are working on it...");
  }

  ////////////////////////////////////////////////////////////////////////////////////////////////
  //
  //              EDIT SURVEY
  //
  ////////////////////////////////////////////////////////////////////////////////////////////////
  
  this.saveGeneralInfo = function()
  {
    let surveyName = $("#survey-name").val();

    let researchGoals = $("#research-goals").val();

    let divBrandListHTML = $("#div-brand-list").text();

    let divAttributesListHTML = $("#div-attributes-list").text();

    var error ='';      
    
    if(surveyName)
    {
      document.getElementById("survey_name-error").style.display = "none";   
    }
    else
    {
      $("#survey_name-error").css("display","block");
      var error = 1;
    }


    if(researchGoals)
    {
      document.getElementById("research-goals-error").style.display = "none";            
    }
    else
    {
      $("#research-goals-error").css("display","block");
      var error = 1;   
    }

    this.surveyParams.surveyName = surveyName;

    this.surveyParams.researchGoals = researchGoals;
    
    var surveyTypes = document.getElementsByName("survey-type");

    for (var index = 0; index < surveyTypes.length; index++) 
    {
      if (surveyTypes[index].checked) 
      {
        this.surveyParams.surveyType = surveyTypes[index].value;
      }
    }
    
    
    console.log("Survey Params", this.surveyParams);

    if(error != 1)
    {
      this.createSurvey();
    }
    
  }



  this.createSurvey = function()
  {
    
    let researchGoals = this.cleanInput(this.surveyParams.researchGoals);
    let surveyName = this.cleanInput(this.surveyParams.surveyName);
    let surveyType = this.cleanInput(this.surveyParams.surveyType);
    
    var url = config.apiUrl + "survey-create.php?";
    url+="&researchGoals=" + researchGoals;
    url+="&surveyName=" + surveyName;
    url+="&surveyType=" + surveyType;

    this.showLoading("Creating Survey...");

    dataHandler.sendDataAndCallBack(url, {},
      function(data)
      {
        try{
          console.log("Survey Created", data);
          
          window.location.href = "edit-survey.php?surveyID=" + data.survey.surveyID;          
        }
        catch(err) {
          console.log("Data Transfer Error");
          console.log(err.message);            
          surveyApp.showError("Oh No, Something went wrong...")
        }
        
      });
  }


  this.selectDomain = function()
  {
    var url = config.apiUrl + "survey-get-statics.php?";

    this.showLoading("Getting Domain Lists...");

    dataHandler.sendDataAndCallBack(url, {},
      function(data)
      {
        surveyApp.staticLists = data;
        
        var finalHtml = "";

        for(var index=0;index<surveyApp.staticLists.domainStatus.length;index++)
        {
            var domain = surveyApp.staticLists.domainStatus[index];

            var html = document.getElementById("template-domain").innerHTML;

            html = html.replaceAll("[ID]", domain.domainKey );
            html = html.replaceAll("[LABEL]", domain.domainTitle);
            html = html.replaceAll("[DESC]", domain.domainDesc);
            html = html.replaceAll("[SUGGESTION]", domain.domainPromptQuestion);
            html = html.replaceAll("[ACTION]", "surveyApp.saveDomain('" + domain.domainKey + "')");
            
            finalHtml+=html;
        }


        document.getElementById("view-domain-select-contents").innerHTML = finalHtml;     
      
        utils.showView("view-domain-select");

      });
  }



  this.saveDomain = function(domainKey)
  {

    
    var url = config.apiUrl + "survey-save-domain.php?";
    url+="&surveyID=" + this.survey.surveyID;
    url+="&domainKey=" + domainKey;
    url+="&desc=" + document.getElementById("domain-input-" + domainKey).value;
    

    dataHandler.sendDataAndCallBack(url, {},function(data)
    {  
      console.log(data);      

      surveyApp.loadSurvey(surveyApp.survey.surveyID);

    });

  }


  this.createScreenerSection = function()
  {
    utils.showView("view-screener-section-edit");
    
  }

  this.checkSurveyStatus = function()
  {
    var hasScreenerSection = false;
    var domainIsSelected = false;

    for(var i=0;i<this.survey.sections.length;i++)
    {
      section = this.survey.sections[i];

      if(section.sectionType == "screener")
      {
        hasScreenerSection = true;
      }
    }

    if(this.survey.params.domains.length > 0)
    {
      domainIsSelected = true;
    }

    if(!domainIsSelected)
    {
      this.selectDomain();
      return;
    }
      
    if(!hasScreenerSection)
    {
      this.createScreenerSection();
      return;
    }


  }

  
  this.removeSurvey = function()
  {
    var url = config.apiUrl + "survey-remove.php?";

    url+="survey-id=" + this.currSurveyID;

    dataHandler.sendDataAndCallBack(url, {},
      function(data)
      {          
          surveyApp.loadSurveyList();

      });
  }  


  ////////////////////////////////////////////////////////////////////////////////////////////////
  //
  //              Adding Modules
  //
  ////////////////////////////////////////////////////////////////////////////////////////////////

  this.openAddSection = function()
  {
    utils.showView("view-add-section");

    this.getAvailSections();
  }
  

  this.getAvailSections = function( )
  {
    
    var url = config.apiUrl + "survey-get-avail-sections.php?surveyID=" + this.survey.surveyID;

    dataHandler.sendDataAndCallBack(url, {},
      function(data)
      {
        
        surveyApp.surveyAvailSections = data.surveySections;

        var finalHtml = "";

        for(var i=0;i<data.surveySections.length;i++)
        {
            var section = data.surveySections[i];

            var html = document.getElementById("template-add-section").innerHTML;

            html = html.replaceAll("[ID]", section.moduleCategoryID);
            html = html.replaceAll("[CATEGORY_IDX]", i);
            html = html.replaceAll("[LABEL]", section.moduleCategoryTitle);
            html = html.replaceAll("[SECTION_DESC]", section.moduleCatetgoryDescription);
            html = html.replaceAll("[SECTION_HUMAN_PROMPT]", section.moduleCategoryPromptForHuman);
            html = html.replaceAll("[SUGGESTION]", section.moduleCategorySuggestion);
            
            var moduleHtml = "<table style='width:100%;'><tr style='font-weight:bold;'><td>Areas</td><td  style='text-align:right;'>Num Questions</td></tr>";
            
            for(var j=0;j<section.modules.length;j++)
            {
              var module = section.modules[j];

              moduleHtml+= "<tr>";
              moduleHtml+= "  <td>" + module.moduleTitle + "</td>";
              moduleHtml+= "  <td style='text-align:right;'><input id='module_questions_" + module.moduleID + "' value='3' style='width: 50px;text-align: center;'></td>";
              moduleHtml+= "<tr>";

            }

            moduleHtml+="</table>";

            html = html.replaceAll("[MODULE_LIST]", moduleHtml);
            
            finalHtml+=html;
        }
    
        document.getElementById("view-add-section-contents").innerHTML = finalHtml;
    
      });


  }

  
  this.addModule = function(moduleCatIdx)
  {
    var section = this.surveyAvailSections[moduleCatIdx];

    var url = config.apiUrl + "survey-add-module.php?surveyID=" + this.survey.surveyID;
    url+="&moduleCategoryID=" + section.moduleCategoryID;
    url+="&answer=" + document.getElementById("section-input-" + section.moduleCategoryID).value;

    this.showLoading("Adding Module...");

    for(var i=0;i<section.modules.length;i++)
    {
      var module = section.modules[i];
      url+="&num_questions_" + module.moduleID + "=" + document.getElementById("module_questions_" + module.moduleID).value;

    }

    console.log(url);

    
    dataHandler.sendDataAndCallBack(url, {},
      function(data)
      {
        
        surveyApp.loadSurvey(surveyApp.survey.surveyID);
    
      });


  }





  
  ////////////////////////////////////////////////////////////////////////////////////////
  //
  // Target Audience Attributes
  //
  ///////////////////////////////////////////////////////////////////////////////////////

  
  this.saveTargetAudience = function(){

    if ($("#target-audience-field").val() === '') {
      $('#target-audience-error').css('display', 'block');
      return;
    } else {
        $('#target-audience-error').css('display', 'none');
    }

    surveyApp.surveyParams.targetAudienceDesc = $("#target-audience-field").val();
    
    let surveyJSON = JSON.stringify(surveyApp.surveyParams);

    this.showLoading("Creating Screener Questions...");

    var url = config.apiUrl + "get-target-audience.php?";
    url+="&surveyID=" + this.survey.surveyID;
    url+="&numQuestions=5";
    url+="&targetAudienceDesc=" + $("#target-audience-field").val();
    

    dataHandler.sendDataAndCallBack(url, {},function(data)
    {  
      console.log(data);      

      surveyApp.loadSurvey(surveyApp.survey.surveyID);

    });

  }






  ////////////////////////////////////////////////////////////////////////////////////////////////
  //
  //              Question Functions
  //
  ////////////////////////////////////////////////////////////////////////////////////////////////

  this.saveQuestion = function(surveyID, sectionIdx, questionIdx)
  {
    var url = config.apiUrl + "survey-edit.php?";
    url+="action=save-question";
    url+="&survey-id=" + this.currSurveyID;
    url+="&section-idx=" + sectionIdx;
    url+="&question-idx=" + questionIdx;
    url+="&question-text=" + document.getElementById("question_" + surveyID + "_" + sectionIdx + "_" + questionIdx).value;

    dataHandler.sendDataAndCallBack(url, {},
      function(data)
      {          
          //surveyApp.loadEditSurvey(surveyApp.currSurveyID);
          toastr.success("Question saved!");
      });
  }

  
  this.rewordQuestion = function(surveyID, sectionIdx, questionIdx)
  {

    var url = config.apiUrl + "survey-reword.php?";
    url+= "&survey-id=" + surveyID;
    url+= "&section-idx=" + sectionIdx;
    url+= "&question-idx=" + questionIdx;

    this.showSpinner();

    dataHandler.sendDataAndCallBack(url, {},
      function(data)
      {
        toastr.success("Question Reworded, Survey Reloaded");

        surveyApp.loadSurvey(data.survey.surveyID);

      });
  }



  this.removeQuestion = function(surveyID, sectionIdx, questionIdx)
  {
    var url = config.apiUrl + "survey-remove-question.php?";
    url+="survey-id=" + this.currSurveyID;
    url+="&section-idx=" + sectionIdx;
    url+="&question-idx=" + questionIdx;

    this.showSpinner();

    dataHandler.sendDataAndCallBack(url, {},
      function(data)
      {          
        toastr.success("Question Removed, Survey Reloaded");

        surveyApp.loadSurvey(data.surveyID);

      });
  }    


  
  this.addQuestion = function(sectionIdx, questionType)
  {
    var url = config.apiUrl + "survey-add-question.php?";
    url+="survey-id=" + this.currSurveyID;
    url+="&section-idx=" + sectionIdx;
    url+="&question-type=" + questionType;

    this.showSpinner();

    dataHandler.sendDataAndCallBack(url, {},
      function(data)
      {          
        
        surveyApp.loadSurvey(surveyApp.currSurveyID);

        toastr.success("Question Added, Survey Reloaded");

      });
  }    




  
  ////////////////////////////////////////////////////////////////////////////////////////////////
  //
  //              Answer Functions
  //
  ////////////////////////////////////////////////////////////////////////////////////////////////

  this.saveAnswer = function(surveyID, sectionIdx, questionIdx, answerIdx)
  {
    var url = config.apiUrl + "survey-edit.php?";
    url+="action=save-answer";
    url+="&survey-id=" + this.currSurveyID;
    url+="&question-idx=" + questionIdx;
    url+="&section-idx=" + sectionIdx;
    url+="&answer-idx=" + answerIdx;
    url+="&answer-text=" + document.getElementById("answer-text-" + this.currSurveyID + "-" + sectionIdx + "-" + questionIdx + "-" + answerIdx).value;

    dataHandler.sendDataAndCallBack(url, {},
      function(data)
      {          
          toastr.success("Answer was updated!");
      });
  }

  
  this.removeAnswer = function(surveyID, sectionIdx, questionIdx, answerIdx)
  {
    var url = config.apiUrl + "survey-edit.php?";
    url+="action=remove-answer";
    url+="&survey-id=" + this.currSurveyID;
    url+="&question-idx=" + questionIdx;
    url+="&section-idx=" + sectionIdx;
    url+="&answer-idx=" + answerIdx;

    this.showSpinner()

    dataHandler.sendDataAndCallBack(url, {},
      function(data)
      {          
          toastr.success("Answer was removed!");

          surveyApp.loadSurvey(surveyApp.currSurveyID);

      });
  }

  
  this.addAnswer = function(sectionIdx, questionIdx)
  {
    var url = config.apiUrl + "survey-add-answer.php?";
    url+="survey-id=" + this.currSurveyID;
    url+="&section-idx=" + sectionIdx;
    url+="&question-idx=" + questionIdx;

    this.showSpinner();

    dataHandler.sendDataAndCallBack(url, {},
      function(data)
      {          
        
        surveyApp.loadSurvey(surveyApp.currSurveyID);

        toastr.success("Question Added, Survey Reloaded");

      });
  }    


  ////////////////////////////////////////////////////////////////////////////////////////////////
  //
  //              Notes Functions
  //
  ////////////////////////////////////////////////////////////////////////////////////////////////
  
  
  this.saveNotes = function(surveyID, sectionIdx, questionIdx, answerIdx)
  {
    var url = config.apiUrl + "survey-edit.php?";
    url+="action=save-notes";
    url+="&survey-id=" + this.currSurveyID;
    url+="&question-idx=" + questionIdx;
    url+="&section-idx=" + sectionIdx;
    url+="&answer-idx=" + answerIdx;
    url+="&answer-notes=" + document.getElementById("answer-note-" + this.currSurveyID + "-" + sectionIdx + "-" + questionIdx + "-" + answerIdx).value;

    dataHandler.sendDataAndCallBack(url, {},
      function(data)
      {          
          toastr.success("Programming Notes updated!");
      });
  }




  ////////////////////////////////////////////////////////////////////////////////////////////////
  //
  //              Utility Functions
  //
  ////////////////////////////////////////////////////////////////////////////////////////////////
  
  
  this.showProgrammingNotes = function(divID)
  {
    var d = document.getElementById(divID);
    if(d.style.display == "")
    {
      d.style.display = "none";
      d.style.visibility = "hidden";

    }
    else
    {
      d.style.display = "";
      d.style.visibility = "visible";
    }
  }
  
  
  this.showError = function(msg)
  {
    this.showLoading(msg + "...<a href='index.html'>continue</a>");
  }

  this.showLoading = function(msg) 
  {

    document.getElementById("loader-text").innerHTML = msg;
    
    utils.showView("view-spanner");
  
  }

  this.cleanInput = function(val)
  {
    val = val.replace(/\\n/g, "\\n")
                          .replace(/\\'/g, "\\'")
                          .replace(/\\"/g, '\\"')
                          .replace(/\\&/g, "\\&")
                          .replace(/\\r/g, "\\r")
                          .replace(/\\t/g, "\\t")
                          .replace(/\\b/g, "\\b")
                          .replace(/\\f/g, "\\f")
                          .replace(/\\%/g, "\\percent")
                          .replace(/\\&/g, "\\and");

    return val;
  }
























}



