<?php
///////////////////////////////////////////////////////// Prep
include "_includes.php";

$out = new DataPacket();

$auth = new Auth();

$auth->fromSession($conn);

$dataOut = new stdClass();

///////////////////////////////////////////////////////// Prep
$surveyID = clean($conn, getVar("surveyID"));

$sql = "select * from survey_facts where surveyID = $surveyID";

if($debug == "Y") debug($sql);

$dataOut->facts = getDataObjects($conn, $sql);

///////////////////////////////////////////////////////// Send Data

$out->data = $dataOut;

header('Content-type: application/json');

echo $out->generateOutput($auth);

/////////////////////////////////////////////////////////
?>