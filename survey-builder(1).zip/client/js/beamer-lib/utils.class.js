function BeamerUtils()
{
    
  this.getUrlParams = function()
  {
    var url = window.location.href;

    var queryString = url.split('?')[1];

    var vars = {};

    var pairs = queryString.split('&');

    // Loop through the pairs and populate the vars object
    for (var i = 0; i < pairs.length; i++) {
        var pair = pairs[i].split('=');
        vars[pair[0]] = decodeURIComponent(pair[1]);
    }

    return vars;
  }


    this.createGuid = function() {
        return ([1e7]+-1e3+-4e3+-8e3+-1e11).replace(/[018]/g, c =>
          (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
        );
      }
    

    this.growl = function(msg, showTimeSecs)
    {
      var d = document.getElementById("div-growl");
      
      if(!d)
      {
        console.error("Growl div does not exists");
        return;
      }

      d.style.visibility = "visible";
      
      document.getElementById("div-growl-contents").innerHTML = msg;

      window.setTimeout(utils.hideGrowl, showTimeSecs * 1000);

    }

    this.hideGrowl = function()
    {
      var d = document.getElementById("div-growl");
      
      if(!d)
      {
        console.error("Growl div does not exists");
        return;
      }

      d.style.visibility = "hidden";
    }
      
    this.showView = function(viewID)
    {
      var elements = document.getElementsByClassName("view");

      for(i=0;i<elements.length;i++)
      {
        elements[i].style.visibility = "hidden";
        elements[i].style.display = "none";
      }

      var d = document.getElementById(viewID);
      d.style.visibility = "visible";
      d.style.display = "block";

      console.log("Showing View: " + viewID);

    }

    this.buildTable = function(data, options)
    {
      var html = "<table class='table table-hover' style='width:100%;'>";
      html+= "<thead>";
      html+="<tr>";

      for (var prop in data[0]) 
      {
        if (data[0].hasOwnProperty(prop)) 
        {
          prop = prop.replace("_"," ");

          html+="<th>" + prop + "</th>";
        }
      }

      html+="</tr>";
      html+="</thead>";

      for(var i=0;i<data.length;i++)
      {
        var row = data[i];
        
        html+="<tr>";
        
        var colCount = 0;
        var currentRowID = -1;

        for (var prop in row) 
        {
          if (row.hasOwnProperty(prop)) 
          {
            if(colCount == 0)
            {
              currentRowID = row[prop];
            }

            var label = row[prop];

            if(options !== undefined)
            {
              if(options["is-clickable"] == "yes")
              {
                var link = options["link"];
                
                label = "<a href=\"javascript:" + link + "(" + currentRowID + ")\">" + row[prop] + "</a>";
              }
            }

            html+="<td>" + label + "</td>";

            colCount++;
          }

          
        }
        html+="</tr>";

      }

      html+="</table>";
      return html;
      
    }

    this.formatSqlDate = function(dateStr)
    {
      var dateParts = dateStr.split("-");
      var jsDate = new Date(dateParts[0], dateParts[1] - 1, dateParts[2].substr(0,2));
      
      let year = jsDate.getFullYear();
      let month = (1 + jsDate.getMonth()).toString().padStart(2, '0');
      let day = jsDate.getDate().toString().padStart(2, '0');
    
      return month + '/' + day + '/' + year;
      
    }

}