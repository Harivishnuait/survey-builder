<?php
class Survey
{
    public $debug = "";
    public $surveyID = 0;
    public $surveyDataObj;
    public $survey;

    public $prompts = [];

    public $questionCount = 0;
    public $answerCount = 0;
    public $moduleID;

    private $conn;

    // private $openAi;    
    public $openAI;

    private $auth;

    function __construct()
    {
        $this->surveyDataObj = new SurveyDataObj();     
        
        $this->openAI = new OpenAiWrapper("");
    }

    function loadFromDatabase($conn, $surveyID)
    {
        $this->conn = $conn;

        $survey = getDataObject($conn, "select * from survey.survey where surveyID = $surveyID");

        $userParams = json_decode($survey->surveyParams);

        $surveyObj = json_decode($survey->surveyJson);

        $this->survey = $survey;

        $this->loadSurvey($surveyID, $surveyObj, $userParams);

    }

    function createSurvey($conn, $auth, $userParams)
    {
        $this->conn = $conn;

        $surveyPrompts = new SurveyPrompts();

        if ($this->debugIsOn())
        {
            debug("");
            debug("");
            debug("");
            debug("Survey.createSurvey()");
            debug("-----------------Survey.createSurvey() - Raw params------------------------------------");
            print_r($userParams);
        }        

        $this->surveyDataObj = new SurveyDataObj();

        $this->surveyDataObj->params = $this->createSurveyParamObj($userParams);
        
        $this->surveyDataObj->title = $this->surveyDataObj->params->surveyName;

        $this->surveyDataObj->description = $this->surveyDataObj->params->researchGoals;

        if ($this->debugIsOn())
        {
            debug("");debug("");debug("");
            debug("Survey.createSurvey()");
            debug("-----------------Survey Data Object------------------------------------");
            print_r($this->surveyDataObj);
        }        

        $this->saveSurvey($conn, $auth);
        
        $this->saveFact($auth, "research-goals", "What are your research goals?", $this->surveyDataObj->params->researchGoals);

        $this->saveFact($auth, "survey-type", "What type of survey are you performing?", $this->surveyDataObj->params->surveyType);

        $this->saveFact($auth, "survey-name", "What is the name of this survey?", $this->surveyDataObj->params->surveyName);

        $prompt = $this->getBasePrompts("");

        $prompt.=$this->getFactPrompts();

        if ($this->debugIsOn()) $this->debug("Prompt: $prompt");

        
        $prompts[] = $this->openAI->createPrompt("user", $prompt);


        if($this->debugisOn())
        {
            
            debug("");debug("");debug("");
            debug("Survey.createSurvey() - Final Prompts");
            debug("----------------------------------------------------------------");
            print_r($prompts);
        }
        
        $this->genObjectiveSection($conn, $prompt);

        $this->saveSurvey($conn, $auth);
        
        if ($this->debugIsOn())
        {
            debug("-----------------Survey.createSurvey() - Final------------------------------------");
            print_r($this->surveyDataObj);
            debug("-----------------End Survey.createSurvey() - Survey Data Obj------------------------------------");
        }
    }

    
    function loadSurvey($surveyID, $surveyDataObj, $userParams)
    {
        $this->surveyID = $surveyID;
        $this->questionCount = 0;
        $this->answerCount = 0;

        $this->surveyDataObj = new SurveyDataObj();

        $this->surveyDataObj->formatVersion = $surveyDataObj->formatVersion;
        $this->surveyDataObj->surveyID = $surveyID;
        $this->surveyDataObj->title = $surveyDataObj->title;
        $this->surveyDataObj->description = $surveyDataObj->description;
        if(isset($surveyDataObj->loi))
        {
            $this->surveyDataObj->loi = $surveyDataObj->loi;
        }
        else
        {
            $this->surveyDataObj->loi = 1;
        }

        $this->surveyDataObj->params = $this->createSurveyParamObj($userParams);

        
        $this->surveyDataObj->sections = [];

        for($i=0;$i<sizeOf($surveyDataObj->sections);$i++)
        {
            $this->surveyDataObj->sections[] = $this->createSection($i, $surveyDataObj->sections[$i]);
        }


        if ($this->debugIsOn())
        {
            debug("-----------------Survey.loadSurvey()------------------------------------");
            print_r($this->surveyDataObj);
            debug("-----------------End Survey.loadSurvey()------------------------------------");
        }



    }

    function genObjectiveSection($conn, $prompt)
    {
        if($this->debugIsOn()) 
        {
            debug("");debug("");debug("");
            debug("OBJECTIVE PROMPT---------------------------------");
            debug("");debug("");debug("");
        }
        
        
        $sql = "select survey_modules.*,survey_modules_category.moduleCategoryID  
                        from survey_modules 
                        inner join survey_modules_category on survey_modules.moduleCategory = survey_modules_category.moduleCategoryName
                    where moduleTitle = 'Objective'";
         

        $module = getDataObject($conn, $sql);

        $prompt.= "$module->promptTemplate \r\n \r\n";
                
        
        $fullPrompt = $prompt;

        if($this->debugisOn())
        {
            
            debug("");debug("");debug("");
            debug("Survey.genObjectiveSection() - Final Prompts");
            debug("----------------------------------------------------------------");
            print_r($fullPrompt);
        }

        $reply = $this->askChatGpt($fullPrompt);

        if($this->debugIsOn()) 
        {
            debug("");debug("");debug("");
            debug("Survey.genObjectiveSection() - Reply");
            debug("----------------------------------------------------------------");
            print_r($reply);
        }

        $rawReply = $reply;

        $reply = json_decode($reply);
        
        if($this->debugIsOn())
        {
            print_r($reply);
        } 


        $this->savePrompt($fullPrompt, $rawReply, $module->moduleCategoryID, $module->moduleID);

        $newSection = new SurveySection();
        $newSection->section_num = 0;
        $newSection->sectionIdx = 0;
        $newSection->moduleID = $module->moduleID;
        $newSection->sectionType = $module->moduleType;
        $newSection->moduleCategory = "Objective";
        $newSection->moduleTitle = "Objective";
        $newSection->title = $reply->survey->survey_title;
        $newSection->description = $reply->survey->survey_objective;
        
        $this->surveyDataObj->sections[0] = $newSection;


        
    }


    function genScreenSection($params)
    {
        if($this->debugIsOn()) 
        {
            debug("");debug("");debug("");
            debug("SCREENER PROMPT---------------------------------");
            debug("");debug("");debug("");
        }
        
        $this->saveReplaceFact($this->auth, "target-audience", "Who is your target audience?", $params->targetAudienceDesc);

        $prompt = $this->getBasePrompts("");

        $prompt.=$this->getFactPrompts();

        $sql = "select survey_modules.*,survey_modules_category.moduleCategoryID  
                        from survey_modules 
                        inner join survey_modules_category on survey_modules.moduleCategory = survey_modules_category.moduleCategoryName
                    where moduleTitle = 'Screener'";
         

        $module = getDataObject($this->conn, $sql);
        
        $prompt.= "
                    $module->promptTemplate
                ";
                
        
        $prompt = $this->promptVarReplacement($prompt, $params);
        
        $fullPrompt = $prompt;

        if($this->debugisOn())
        {
            
            debug("");debug("");debug("");
            debug("Survey.genScreenSection() - Final Prompts");
            debug("----------------------------------------------------------------");
            print_r($fullPrompt);
        }


        $reply = $this->askChatGpt($fullPrompt);

        if($this->debugIsOn()) 
        {
            debug("");debug("");debug("");
            debug("Survey.genScreenSection() - Reply");
            debug("----------------------------------------------------------------");
            print_r($reply);
        }
        
        $rawReply = $reply;

        $reply = json_decode($reply);
        
        if($this->debugIsOn())
        {
            print_r($reply);
        } 

        $this->savePrompt($fullPrompt, $rawReply, $module->moduleCategoryID, $module->moduleID);

        $newSection = new SurveySection();
        $newSection->section_num = 0;
        $newSection->sectionIdx = 0;
        $newSection->sectionType = "screener";
        $newSection->moduleCategory = "Screener";
        $newSection->moduleTitle = "Screener";
        $newSection->title = $reply->survey->survey_section_title;
        $newSection->description = $reply->survey->survey_section_description;
        $newSection->questions = [];

        
        $questions = $reply->survey->survey_section_questions;

        for($j=0;$j<sizeOf($questions);$j++)
        {
            $newSection->questions[] = $this->createQuestion($j, $questions[$j]);
        }

        $this->surveyDataObj->sections[1] = $newSection;

        $this->saveSurvey($this->conn, $this->auth);
    }

    
    function genModule($moduleID, $numQuestions)
    {

        if($this->debugIsOn()) $this->debug("Survey.genModule() - moduleID = $moduleID numQuestions = $numQuestions");

        $sql = "select survey_modules.*,survey_modules_category.moduleCategoryID  
                        from survey_modules 
                        inner join survey_modules_category on survey_modules.moduleCategory = survey_modules_category.moduleCategoryName
                    where moduleID = $moduleID";
        
        if($this->debugIsOn()) debug("SQL: $sql");

        $module = getDataObject($this->conn, $sql);
        
        if($this->debugIsOn()) 
        {
            debug("");debug("");debug("");
            debug("Gen Module $module->moduleTitle PROMPT---------------------------------");
            debug("");debug("");debug("");
        }

        if($module->moduleTitle == "Conclusion")
        {
            return $this->genConclusion($module);
        }

        $prompt = $this->getBasePrompts("");

        $prompt.=$this->getFactPrompts();

        $prompt.= "
                    $module->promptTemplate
                ";
        
        $params = new stdClass();
        $params->numQuestions = $numQuestions;
        $params->moduleTitle = $module->moduleTitle;
        $params->moduleDesc = $module->moduleDesc;

        $prompt = $this->promptVarReplacement($prompt, $params);
        
        $fullPrompt = $prompt;

        if($this->debugisOn())
        {
            
            debug("");debug("");debug("");
            debug("Survey.genScreenSection() - Final Prompts");
            debug("----------------------------------------------------------------");
            print_r($fullPrompt);
        }

        
        $reply = $this->askChatGpt($fullPrompt);

        if($this->debugIsOn()) 
        {
            debug("");debug("");debug("");
            debug("Survey.genScreenSection() - Reply");
            debug("----------------------------------------------------------------");
            print_r($reply);
        }

        $rawReply = $reply;

        $reply = json_decode($reply);
        
        if($this->debugIsOn())
        {
            print_r($reply);
        } 

        $this->savePrompt($fullPrompt, $rawReply, $module->moduleCategoryID, $module->moduleID);


        $newSection = new SurveySection();
        $newSection->section_num = 0;
        $newSection->sectionIdx = 0;
        $newSection->sectionType = "general";
        $newSection->moduleCategory = $module->moduleCategory;
        $newSection->moduleTitle = $module->moduleTitle;
        $newSection->title = $reply->survey->survey_section_title;
        $newSection->description = $reply->survey->survey_section_description;
        $newSection->questions = [];

        if(isset($reply->survey->survey_section_questions))
        {
            $questions = $reply->survey->survey_section_questions;

            
            for($j=0;$j<sizeOf($questions);$j++)
            {
                $newSection->questions[] = $this->createQuestion($j, $questions[$j]);
            }
        }

        $this->surveyDataObj->sections[] = $newSection;

        $sql = "select count(*) 
                        from survey_sections 
                        where survey_sections.surveyID = $this->surveyID 
                        and moduleCategoryID = '$module->moduleCategoryID'";

        
        if(getKey($this->conn, $sql)<= 0)
        {
            $sql = "insert into survey_sections (surveyID, userID, moduleCategoryID,position) 
                        values ($this->surveyID
                                ," . $this->auth->getUserID() . "
                                ,$module->moduleCategoryID
                                ,0)";

            executeQuery($this->conn, $sql);
        }
        

        $this->saveSurvey($this->conn, $this->auth);

    }
    

    function genConclusion()
    {

        if($this->debugIsOn()) 
        {
            debug("");debug("");debug("");
            debug("GEN Conclusion---------------------------------");
            debug("");debug("");debug("");
        }

        $sql = "select * from survey_modules where moduleTitle = 'Conclusion'";
        
        if($this->debugIsOn()) debug("SQL: $sql");

        $module = getDataObject($this->conn, $sql);
        
        $moduleCategoryID = getKey($this->conn, "select moduleCategoryID from survey_modules_category where moduleCategoryName='Conclusion'");

        $prompt = $this->getBasePrompts("");

        $prompt.=$this->getFactPrompts();

        $prompt.= "
                    $module->promptTemplate
                ";
        
        $params = new stdClass();
        $params->numQuestions = $numQuestions;
        $params->moduleTitle = $module->moduleTitle;
        $params->moduleDesc = $module->moduleDesc;

        $prompt = $this->promptVarReplacement($prompt, $params);
        
        $fullPrompt = $prompt;

        if($this->debugisOn())
        {
            
            debug("");debug("");debug("");
            debug("Survey.genScreenSection() - Final Prompts");
            debug("----------------------------------------------------------------");
            print_r($fullPrompt);
        }

        
        $reply = $this->askChatGpt($fullPrompt);

        if($this->debugIsOn()) 
        {
            debug("");debug("");debug("");
            debug("Survey.genConclusionModule() - Reply");
            debug("----------------------------------------------------------------");
            print_r($reply);
        }

        $reply = json_decode($reply);
        
        if($this->debugIsOn())
        {
            print_r($reply);
        } 

        $newSection = new SurveySection();
        $newSection->section_num = 0;
        $newSection->sectionIdx = 0;
        $newSection->sectionType = "conclusion";
        $newSection->moduleCategory = "Conclusion";
        $newSection->moduleTitle = "Conclusion";
        $newSection->title = "Conclusion";
        $newSection->description = $reply->conclusion;
        $newSection->questions = [];

        $this->surveyDataObj->sections[] = $newSection;

        $sql = "select count(*) from survey_sections where surveyID = $this->surveyID and moduleCategoryID=$moduleCategoryID";

        if(getKey($this->conn, $sql)<= 0)
        {
            $sql = "insert into survey_sections (surveyID, userID, moduleCategoryID,position) 
                        values ($this->surveyID
                                ," . $this->auth->getUserID() . "
                                ,$moduleCategoryID
                                ,0)";

            executeQuery($this->conn, $sql);
        }

        $this->saveSurvey($this->conn, $this->auth);
   

    }





    function addQuestion($conn, $sectionIdx, $questionType)
    {
        //$this->debug = "Y";
        
        $surveyPrompts = new SurveyPrompts();

        $currSection = $this->surveyDataObj->sections[$sectionIdx];

        if($this->debugIsOn())
        {
            debug("Module Category: $currSection->moduleCategory");
        }

        $prompt = $this->getBasePrompts("");

        $prompt.=$this->getFactPrompts();

        if($currSection->moduleCategory == 'Target Audience')
        {
            $prompt.= $surveyPrompts->getScreenerQuestionAddPrompt($this->surveyDataObj->params, $questionType);
        }
        else
        {
            $sql = "select *
                    from survey.survey_modules 
                    where moduleCategory = '" . $currSection->moduleCategory . "'
                                and moduleTitle='" . $currSection->moduleTitle . "'";

            $surveyModule = getDataObject($conn, $sql);

            if($this->debugIsOn())
            {
                debug($sql);
                print_r($surveyModule);
            }

            
            $prompt.= $surveyPrompts->getQuestionAddPrompt($this->surveyDataObj->params, $questionType, $surveyModule);
            
        }
  
        $params = new stdClass();
        $params->numQuestions = 1;
        $params->moduleTitle = $surveyModule->moduleTitle;
        $params->moduleDesc = $surveyModule->moduleDesc;

        $prompt = $this->promptVarReplacement($prompt, $params);
        
        $fullPrompt = $prompt;

        if($this->debugisOn())
        {
            
            debug("");debug("");debug("");
            debug("Survey.genScreenSection() - Final Prompts");
            debug("----------------------------------------------------------------");
            print_r($fullPrompt);
        }

        $reply = $this->askChatGpt($fullPrompt);

        if($this->debugIsOn()) 
        {
            debug("");debug("");debug("");
            debug("Survey.genScreenSection() - Reply");
            debug("----------------------------------------------------------------");
            print_r($reply);
        }

        $reply = json_decode($reply);
        
        if($this->debugIsOn())
        {
            print_r($reply);
        } 


        $q = $this->createQuestion(0, $reply->survey_section_questions[0]);

        $this->surveyDataObj->sections[$sectionIdx]->questions[] = $q;

        if ($this->debugIsOn()) 
        {
            $this->debug("Survey Data");
            $this->debug("-----------------------------------------");
            print_r($this->surveyDataObj);
            $this->debug("");
        }
        
        $this->saveSurvey($this->conn, $this->auth);


    }



    function promptVarReplacement($prompt, $params)
    {
        $surveyPrompts = new SurveyPrompts();

        if(isset($params->numQuestions))
        {
            $prompt = str_replace("[NUM_QUESTIONS]", $params->numQuestions, $prompt);
        }

        if(isset($params->moduleTitle))
        {
            $prompt = str_replace("[MODULE_TITLE]", $params->moduleTitle, $prompt);
        }

        if(isset($params->moduleDesc))
        {
            $prompt = str_replace("[MODULE_DESC]", $params->moduleDesc, $prompt);
        }        


        if(str_contains($prompt, "[QUESTION_TYPE_LIST]"))
        {
            $prompt = str_replace("[QUESTION_TYPE_LIST]", $surveyPrompts->getQuestionTypeList(), $prompt);
        }

        return $prompt;

    }


    function getFactAnswer($factKey)
    {
        $sql = "select factAnswer from survey_facts where surveyID = " . $this->surveyID . " and factKey='$factKey'";

        $factAnswer = getKey($this->conn, $sql);

        return $factAnswer;
    }


    function getFactPrompts()
    {
        $prompt = "<p><strong>Survey Details:</strong></p>
<ul>
    <li><strong>Research Goals:</strong> " . $this->getFactAnswer('research-goals') . "</li>
    <li><strong>Survey Type:</strong> " . $this->getFactAnswer('survey-type') . "</li>
    <li><strong>Survey Name:</strong> " . $this->getFactAnswer('survey-name') . "</li>

    ";

        $sql = "select * from survey_facts where surveyID = $this->surveyID
                and factKey not in ('research-goals','survey-type','survey-name')";

        $q = executeQuery($this->conn, $sql);

        while($fact = mysqli_fetch_object($q))
        {
            $prompt.="
<li><strong>" . $fact->factQuestion . "</strong> " . $fact->factAnswer . "</li>";
        }

        $prompt.="</ul>";
        
        
        return $prompt;
    }
    

    function getBasePrompts($prompt)
    {
        
        $prompt.="
<p>You are tasked with creating a survey.</p>

<p>Follow these instructions to generate all survey statements and questions effectively:</p>

";

        return $prompt;
    }

    
    function updateDomain($domainKey, $domainDesc)
    {
        if($this->debugIsOn())
        {
            $this->debug("");$this->debug("");$this->debug("");
            $this->debug("Survey.updateDomain");
            $this->debug("domainKey: $domainKey");
            $this->debug("domainDesc:" . $domainDesc);
        }

        $domain = getDataObject($this->conn, "select * from survey_domains where domainKey='$domainKey'");

        $this->surveyDataObj->params->domains = $domainKey;

        $params = new stdClass();
        $params->userID = $this->auth->userID;
        $params->factKey = "domain";
        $params->factQuestion = "What domain is your survey about?";
        $params->factAnswer = $domainKey;
        $params->replaceIfExists = "Y";

        $this->saveFactAdvanced($params);


        if($domainDesc != "")
        {
            $params = new stdClass();
            $params->userID = $this->auth->userID;
            $params->factKey = "domain-more";
            $params->factQuestion = "$domain->domainPromptQuestion";
            $params->factAnswer = $domainDesc;
            $params->replaceIfExists = "Y";

            $this->saveFactAdvanced($params);
        }

        $this->saveSurvey($this->conn, $this->auth);
    }


    function updateFact($factID, $answer)
    {
        if($this->debugIsOn())
        {
            $this->debug("");$this->debug("");$this->debug("");
            $this->debug("Survey.updateFact");
            $this->debug("factID: $factID");
            $this->debug("Answer:" . $answer);
        }

        $sql = "update survey_facts set factAnswer = '$answer' where factID = $factID";

        executeQuery($this->conn, $sql);
    }


    function saveFactAdvanced($params)
    {
        if($this->debugIsOn())
        {
            $this->debug("");$this->debug("");$this->debug("");
            $this->debug("Survey.saveFactAdvanced");
            $this->debug("Question: $params->factQuestion");
            $this->debug("Answer:" . $params->factAnswer);

        }

        if(isset($params->replaceIfExists) && $params->replaceIfExists == "Y")
        {
            $sql = "delete from survey_facts where surveyID = $this->surveyID 
                                                        and userID=$params->userID
                                                        and factKey = '$params->factKey'";

            if($this->debugIsOn()) $this->debug($sql);

            executeQuery($this->conn, $sql);

        }


        $sql = "insert into survey_facts (surveyID, userID, factKey, factQuestion, factAnswer) 
                        values ($this->surveyID
                                ," . $this->auth->getUserID() . "
                                ,'$params->factKey'
                                ,'$params->factQuestion'
                                ,'$params->factAnswer'
                                )";
    
        
        if($this->debugIsOn()) $this->debug($sql);

        executeQuery($this->conn, $sql);

        $sql = "select factID from survey_facts where surveyID = $this->surveyID 
                                                        and userID=$params->userID
                                                        and factKey = '$params->factKey'
                                                        order by factID desc
                                                        limit 1";

        return getKey($this->conn, $sql);
    }



    function saveFact($auth, $factKey,  $factQuestion, $factAnswer)
    {
        $params = new stdClass();
        $params->userID = $auth->userID;
        $params->factKey = $factKey;
        $params->factQuestion = $factQuestion;
        $params->factAnswer = $factAnswer;

        return $this->saveFactAdvanced($params);
        
    }

    
    function saveReplaceFact($auth, $factKey,  $factQuestion, $factAnswer)
    {
        $params = new stdClass();
        $params->userID = $auth->userID;
        $params->factKey = $factKey;
        $params->factQuestion = $factQuestion;
        $params->factAnswer = $factAnswer;
        $params->replaceIfExists = "Y";

        return $this->saveFactAdvanced($params);
        
    }


    function createSurveyParamObj($userParams)
    {   

        $params = new SurveyParams();
        if($this->debugIsOn())
        {
            debug("-----------------Survey.createSurveyParamObj() - User Params Parsed------------------------------------");
            print_r($userParams);
        }

        if(isset($userParams->surveyName)) $params->surveyName = $userParams->surveyName;
        if(isset($userParams->researchGoals))$params->researchGoals = $userParams->researchGoals;
        if(isset($userParams->surveyType))$params->surveyType = $userParams->surveyType;
        if(isset($userParams->brands)) $params->brands = $userParams->brands;
        if(isset($userParams->attributes)) $params->attributes = $userParams->attributes;
        if(isset($userParams->domains))$params->domains = $userParams->domains;
        if(isset($userParams->productStatus)) $params->productStatus = $userParams->productStatus;
        if(isset($userParams->surveyModules)) $params->surveyModules = $userParams->surveyModules;
        if(isset($userParams->targetAudienceAttributes))$params->targetAudienceAttributes = $userParams->targetAudienceAttributes;
        if(isset($userParams->targetAudienceDesc))$params->targetAudienceDesc = $userParams->targetAudienceDesc;

        if($this->debugIsOn())
        {
            debug("-----------------Survey.createSurveyParamObj() - Final Params Parsed------------------------------------");
            print_r($params);
        }

        return $params;
    }


    
    function getModulePrompt($conn, $moduleTitle, $params, $surveyText)
    {
        $prompt = getKey($conn, "select promptTemplate from survey_modules where moduleTitle = '$moduleTitle'");

        //$prompt = str_replace("[SURVEY_DESC]", $this->getSurveyInputs(), $prompt);

        //$prompt = str_replace("[CURR_SURVEY]", $surveyText, $prompt);

        //$prompt = str_replace("[QUESTION_TYPE_LIST]", $this->getQuestionTypeList(), $prompt);

        //$prompt = str_replace("[Multiple Choice]",  $this->getQuestionTypeListFiltered('Multiple Choice'), $prompt);

        //$prompt = str_replace("[Single Choice]",  $this->getQuestionTypeListFiltered('Single Choice'), $prompt);

        //$prompt = str_replace("[Rating Scale]",  $this->getQuestionTypeListFiltered('Rating Scale'), $prompt);

        //$prompt = str_replace("[Ranking]",  $this->getQuestionTypeListFiltered('Ranking'), $prompt);

        return $prompt;
    }


    
    

























    function createSection($idx, $sectionObj)
    {
        $newSection = new SurveySection();
        $newSection->section_num = $idx+1;
        $newSection->sectionIdx = $idx;
        $newSection->sectionType = $sectionObj->sectionType;
        $newSection->title = $sectionObj->title;
        $newSection->moduleCategory = $sectionObj->moduleCategory;
        $newSection->moduleTitle = $sectionObj->moduleTitle;
        $newSection->description = $sectionObj->description;

        for($i=0;$i<sizeOf($sectionObj->questions);$i++)
        {
            $newSection->questions[] = $this->createQuestion($i, $sectionObj->questions[$i]);
        }

        return $newSection;
    }

    function createQuestion($idx, $question)
    {
        
        $newQuestion = new SurveyQuestion();
        $newQuestion->question_num = $this->questionCount++;
        $newQuestion->question_type = $question->question_type;
        $newQuestion->question_text = $question->question_text;
        
        if($newQuestion->question_type == "Yes or No")
        {
            $newQuestion->answers = $this->createAnswerYesNo($question, $question->answers);

        }
        else
        {
            for($i=0;$i<sizeOf($question->answers);$i++)
            {
                $newQuestion->answers[] = $this->createAnswer($question, $i, $question->answers[$i]);

            }
        }

        return $newQuestion;
    }

    
    function createAnswerYesNo($question,$originalAnswers)
    {
        $answers = [];

        $newAnswer = new SurveyQuestionAnswer();
        $newAnswer->answer_num = $this->answerCount++;
        $newAnswer->answer_text = "Yes";
        $newAnswer->terminate_survey = false;
        $newAnswer->programming_notes = [];
        $newAnswer->answer_note = "";
        
        if(sizeOf($originalAnswers)> 0)
        {
            if($originalAnswers[0]->terminate_survey)
            {
                $newAnswer->terminate_survey = $originalAnswers[0]->terminate_survey;
            }

            if($originalAnswers[0]->programming_notes)
            {
                $newAnswer->programming_notes = $originalAnswers[0]->programming_notes;
            }

            if(isset($originalAnswers[0]->answer_note))
            {
                $newAnswer->answer_note = $originalAnswers[0]->answer_note;
            }

        }

        $answers[] = $newAnswer;

        $newAnswer = new SurveyQuestionAnswer();
        $newAnswer->answer_num = $this->answerCount++;
        $newAnswer->answer_text = "No";
        $newAnswer->terminate_survey = false;
        $newAnswer->programming_notes = [];
        $newAnswer->answer_note = "";
        
        if(sizeOf($originalAnswers)> 1)
        {
            if($originalAnswers[1]->terminate_survey)
            {
                $newAnswer->terminate_survey = $originalAnswers[1]->terminate_survey;
            }

            if($originalAnswers[0]->programming_notes)
            {
                $newAnswer->programming_notes = $originalAnswers[1]->programming_notes;
            }

            if(isset($originalAnswers[0]->answer_note))
            {
                $newAnswer->answer_note = $originalAnswers[1]->answer_note;
            }
        }

        $answers[] = $newAnswer;
        
        return $answers;
    }


    function createAnswer($question, $answerIdx, $answer)
    {
        $newAnswer = new SurveyQuestionAnswer();
        $newAnswer->answer_num = $this->answerCount++;
        $newAnswer->answer_text = $answer->answer_text;
        if(isset($answer->answer_note))
        {
            $newAnswer->answer_note = $answer->answer_note;
        }
        else
        {
            $newAnswer->answer_note = "";
        }
        $newAnswer->terminate_survey = $answer->terminate_survey;
        $newAnswer->programming_notes = $answer->programming_notes;
        
        return $newAnswer;
    }




    function genScreenerSection($conn, $numQuestions)
    {
        if($this->debugIsOn()) 
        {
            debug("");debug("");debug("");
            debug("SCREENER PROMPT---------------------------------");
            debug("");debug("");debug("");
        }

        $newSection = new SurveySection();
        $newSection->section_num = 0;
        $newSection->sectionIdx = 0;
        $newSection->sectionType = "screener";
        $newSection->moduleCategory = "Screener";
        $newSection->moduleTitle = "Screener";
        $newSection->title = "";
        $newSection->description = "";
        $newSection->questions = [];

        $surveyPrompts = new SurveyPrompts();

        $module = getDataObject($conn, "select * from survey_modules where moduleTitle = 'Screener'");

    
        $this->prompts[] = new SurveyPrompt();
        
        $idx = sizeOf($this->prompts)-1;

        $this->prompts[$idx]->moduleTitle = $module->moduleTitle;

        $this->prompts[$idx]->sent = $surveyPrompts->getModulePrompt($conn, $module->moduleTitle, $this->surveyDataObj->params, $this->surveyToText());

        $this->prompts[$idx]->sent  = str_replace("[NUM_QUESTIONS]",  $numQuestions, $this->prompts[$idx]->sent);
        
        $reply = $this->askChatGpt($this->prompts[$idx]->sent);

        $this->prompts[$idx]->responseRaw = $reply;
        
        $reply = json_decode($reply);
        
        $this->prompts[$idx]->response = $reply;

        $newSection->title = $reply->survey->survey_section_title;
        $newSection->description = $reply->survey->survey_section_description;

        $questions = $reply->survey->survey_section_questions;

        for($j=0;$j<sizeOf($questions);$j++)
        {
            $newSection->questions[] = $this->createQuestion($j, $questions[$j]);
        }

        
        if($this->debugIsOn())
        {
            debug("COMMS $idx");
            debug("SENT:" . $this->prompts[$idx]->sent . "");
            debug("REPLY:");
            print_r($this->prompts[$idx]->response);
            debug("SECTION:");
            print_r($newSection);
        } 

        $this->surveyDataObj->sections[1] = $newSection;
      

        
    }
    

    

    
    function genFeedbackSection()
    {
        if($this->debugIsOn()) 
        {
            debug("");debug("");debug("");
            debug("GEN FEEDBACK---------------------------------");
            debug("");debug("");debug("");
        }

        $surveyPrompts = new SurveyPrompts();

        $sql = "select * from survey_modules where moduleTitle = 'Feedback'";
        
        if($this->debugIsOn()) debug("SQL: $sql");

        $module = getDataObject($this->conn, $sql);
        
        $this->prompts[] = new SurveyPrompt();
        
        $idx = sizeOf($this->prompts)-1;

        $this->prompts[$idx]->moduleTitle = $module->moduleTitle;

        $this->prompts[$idx]->sent = $surveyPrompts->getModulePrompt($this->conn, $module->moduleTitle, $this->surveyDataObj->params, $this->surveyToText());

        $reply = $this->askChatGpt($this->prompts[$idx]->sent);

        $this->prompts[$idx]->responseRaw = $reply;
        
        $reply = json_decode($reply);
        
        $this->prompts[$idx]->response = $reply;

        $newSection = new SurveySection();
        $newSection->section_num = 0;
        $newSection->sectionIdx = 0;
        $newSection->sectionType = "feedback";
        $newSection->moduleCategory = $module->moduleCategory;
        $newSection->moduleTitle = $module->moduleTitle;
        $newSection->title = $reply->survey->survey_section_title;
        $newSection->description = $reply->survey->survey_section_description;
        $newSection->questions = [];

        $newQuestion = new SurveyQuestion();
        $newQuestion->question_num = $this->questionCount++;
        $newQuestion->question_type = "Free Text";
        $newQuestion->question_text = $reply->survey->question_text;
        
        $newSection->questions[] = $this->createQuestion(0, $newQuestion);
        
        $this->surveyDataObj->sections[] = $newSection;

        if($this->debugIsOn()) 
        {
            print_r($newSection);
            debug("");debug("");debug("");
            debug("GEN FEEDBACK DONE---------------------------------");
            debug("");debug("");debug("");
        }

    }


        

    function saveObjective($conn, $objectiveTitle, $objectiveText)
    {
        $this->surveyDataObj->sections[0]->title = $objectiveTitle;
        $this->surveyDataObj->sections[0]->description = $objectiveText;
        
        $this->surveyDataObj->title = $objectiveTitle;
        $this->surveyDataObj->description = $objectiveText;
    }

    
    function saveSectionHeader($conn, $sectionIdx, $title, $desc)
    {
        $this->surveyDataObj->sections[$sectionIdx]->title = $title;
        $this->surveyDataObj->sections[$sectionIdx]->description = $desc;
        
    }

    
    function saveQuestion($conn, $sectionIdx, $questionIdx, $questionText)
    {
        $this->surveyDataObj->sections[$sectionIdx]->questions[$questionIdx]->question_text = $questionText;
    }

    
    function saveAnswer($conn, $sectionIdx, $questionIdx, $answerIdx, $answerText)
    {
        $this->surveyDataObj->sections[$sectionIdx]->questions[$questionIdx]->answers[$answerIdx]->answer_text = $answerText;
        

    }

    function saveAnswerNote($conn, $sectionIdx, $questionIdx, $answerIdx, $answerNote)
    {
        $this->surveyDataObj->sections[$sectionIdx]->questions[$questionIdx]->answers[$answerIdx]->programming_notes[0] = $answerNote;
        

    }    

    function calcLOI()
    {
        $numQuestions = 0;

        for($i=0;$i<sizeOf($this->surveyDataObj->sections);$i++)
        {
            $numQuestions+= sizeOf($this->surveyDataObj->sections[$i]->questions);
        }

        $this->surveyDataObj->loi = $numQuestions/2;

    }

    
    function savePrompt($promptSent, $promptResponse, $moduleCategoryID, $moduleID)
    {
        if ($this->debugIsOn()) 
        {
            $this->debug("savePrompt(): surveyID: $this->surveyID");
            $this->debug("moduleCategoryID: $moduleCategoryID");
            $this->debug("moduleID: $moduleID");
        }

        $sql = "insert into survey_prompts_sent (surveyID, userID, surveyPrompt, response, moduleCategoryID,moduleID, isActive) values (
            $this->surveyID
            ," . $this->auth->getUserID() . "
            ,'" . $this->conn->real_escape_string($promptSent) ."'
            ,'" . $this->conn->real_escape_string($promptResponse) ."'
            ,$moduleCategoryID
            ,$moduleID
            ,'Y')";


        $sql = "insert into survey_prompts_sent (surveyID, userID, surveyPrompt, response, moduleCategoryID,moduleID, isActive) values (
            $this->surveyID
            ," . $this->auth->getUserID() . "
            ,'" . $this->cleanInput($promptSent) ."'
            ,'" . $this->cleanInput($promptResponse) ."'
            ,$moduleCategoryID
            ,$moduleID
            ,'Y')";

        if($this->debugIsOn())
        {
            $this->debug("Prompt Save SQL");
            $this->debug($sql);
        }

        executeQuery($this->conn, $sql);

    }


    function saveSurvey($conn, $auth)
    {
        if ($this->debugIsOn()) $this->debug("saveSurvey(): surveyID: $this->surveyID");

        $validator = new SurveyValidator();

        $this->surveyDataObj = $validator->validateSurvey($this->surveyDataObj);

        $this->calcLOI();

        $paramsJson = json_encode($this->surveyDataObj->params);

        $paramsJson = $this->cleanJsonString($paramsJson);

        $surveyJson = json_encode($this->surveyDataObj);

        $surveyJson = $this->cleanJsonString($surveyJson);

        if($this->surveyID <= 0)
        {
            $sql = "insert into survey_db.survey (userID, surveyGuid, surveyName, surveyDesc, surveyParams, surveyJson, createdDate, modifiedDate)
                    values (" . $auth->getUserID() . "
                            ,UUID()
                            ,'" . clean($conn, $this->surveyDataObj->title) . "'
                            ,'" . clean($conn, $this->surveyDataObj->description) . "'
                            ,'$paramsJson'
                            ,'$surveyJson' 
                            ,now()
                            ,now()
                            )";

            if ($this->debugIsOn()) $this->debug($sql);

            if ($this->debugIsOn()) $this->debug("...Survey Inserted");



            executeQuery($conn, $sql);

            $this->surveyID = getKey($conn, "select max(surveyID) from survey_db.survey where userID = " . $auth->getUserID());

            $this->surveyDataObj->surveyID = $this->surveyID;

            //2024.09 - MB - Insert into history table as well
            $sql = "insert into survey_db.survey_history (surveyID, userID, surveyGuid, surveyName, surveyDesc, surveyParams, surveyJson, createdDate, modifiedDate)
                    values ($this->surveyID
                            ," . $auth->getUserID() . "
                            ,UUID()
                            ,'" . clean($conn, $this->surveyDataObj->title) . "'
                            ,'" . clean($conn, $this->surveyDataObj->description) . "'
                            ,'$paramsJson'
                            ,'$surveyJson' 
                            ,now()
                            ,now()
                            )";

            if ($this->debugIsOn()) $this->debug($sql);

            if ($this->debugIsOn()) $this->debug("...Survey History Inserted");

            executeQuery($conn, $sql);

            $this->surveyID = getKey($conn, "select max(surveyID) from survey_db.survey where userID = " . $auth->getUserID());

            $this->surveyDataObj->surveyID = $this->surveyID;

        }


        
        $paramsJson = json_encode($this->surveyDataObj->params);

        $paramsJson = $this->cleanJsonString($paramsJson);

        $surveyJson = json_encode($this->surveyDataObj);

        $surveyJson = $this->cleanJsonString($surveyJson);
        
        
        $sql = "update survey_db.survey 
                    set 
                        surveyName = '" . clean($conn, $this->surveyDataObj->title) . "'
                        ,surveyDesc = '" . clean($conn, $this->surveyDataObj->description) . "'
                        ,surveyParams = '" . $paramsJson ."' 
                        ,surveyJson ='$surveyJson'
                        ,modifiedDate = now()
                    where surveyID = $this->surveyID";

        if ($this->debugIsOn()) $this->debug($sql);

        executeQuery($conn, $sql);

        if ($this->debugIsOn()) $this->debug("...Survey Updated");

        //09.2024 - MB - Save to history
        $sql = "insert into survey_db.survey_history (surveyID, userID, surveyGuid, surveyName, surveyDesc, surveyParams, surveyJson, createdDate, modifiedDate)
        values ($this->surveyID
                ," . $auth->getUserID() . "
                ,UUID()
                ,'" . clean($conn, $this->surveyDataObj->title) . "'
                ,'" . clean($conn, $this->surveyDataObj->description) . "'
                ,'$paramsJson'
                ,'$surveyJson' 
                ,now()
                ,now()
                )";

        if ($this->debugIsOn()) $this->debug($sql);

        if ($this->debugIsOn()) $this->debug("...Survey History Inserted");

        executeQuery($conn, $sql);

        
        if($this->debugIsOn())
        {
            $this->debug("Saving Survey Data Object");

            print_r($this->surveyDataObj);
        }

        return $this->surveyID;
    }



    function cleanJsonString($json)
    {
        $json = str_replace("\\n", '', $json);
        $json = str_replace("\\r", '', $json);
        $json = str_replace("\n", '', $json);
        $json = str_replace("\r", '', $json);
        $json = str_replace("'", '', $json);
        
        return $json;
    }

    function askChatGpt($prompt)
    {
        
        $debug = $this->debug;

        $sql = "insert into survey_chat_history (surveyID, msg, direction) values (
                    $this->surveyID
                    ,'" . $this->conn->real_escape_string($prompt) . "'
                    ,'sent'
                    )";
        executeQuery($this->conn, $sql);


        include "../open-ai/get-response.php";


        $sql = "insert into survey_chat_history (surveyID, msg, direction) values (
            $this->surveyID
            ,'" . $this->conn->real_escape_string($reply) . "'
            ,'recieved'
            )";
        executeQuery($this->conn, $sql);

        return $reply;
    }


    function getSurveyData($conn, $surveyID)
    {
        return $this->surveyDataObj;
    }




    

    
    
    function addAnswer($conn, $sectionIdx, $questionIdx)
    {
        //$this->debug = "Y";
        
        $surveyPrompts = new SurveyPrompts();

        $currQuestion = $this->surveyDataObj->sections[$sectionIdx]->questions[$questionIdx];

        $prompt = $surveyPrompts->getAnswerAddPrompt($this->surveyDataObj->params, $currQuestion);

        if ($this->debugIsOn()) 
        {
            $this->debug("Prompt");
            $this->debug("-----------------------------------------");
            $this->debug($prompt);
       
        }
        
        $reply = $this->askChatGpt($prompt);

        if ($this->debugIsOn()) 
        {
            $this->debug("Reply");
            $this->debug("-----------------------------------------");
            print_r($reply);
            $this->debug("");
        }

        $reply = json_decode($reply);


        $this->surveyDataObj->sections[$sectionIdx]->questions[$questionIdx]->answers[] = $this->createAnswer($currQuestion, 0, $reply->answers[0]);

        if ($this->debugIsOn()) 
        {
            $this->debug("Survey Data");
            $this->debug("-----------------------------------------");
            print_r($this->surveyDataObj);
            $this->debug("");
        }

    }

    
    function rewordQuestion($conn, $sectionIdx, $questionIdx)
    {
        //$this->debug = "Y";

        $currSection = $this->surveyDataObj->sections[$sectionIdx];

        $currQuestion = $currSection->questions[$questionIdx];

        if ($this->debugIsOn()) {
            $this->debug("Current Question");
            $this->debug("-----------------------------------------");
            print_r($currQuestion);
        }

        $surveyPrompts = new SurveyPrompts();

        $prompt = $surveyPrompts->getQuestionRewordPrompt($this->surveyDataObj->params,$currQuestion);
        
        if ($this->debugIsOn()) {
            $this->debug("Prompt");
            $this->debug("-----------------------------------------");
            $this->debug($prompt);
        }
        
        $reply = $this->askChatGpt($prompt);

        if ($this->debugIsOn()) {
            $this->debug("Reply");
            $this->debug("-----------------------------------------");
            print_r($reply);
            $this->debug("");
        }

        $reply = json_decode($reply);

        $q = $this->createQuestion($questionIdx, $reply->survey_section_questions[0]);

        $this->surveyDataObj->sections[$sectionIdx]->questions[$questionIdx] = $q;

        if ($this->debugIsOn()) {
            $this->debug("Survey Data");
            $this->debug("-----------------------------------------");
            print_r($this->surveyDataObj);
            $this->debug("");
        }

    }



    function removeQuestion($conn, $sectionIdx, $questionIdx)
    {
        // $questionIdx = 0;
        $newQuestionList = [];

        $section = $this->surveyDataObj->sections[$sectionIdx];

        for ($i = 0; $i < sizeOf($section->questions); $i++) {
            $q = $section->questions[$i];

            if ($i != $questionIdx) {
                array_push($newQuestionList, $q);
            }
        }

        $this->surveyDataObj->sections[$sectionIdx]->questions = $newQuestionList;

    }




    function removeAnswer($conn, $sectionIdx, $questionIdx, $answerIdx)
    {
        $answers = $this->surveyDataObj->sections[$sectionIdx]->questions[$questionIdx]->answers;

        array_splice($answers, $answerIdx, 1);

        $this->surveyDataObj->sections[$sectionIdx]->questions[$questionIdx]->answers = $answers;
    }

    

    function getSurveyDataObj()
    {
        return $this->surveyDataObj;
    }


    
    function getSurveyGuid()
    {
        return $this->survey->surveyGuid;
    }


    function debugIsOn()
    {
        return $this->debug != "";
    }

    function debug($msg)
    {
        print "$msg <br>\r\n";
    }

    function surveyToText()
    {
        $out = "";
 
        $sections = $this->surveyDataObj->sections;

        foreach ($sections as $section) 
        {
            //print_r($section);
            $out.= "Section Title: " . $section->title . "\r\n";
            $out.= "Section Description: " . $section->description . "\r\n";

            foreach ($section->questions as $question) 
            {
                $txt = $question->question_num . ": " . $question->question_text;
                $out.= $txt . "\r\n";
                
                
                if (property_exists($question, 'answers')) 
                {
                    foreach ($question->answers as $answer) 
                    {
                        $answerTxt = $answer->answer_text;
                        
                        if($answer->terminate_survey) 
                        {
                            $answerTxt.="[TERMINATE SURVEY]";
                        }

                        $out.=$answerTxt . "\r\n";
                        $out.= "\r\n";
                        $out.= "\r\n";
                    }
                }
            }
        }

        $out.= "-----------------------------------------------------------------------";
        $out.= "\r\n";

        return $out;


    }

    public function cleanInput($string)
    {
        // Use preg_replace to remove all characters except alphanumeric, spaces, and line breaks
        return preg_replace('/[^\w\s\n\r<>]/u', '', $string);

    }
    public function setConn($conn)
    {
        $this->conn = $conn;
    }

    public function setAuth($auth)
    {
        $this->auth = $auth;
    }    
}
