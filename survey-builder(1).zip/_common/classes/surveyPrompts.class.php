<?php
class SurveyPrompts
{

    
    function getModulePrompt($conn, $moduleTitle, $params, $surveyText)
    {
        $prompt = getKey($conn, "select promptTemplate from survey_modules where moduleTitle = '$moduleTitle'");

        $prompt = str_replace("[SURVEY_DESC]", $this->getSurveyDescription($params), $prompt);

        //$prompt = str_replace("[CURR_SURVEY]", $surveyText, $prompt);

        //$prompt = str_replace("[QUESTION_TYPE_LIST]", $this->getQuestionTypeList(), $prompt);

        //$prompt = str_replace("[Multiple Choice]",  $this->getQuestionTypeListFiltered('Multiple Choice'), $prompt);

        //$prompt = str_replace("[Single Choice]",  $this->getQuestionTypeListFiltered('Single Choice'), $prompt);

        //$prompt = str_replace("[Rating Scale]",  $this->getQuestionTypeListFiltered('Rating Scale'), $prompt);

        //$prompt = str_replace("[Ranking]",  $this->getQuestionTypeListFiltered('Ranking'), $prompt);

        return $prompt;
    }





    function getSurveyDescription($params)
    {
        $prompt = "
The topic of the survey is: $params->surveyName

The research goal of the survey is: " . $params->researchGoals . "

The target audience is described as:  " . $params->targetAudienceDesc . "

The target audience has the following attributes: " . $this->getTargetAudienceAttributes($params) . "

The product has the following related brands: " . $this->getBrandList($params) . "

The survey will ask about: " . $this->getAttributeList($params) . "

The survey is about a product in the " . $this->getDomainList($params) . " domain(s) 

This survey is a a " . $params->surveyType . " survey.

The product asked about has a status of " . $this->getProductStatus($params) . " 

        ";

        return $prompt;
    }
    




    function getTargetAudiencePrompt($params)
    {

        $prompt = "
I am creating a survey, I need a list of attributes about my target audience. Each attribute should be no more than 2 words long.

The survey description is as follows:

" . $this->getSurveyDescription($params) . "

Output all content in the survey as a JSON object 

Use the following JSON template
{
    \"attributes\":[]
}";

        return $prompt;
    }



    function getObjectivePrompt($params)
    {
        $prompt = "
Create a catchy title for the following survey.

Write a statement that encourages the respondant to take the survey

The survey description is as follows:

" . $this->getSurveyDescription($params) . "

Output all content using the following JSON template
{
    \"survey\":{
        \"survey_title\",
        \"survey_objective\":\"\"
    }
}
";

        return $prompt;
    }





    function getScreenerPrompt($params, $currSurveyObj)
    {
        $prompt = "
This is the current contents of the survey object:

" . json_encode($currSurveyObj, JSON_PRETTY_PRINT) . "

Create an additional question which will determine if the respondant is in the target audience for this survey:

" . $this->getSurveyDescription($params) . "

" . $this->getQuestionTypeList() . "

Identify which answers if selected would terminate the survey.

Output all content using the following JSON template
{
    \"survey\":{
        \"survey_section_title\": \"xyz\",
        \"survey_section_description\": \"xyz\",
        \"survey_section_questions\": [
                {
                \"question_text\": \"xyz\",
                \"question_type\": \"Multiple Choice\",
                \"answers\": [
                                {
                                    \"answer_text\":\"xyz\"
                                    ,\"terminate_survey\":false
                                    ,\"programming_notes\":[]
                                }
                    ]
                }
            ]
        }
    
}
";
  

        return $prompt;
    }


    
    function getScreenerQuestionAddPrompt($params, $questionType)
    {
        $prompt = "
Create a single question which will determine if the respondant is in the target audience for this survey:
            ";

if($questionType == "Single Choice" || $questionType == "Yes or No")
{
    $prompt.= "Make the question a Yes or No question";
}

if($questionType == "Multiple Choice")
{
    $prompt.= "Make the question a Multiple Choice question, not a Yes or No question";
}

if($questionType == "Rating Scale")
{
    $prompt.= "Make the question a Rating Scale question";
}


if($questionType == "Ranking")
{
    $prompt.= "Make the question a Ranking question";
}


$prompt.= "
Identify which answers if selected would terminate the survey.

Output all content using the following JSON template
{
    \"survey_section_questions\": [
            {
            \"question_text\": \"xyz\",
            \"question_type\": \"Multiple Choice\",
            \"answers\": [
                            {
                                \"answer_text\":\"xyz\"
                                ,\"terminate_survey\":false
                                ,\"programming_notes\":[]
                            }
                ]
            }
        ]
}
";
  

        return $prompt;
    }




    

    function getAdditionalSectionPrompt($params,$module)
    {
        $prompts = [];
        

        $sectionPrompt = "
I need you to create 4 to 5 questions for a survey, the description of the survey follows:

" . $this->getSurveyDescription($params) . "

This section is called '" . $module->moduleTitle . "' and the purpose of the questions is to:

$module->moduleDesc

" . $this->getQuestionTypeListFiltered($module->questionTypes) . "

Output all content in the survey as a JSON object 

Use the following JSON template
{
    \"survey\":{
        \"survey_section_title\": \"xyz\",
        \"survey_section_description\": \"xyz\",
        \"survey_section_questions\": [
                {
                \"question_text\": \"xyz\",
                \"question_type\": \"Multiple Choice\",
                \"answers\": [
                                {
                                    \"answer_text\":\"xyz\"
                                    ,\"terminate_survey\":false
                                    ,\"programming_notes\":[]
                                }
                    ]
                }
            ]
        }
    
}
";

        return $sectionPrompt;

        
    }


    
    function getAnswerAddPrompt($params,$question)
    {
        
        $prompt = "
I need you to create an additional answer to the following question:

" . $question->question_text . "
Current Answers: 
";

for($i=0;$i<sizeOf($question->answers);$i++)
{
    $prompt.= "  * " . $question->answers[$i]->answer_text . "
";
}

$prompt.= "
Output all content in the survey as a JSON object 

Use the following JSON template
{
    \"answers\": [
                {
                    \"answer_text\":\"xyz\"
                    ,\"terminate_survey\":false
                    ,\"programming_notes\":[]
                }
    ]
}
";

        return $prompt;

        
    }



    function getQuestionRewordPrompt($params,$currQuestion)
    {

        $prompt = "
        I want to replace the following question
        
            " . $currQuestion->question_text . "
        
        Rephrase the question and the answers.

            " . $this->getQuestionTypeList() . "
            
            Output all content using the following JSON template
                            
    Use the following JSON template to reply
    {
        \"survey_section_questions\": [
                {
                \"question_text\": \"xyz\",
                \"question_type\": \"Multiple Choice\",
                \"answers\": [
                                {
                                    \"answer_text\":\"xyz\"
                                    ,\"terminate_survey\":false
                                    ,\"programming_notes\":[]
                                }
                    ]
                }
            ]
    }
";

        return $prompt;

        
    }

    
    function getQuestionAddPrompt($params,$questionType, $module)
    {

        $prompt = "
        I need you to create 1 question for a survey, the description of the survey follows:
            
            This section is called '" . $module->moduleTitle . "' and the purpose of the questions is to:
            
            $module->moduleDesc
            
            " . $this->getQuestionTypeListFiltered($questionType) . "
            
            Output all content using the following JSON template
                            
    Use the following JSON template to reply
    {
        \"survey_section_questions\": [
                {
                \"question_text\": \"xyz\",
                \"question_type\": \"xxx\",
                \"answers\": [
                                {
                                    \"answer_text\":\"xyz\"
                                    ,\"terminate_survey\":false
                                    ,\"programming_notes\":[]
                                }
                    ]
                }
            ]
    }
";

        return $prompt;

        
    }

    function getQuestionTypeList()
    {
        $out = "
For each question you create, select one of the following types of question at random:

'Yes or No' - A question that has an answer of yes or no

'Single Choice' - A question with x number of answers, the user can only select one of the answers

'Multiple Choice' - A question with x number of answers, the user can select multiple answers

'Rating Scale' - A question with x number of answers, the user will select from a scale of 1 to 7, with 1 being the least on the scale and 7 being the most.

'Ranking' - A question with x number of answers, for each answer the user will give a numeric rank (from 1 onward) on how they would like to rank the answers being tested.
";

        return $out;
    }
    
    
    function getQuestionTypeListFiltered($list)
    {
        $list = explode(",",$list);

        $out = "
Select from one of the following types of questions:
";
 
        if(in_array("Yes or No",$list))
        {
            $out.="
'Yes or No' - A question that has an answer of yes or no
";
        }

        if(in_array("Single Choice",$list))
        {
            $out.="
'Single Choice' - A question with x number of answers, the user can only select one of the answers
            ";
        }

        if(in_array("Multiple Choice",$list))
        {
            $out.="
'Multiple Choice' - A question with x number of answers, the user can select multiple answers
            ";
        }

        if(in_array("Rating Scale",$list))
        {
            $out.="
'Rating Scale' - A question with x number of answers, the user will select from a scale of 1 to 7, with 1 being the least on the scale and 7 being the most.
            ";
        }

        if(in_array("Ranking",$list))
        {
            $out.="
'Ranking' - A question with x number of answers, for each answer the user will give a numeric rank (from 1 onward) on how they would like to rank the answers being tested.
            ";
        }


        return $out;
    }
    
    function getProductStatus($params)
    {
        return $params->productStatus;
    }

    function getBrandList($params)
    {
        
        $brandList = "";

        for ($i = 0; $i < sizeOf($params->brands); $i++) {
            if ($i > 0) $brandList .= ",";

            $brandList .= $params->brands[$i];
        }

        return $brandList;

    }


    function getDomainList($params)
    {
        
        $out = "";
        for ($i = 0; $i < sizeOf($params->domains); $i++) {
            if ($i > 0) $out .= ",";

            $out .= $params->domains[$i];
        }

        return $out;

    }


    function getAttributeList($params)
    {
        
        $addAttributeList = "";
        for ($i = 0; $i < sizeOf($params->attributes); $i++) {
            if ($i > 0) $addAttributeList .= ",";

            $addAttributeList .= $params->attributes[$i];
        }

        return $addAttributeList;

    }
    
    function getTargetAudienceAttributes($params)
    {

        $targetAudienceAttributes = "";

        for ($i = 0; $i < sizeOf($params->targetAudienceAttributes); $i++) {
            if ($i > 0) $targetAudienceAttributes .= ",";

            $targetAudienceAttributes .= $params->targetAudienceAttributes[$i];
        }

        return $targetAudienceAttributes;

    }
}
?>