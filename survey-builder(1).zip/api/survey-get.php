<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

///////////////////////////////////////////////////////// Prep
include "_includes.php";

$out = new DataPacket();

$auth = new Auth();

$auth->fromSession($conn);

$dataOut = new stdClass();

///////////////////////////////////////////////////////// Prep


$surveyID = clean($conn, getVar("surveyID"));
$surveyGuid = clean($conn, getVar("surveyGuid"));

$survey = new Survey();

if($surveyID <= 0)
{
    $surveyID = getKey($conn, "Select max(surveyID) from survey.survey where userID = " . $auth->getUserID());
}

if($surveyID != "")
{
    $survey->loadFromDatabase($conn, $surveyID);
    
    $dataOut->survey = $survey->getSurveyData($conn, $surveyID);
}

///////////////////////////////////////////////////////// Send Data

$out->data = $dataOut;

header('Content-type: application/json');

echo $out->generateOutput($auth);

/////////////////////////////////////////////////////////


?>