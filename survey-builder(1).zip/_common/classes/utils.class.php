<?php
class Utils
{
    public $debug = "verbose";
    public $tradeUrl = "";
    public $log = "";
    public $beSilent = false;

    public function __construct()
    { 
        $config = getAppConfig();

        //$this->tradeUrl = $config["trade-url"];
    }

    public function getPriorDateID($conn, $dateID, $numDays)
    {
        $sql = "select min(dateID) as numDBDays from (select dateID from dim_date where dateID < $dateID and isTradeDay = 'Y' order by dateID desc limit $numDays) as a";
        return getKey($conn, $sql);
    }

    public function getFutureDateID($conn, $dateID, $numDays)
    {
        $sql = "select max(dateID) as numDBDays from (select dateID from dim_date where dateID > $dateID and isTradeDay = 'Y' order by dateID limit $numDays) as a";
        return getKey($conn, $sql);
    }


    public function createPortfolio($conn, $userID, $config)
    {

        $debugThis = false;
        
        if($debugThis) $this->debug("utils.createPortfolio()");
        
        $sql = "select u.userID, username, userGuid, authToken 
                    from pat_user u
                    where userID = $userID";

        $portfolioUser = getDataObject($conn, $sql);

        $dataOut = array('userGuid'=>$portfolioUser->userGuid
                            ,'portfolioType'=>$config->portfolioType
                            ,'portfolioName'=>$config->portfolioName
                            ,'startingBalance'=>$config->startingBalance);
                              
        $url = $this->tradeUrl . "/create-portfolio.php";

        $data = callAPI("POST", $url, $dataOut);
        
        if($debugThis) 
        {
            $this->debug("**************************************************");
            $this->debug("*            Add Portfolio API call              *");
            $this->debug("**************************************************");
            $this->debug("Request....");
            $this->debug($url);
            print_r($dataOut);
            $this->debug("Response....");
            print_r($data);
            $this->debug("**************************************************");
        }

        $data = json_decode($data, true);

        $portfolio = $data["data"]["portfolio"];
        
        if($debugThis) print_r($portfolio);
        
        if($debugThis) $this->debug("Debug:" . $this->debug . " PortfolioID:" . $portfolio["portfolioID"] . " Balance: " . $portfolio["portfolioBalance"]);

        return $portfolio["portfolioID"];

    }    


    
    public function placeSell($conn, $portfolioID, $symbolID, $market,$sellDateID, $sellTimeID, $sellPrice, $numShares, $sellReason)
    {
        $debugThis = false;

        if($debugThis) $this->debug("utils.placeSell()");

        $sellPrice = preg_replace('/[^0-9-.]+/', '', $sellPrice);

        $numShares = preg_replace('/[^0-9-.]+/', '', $numShares);
        
        $success = true;
        
        $sql = "update pat_trader_order set orderStatus='CANCEL', reason=CONCAT(reason,' New Order placed') 
                   where portfolioID = $portfolioID 
                   and symbolID = '$symbolID'
                   and numShares = $numShares
                   and orderStatus ='PENDING'";
                   
        executeQuery($conn, $sql);
       
        $url = $this->tradeUrl . "/new-sell-order.php";
        $params =  array(
                            'userGuid' => $this->getUserGuidByPortfolio($conn, $portfolioID)
                            ,'portfolioID' => $portfolioID
                            ,'symbolID' => $symbolID
                            ,'market' => $market
                            ,'sellDateID' => $sellDateID
                            ,'sellTimeID' => $sellTimeID
                            ,'sellPrice'=> $sellPrice
                            ,'numShares' => $numShares
                            ,'sellReason' => $sellReason
                );
        
        if($debugThis)
        {
            $this->debug("Sell Order-------------------------------------------------");
            print_r($params);
        }
        
        
   
        if($debugThis) $this->debug("utils.placeSell(): $symbolID Shares: $numShares  DateID: $sellDateID TimeID: $sellTimeID Price: $sellPrice sellReason: $sellReason portfolioID: $portfolioID");
   
        
   
        $data = callAPI("POST", $url, $params);
        
        $response = json_decode($data, true);
        
        if($response["error"]["errorID"]  != "0" || $response == "")
        {
            if($debugThis) $this->debug("utils.placeSell(): Somethings wrong");
   
            if($debugThis) print "Request\r\n";
            if($debugThis) print_r($params);
            
            if($debugThis) print "Response\r\n";
            if($debugThis) print_r($data);
   
            if($this->stopOnError) die("utils.placeSell() - FAILED");
        }
   
   
        if($response["error"]["errorID"]  != "0")
        {
            if($debugThis) $this->debug("utils():  Order Failed");
            $success = false;
        }
        else
        {
            if($debugThis) $this->debug("utils(): Order Sent");
            $success = true;
        }
   
        return $success;
    }    
   

    
    public function processSellOrders($conn, $portfolioID, $tradeDateID)
    {
        $debugThis = false;

        if($debugThis) $this->debug("processSellOrders(portfolioID = $portfolioID, tradeDateID = $tradeDateID)");

        $sql = "select o.orderID
                ,p.portfolioID
                ,o.symbolID
                ,o.symbol 
                ,o.askingDateID
                ,o.orderType 
                ,o.orderStatus
                ,o.askingPrice 
                ,o.numShares 
                ,(o.askingPrice * o.numShares) + p.commissionPrice as totalInvested
                ,p.commissionPrice
                ,o.reason
                ,p.userID
            from pat_trader_order o 
            inner join pat_trader_portfolio p on p.portfolioID = o.portfolioID and p.isActiveRecord = 1
            where o.isDeleted = 0
            and o.portfolioID = $portfolioID
            and o.orderType ='Sell'
            and o.orderStatus = 'PENDING'
            and o.askingDateID <= $tradeDateID
            order by o.askingPrice
            ";

            
        if($debugThis) $this->debug($sql);

        $q = executeQuery($conn, $sql);


        while($order = mysqli_fetch_object($q))
        {
            if($debugThis) $this->debug("processSellOrders(): orderID = $order->orderID, stock = $order->symbol, askingPrice = $order->askingPrice");
                
            $sellPrice = $order->askingPrice;

            if($sellPrice == 99999999)
            {
                $sql = "select dailyOpen
                    from pat_stock_history_daily
                    where dateID = $tradeDateID
                    and isEOD = 1
                    and symbolID = $order->symbolID";

                $sellPrice = getKey($conn, $sql);

                if($debugThis) $this->debug($sql);

                if($debugThis) $this->debug("processSellOrders(): Finding market price: $sellPrice");

                if($sellPrice <= 0)
                {
                    $this->debug("processSellOrders() WARNING - no data found for $order->symbol on $tradeDateID");
                    return;
                }

            }


            $sql = "select count(*)
                    from pat_stock_history_daily
                    where dateID = $tradeDateID
                    and isEOD = 1
                    and $sellPrice between Round(dailyLow,2) and Round(dailyHigh,2)
                    and symbolID = $order->symbolID";

            $numMatches = getKey($conn, $sql);

            if($numMatches <= 0)
            {
                $this->debug("processSellOrders(): ...$order->symbol Daily high and  low not in range, (askingPrice: $sellPrice) order ignored");
            }

            if($numMatches > 0)
            {
                $this->debug("processSellOrders(): ...sell order executed: $order->symbol sellPrice: $sellPrice");
                
                $totalInvested = ($sellPrice * $order->numShares) + $order->commissionPrice;                    

                $sql = "call pat_update_portfolio($portfolioID, 'Selling $order->symbol',$tradeDateID,800, $totalInvested )";
                    
                executeQuery($conn, $sql);

                if($debugThis) $this->debug($sql);
                    

                $sql = "select min(tradeID) 
                        from pat_trader_trade
                        where symbolID = $order->symbolID
                        and tradeStatus = 'Holding'
                        and numShares >= $order->numShares
                        and portfolioID = $portfolioID
                        ";
                    
                $tradeID = getKey($conn, $sql);

                if($debugThis) $this->debug($sql);

                if($debugThis) $this->debug("processSellOrders()...buy trade found: tradeID = $tradeID, orderID: $order->orderID");

                if($tradeID <= 0)
                {
                    if($debugThis) $this->debug("processSellOrders(): ...WARNING - No open position found!");

                    $sql = "update pat_trader_order
                    set orderStatus = 'CANCELED'
                    ,askingPrice = $sellPrice
                    ,commissionPaid = $order->commissionPrice
                    ,reason = 'No open position found'
                    where orderID = $order->orderID";

                    if($debugThis) $this->debug($sql);
                        
                    executeQuery($conn, $sql);
                }
                else
                {

                    $sql = "update pat_trader_order
                    set askingPrice = $sellPrice
                    where orderID = $order->orderID
                    and askingPrice = 99999999";

                    if($debugThis) $this->debug($sql);
                        
                    executeQuery($conn, $sql);

                    $sql = "update pat_trader_order
                    set buyTradeID = $tradeID
                    where orderID = $order->orderID
                    and buyTradeID is null";

                    if($debugThis) $this->debug($sql);
                        
                    executeQuery($conn, $sql);


                    $sql = "update pat_trader_trade
                        set sellOrderID = $order->orderID
                            ,sellPrice = $sellPrice
                            ,sellDateID = $tradeDateID
                            ,sellTimeID = 800
                            ,sellDateTime = DATE($tradeDateID)
                            ,tradeStatus = 'CLOSED'
                            ,sellReason = '$order->reason'
                        where tradeID = $tradeID";

                    if($debugThis) $this->debug($sql);
                        
                    executeQuery($conn, $sql);

                    if($debugThis) $this->debug("processSellOrders()...sell trade updated");

                            
                    $sql = "update pat_trader_order
                        set orderStatus = 'EXECUTED'
                        where orderID = $order->orderID";

                    if($debugThis) $this->debug($sql);
                        
                    executeQuery($conn, $sql);

                }


                if($debugThis) $this->debug("processSellOrders()...order status updated");
            
                
            }

            
        }
    }




    public function placeBuy($conn, $portfolioID, $symbolID, $market,$buyDateID, $buyTimeID, $buyPrice, $numShares, $buyAtMarket)
    {
        $debugThis = false;
        
        $buyPrice = preg_replace('/[^0-9-.]+/', '', $buyPrice);

        $numShares = preg_replace('/[^0-9-.]+/', '', $numShares);


        $symbol = getKey($conn, "select symbol from pat_stock where symbolID = $symbolID");

        if($debugThis) $this->debug("utils.placeBuy(portfolioID = $portfolioID, $symbolID, buyDateID = $buyDateID buyPrice = $buyPrice numShars = $numShares)");

        $success = true;

        $url = $this->tradeUrl . "/new-buy-order.php";

        $params =  array(
            'userGuid' => $this->getUserGuidByPortfolio($conn, $portfolioID)
            ,'portfolioID' => $portfolioID
            ,'symbolID' => $symbolID
            ,'market' => $market
            ,'buyDateID' => $buyDateID
            ,'buyTimeID' => $buyTimeID
            ,'buyPrice'=> $buyPrice
            ,'numShares' => $numShares
            ,'buyAtMarket' => $buyAtMarket
        );
        

        if($debugThis)  $this->debug("Buy Order");
        if($debugThis) print_r($params);

        if($debugThis) $this->debug("utils.placeBuy():  $symbol Shares: $numShares  DateID: $buyDateID TimeID: $buyTimeID Price: $buyPrice");
        if($debugThis) $this->debug("");
        if($debugThis) $this->debug("utils.placeBuy()");
        if($debugThis) $this->debug("url: $url");
        if($debugThis) $this->debug("...Buy Order - Internal");
        if($debugThis) $this->debug("...SymbolID: $symbolID");
        if($debugThis) $this->debug("...Stock: $symbol");
        if($debugThis) $this->debug("...BuyPrice: $buyPrice");
        if($debugThis) $this->debug("...NumShares: $numShares");
        if($debugThis) $this->debug("...Invested: " . ($numShares * $buyPrice));
        if($debugThis) $this->debug("...Buy At Market: " . $buyAtMarket);
        if($debugThis) $this->debug("...BuyDateID: $buyDateID");
        if($debugThis) $this->debug("...BuyTimeID: $buyTimeID");
        if($debugThis) $this->debug("");

        $data = callAPI("POST", $url, $params);

        $response = json_decode($data,true);

        if($response["error"]["errorID"]  != "0" && $debugThis )
        {
            $this->debug("utils.placeBuy(): Somethings wrong");

            print "Request\r\n";
            print_r($params);

            print "Response\r\n";
            print_r($data);

            if($this->stopOnError) die("utils.placeBuy() - FAILED");
        }
        //print_r($response);

        if($response["error"]["errorID"]  != "0" )
        {
            if($debugThis)$this->debug("utils.placeBuy(): Order Failed");
            $success = false;
        }
        else
        {
            if($debugThis)$this->debug("utils.placeBuy(): Order Sent");
        }

        return $success;
    }



    public function cancelAllBuyOrders($conn, $backTest, $tradeDateID, $reason)
    {
        $debugThis = false;

        if($debugThis) $this->debug("utils.cancelAllBuyOrders(portfolioID = $portfolioID, tradeDateID = $tradeDateID)");

        $sql = "select o.orderID
                ,p.portfolioID
                ,o.symbolID
                ,o.symbol 
                ,o.askingDateID
                ,o.orderType 
                ,o.orderStatus
                ,o.askingPrice 
                ,o.numShares 
                ,(o.askingPrice * o.numShares) + p.commissionPrice as totalInvested
                ,p.commissionPrice
                ,o.reason
                ,p.userID
            from pat_trader_order o 
            inner join pat_trader_portfolio p on p.portfolioID = o.portfolioID and p.isActiveRecord = 1
            where o.isDeleted = 0
            and o.portfolioID = $backTest->portfolioID
            and o.orderType ='Buy'
            and o.orderStatus = 'PENDING'
            order by o.askingPrice
            ";
         
        if($debugThis)  $this->debug($sql);

        $q = executeQuery($conn, $sql);
            

        while($order = mysqli_fetch_object($q))
        {
            
            $this->debug("...canceling buy order $order->symbol $order->askingDateID");

            $sql = "update pat_trader_order
            set orderStatus = 'CANCELED'
            ,reason = '$reason'
            where orderID = $order->orderID";

            executeQuery($conn, $sql);
        }
    }



    public function processBuyOrders($conn, $portfolioID, $tradeDateID)
    {
        $debugThis = false;

        if($debugThis) $this->debug("utils.processBuyOrders(portfolioID = $portfolioID, tradeDateID = $tradeDateID)");

        $sql = "select o.orderID
                ,p.portfolioID
                ,o.symbolID
                ,o.symbol 
                ,o.askingDateID
                ,o.orderType 
                ,o.orderStatus
                ,o.askingPrice 
                ,o.numShares 
                ,(o.askingPrice * o.numShares) + p.commissionPrice as totalInvested
                ,p.commissionPrice
                ,o.reason
                ,p.userID
            from pat_trader_order o 
            inner join pat_trader_portfolio p on p.portfolioID = o.portfolioID and p.isActiveRecord = 1
            where o.isDeleted = 0
            and o.portfolioID = $portfolioID
            and o.orderType ='Buy'
            and o.orderStatus = 'PENDING'
            and o.askingDateID <= $tradeDateID
            order by o.askingPrice
            ";
         
        if($debugThis)  $this->debug($sql);

        $q = executeQuery($conn, $sql);
            

        while($order = mysqli_fetch_object($q))
        {
            $this->debug("processBuyOrders(): orderID = $order->orderID, stock = $order->symbol");

            $sql = "select count(*)
                    from pat_stock_history_daily
                    where dateID = $tradeDateID
                    and isEOD = 1
                    and $order->askingPrice between dailyLow and dailyHigh
                    and symbolID = $order->symbolID";

                    if($debugThis) $this->debug($sql);

            $numMatches = getKey($conn, $sql);

            if($numMatches <= 0)
            {
                $this->debug("processBuyOrders(): ...Daily high and  low not in range, order ignored");
                
            }

            if($numMatches > 0)
            {
                $this->debug("processBuyOrders(): --------------------------------");
                $this->debug("processBuyOrders(): Order Filled: ");
                $this->debug("...symbol: $order->symbol");
                $this->debug("...orderID: $order->orderID");
                $this->debug("...askingPrice: $order->askingPrice");
                $this->debug("...askingDateID: $order->askingDateID");
                $this->debug("...tradeDateID: $tradeDateID");
                

                $executionPrice = $order->askingPrice;


                $sql = "insert into pat_trader_trade(
                                tradeID,
                                portfolioID,
                                userID,
                                symbolID,
                                symbol ,
                                tradeStatus,
                                numShares ,
                                buyOrderID ,
                                buyPrice ,
                                buyDateID ,
                                buyTimeID ,
                                buyDateTime ,
                                commissionPaid,
                                isDeleted ,
                                insertDateTime ,
                                modifiedDateTime 	
                                )
                                values (
                                    null 
                                    ,$order->portfolioID
                                    ,$order->userID
                                    ,$order->symbolID
                                    ,'$order->symbol' 
                                    ,'HOLDING'
                                    ,$order->numShares
                                    ,$order->orderID
                                    ,$order->askingPrice
                                    ,$tradeDateID
                                    ,800
                                    ,DATE($tradeDateID)
                                    ,$order->commissionPrice
                                    ,0
                                    ,NOW()
                                    ,NOW()
                                )";
                executeQuery($conn, $sql);
                
                $buyTradeID = getKey($conn, "select max(tradeID) from pat_trader_trade where portfolioID = $order->portfolioID and symbolID = $order->symbolID");

                
                $sql = "update pat_trader_order
                set orderStatus = 'EXECUTED'
                ,commissionPaid = $order->commissionPrice
                ,buyTradeID = '$buyTradeID'
                where orderID = $order->orderID";
                    
                executeQuery($conn, $sql);

                $sql = "call pat_update_portfolio($order->portfolioID, 'Buying $order->symbol',$tradeDateID,800, $order->totalInvested *-1 )";
                executeQuery($conn, $sql);

            }
        }
    }

    public function getUserGuidByPortfolio($conn, $portfolioID)
    {
        $sql = "select userGuid
        from pat_user u
        inner join pat_trader_portfolio p on p.userID = u.userID and p.isActiveRecord=1
        where p.portfolioID = $portfolioID";

        $userGuid = getKey($conn, $sql);

        return $userGuid;
    }

    public function getMaxDateID($conn)
    {
        $sql = "select varVal from pat_stock_vars where varKey = 'maxLoadedDateID'";
        //debug($sql);
        return getKey($conn, $sql);
    }

    
    public function getLastTradeDateID($conn, $dateID)
    {
        $sql = "select max(dateID) from dim_date where dateID <= $dateID and isTradeDay = 'Y'";
        
        //debug($sql);

        return getKey($conn, $sql);
    }



    public function debug($msg)
    {
        if(!$this->beSilent) print $msg . "\r\n<br>";

        $this->log.=$msg . "\r\n<br>";
    }

    public function secsToString($secs)
    {
        $out = "";
        $secsLeft = $secs;
        if($secsLeft > 60)
        {
            $min = round($secsLeft / 60);
            $secsLeft = $secsLeft - ($min * 60);
            $out = "$min mins and $secsLeft secs";
        }
        else
        {
            $out = $secsLeft;
        }

        return round($out, 2) . " secs";

    }


    public function getDefaultPortfolioConfig()
    {
        $out = new stdClass();
        $out->portfolioName = "Default";
        $out->portfolioType = "general";
        $out->startingBalance = 10000;
        
        return $out;
    }
}



?>