<?php 

class OpenAiWrapper{

    private $apiKey;

    public function __construct()
    {
        $config = getAppConfig();
        
        $this->apiKey =  $config["openAiKey"];
    }

    public function createPrompt($role, $content)
    {
        $prompt = new stdClass();
        $prompt->role = $role;
        $prompt->content = $content;

        return $prompt;
    }

    public function getResponse($prompts)
    {
        
        $client = OpenAI::client($this->apiKey);
            
        $result = $client->chat()->create([
            'model' => 'gpt-4',
            'messages' => $prompts
        ]);
        
        $reply = $result['choices'][0]['message']['content'];

        return $reply;
            
    }


    public function getJsonResponse($prompts)
    {
        
        $client = OpenAI::client($this->apiKey);
    
        $responseFormat = new stdClass();
    
        $responseFormat->type =  'json_object';
        
        $result = $client->chat()->create([
            'model' => 'gpt-3.5-turbo',
            'response_format' =>$responseFormat,
            'messages' => $prompts
        ]);
        
        $replyRaw = $result['choices'][0]['message']['content'];

        $replyJson = json_decode($replyRaw);

        if(!isset($replyJson) && $replyRaw != "")
        {
            debug("OH NO, issue with JSON Formatting");
            debug("Raw:" . $replyRaw);
        }
        
        return $replyJson;
            
    }    

}

?>
