<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

///////////////////////////////////////////////////////// Prep
include "_includes.php";

include "../_common/classes/survey.class.php";

$out = new DataPacket();

$auth = new Auth();

$auth->fromSession($conn);

$dataOut = new stdClass();

///////////////////////////////////////////////////////// Prep


$surveyID = clean($conn, getVar("surveyID"));
$surveyGuid = clean($conn, getVar("surveyGuid"));

$survey = new Survey();
$dataOut = $survey->getYourSurveyParams($conn);
///////////////////////////////////////////////////////// Send Data

$out->data = $dataOut;

header('Content-type: application/json');

echo $out->generateOutput($auth);

/////////////////////////////////////////////////////////


?>