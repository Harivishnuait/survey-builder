<?php

///////////////////////////////////////////////////////// Prep
include "_includes.php";

$out = new DataPacket();

$auth = new Auth();

$auth->fromSession($conn);

$dataOut = new stdClass();

///////////////////////////////////////////////////////// Prep

$survey = new Survey();

$survey->debug = $debug;

$surveyID = clean($conn, getVar("surveyID"));
$moduleCategoryID = clean($conn, getVar("moduleCategoryID"));
$answer = clean($conn, getVar("answer"));

if($surveyID <= 0) $surveyID = $_SESSION["lastSurveyID"];

if($debug == "Y")
{
    debug("Add Module");
    debug("surveyID = $surveyID ");
    debug("answer = $answer");
    debug("moduleCategoryID = $moduleCategoryID");
}

$survey->loadFromDatabase($conn, $surveyID);
$survey->setAuth($auth);

$sql = "select * from survey_modules_category where moduleCategoryID = $moduleCategoryID";

$moduleCategory = getDataObject($conn, $sql);

$factKey = "$moduleCategory->moduleCategoryName";
$factQuestion = "$moduleCategory->promptForHuman";
$factAnswer = $answer;

$survey->saveReplaceFact($auth, $factKey,  $factQuestion, $factAnswer);

$sql = "select * from survey_modules where moduleCategory = '$moduleCategory->moduleCategoryName'";

if($debug =="Y") debug($sql);

$q = executeQuery($conn, $sql);

while($module = mysqli_fetch_object($q))
{
    $numQuestions = clean($conn, getVar("num_questions_" . $module->moduleID));
    
    $survey->genModule($module->moduleID, $numQuestions);

}

$dataOut->survey = $survey->getSurveyData($conn, $surveyID);

///////////////////////////////////////////////////////// Send Data

$out->data = $dataOut;

header('Content-type: application/json');

echo $out->generateOutput($auth);

/////////////////////////////////////////////////////////


?>