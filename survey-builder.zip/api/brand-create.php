<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

///////////////////////////////////////////////////////// Prep
include "_includes.php";

$out = new DataPacket();

$auth = new Auth();

$auth->fromSession($conn);

$dataOut = new stdClass();

///////////////////////////////////////////////////////// Prep

include "../_common/classes/brand.class.php";

$brand = new Brand();

$brandNames = isset($_GET['brand-names']) ? explode(',', $_GET['brand-names']) : [];

foreach ($brandNames as $brandName) {
    $params = new stdClass();

    $params->brandName = clean($conn, $brandName);

    $isAlreadyExist = $brand->brandDataExist($conn, $params->brandName);
    if (!isset($isAlreadyExist->brandID)) {
        $brandID = $brand->createBrand($conn, $auth, $params);
        $brand->loadBrand($conn, $auth->userID, $brandID);
        $dataOut->message = "Brand '$params->brandName' created Successfully";
        $dataOut->code    = "success";
    } else {
        $dataOut->message = "Brand '$params->brandName' Already Exists";
        $dataOut->code    = "exist";
    }
}



///////////////////////////////////////////////////////// Send Data

$out->data = $dataOut;

header('Content-type: application/json');

echo $out->generateOutput($auth);

/////////////////////////////////////////////////////////


?>