<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

///////////////////////////////////////////////////////// Prep
include "_includes.php";

$out = new DataPacket();

$auth = new Auth();

$auth->fromSession($conn);

$dataOut = new stdClass();

///////////////////////////////////////////////////////// Prep

include "../_common/classes/survey.class.php";

$surveyID = clean($conn, getVar("survey-id"));
$sectionIndex = clean($conn, getVar("section-index"));

$survey = new Survey();

$survey->loadSurvey($conn, $auth->userID, $surveyID);

$survey->removeSection($conn, $sectionIndex);

$dataOut = $survey->getSurveyData($conn, $surveyID);

///////////////////////////////////////////////////////// Send Data

$out->data = $dataOut;

header('Content-type: application/json');

echo $out->generateOutput($auth);

/////////////////////////////////////////////////////////


?>