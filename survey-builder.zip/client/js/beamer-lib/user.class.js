function User(config) {
  this.config = config;

  this.userID = -1;
  this.userGuid = -1;
  this.userName = "Guest";
  this.authToken = "";
  this.connectToServer = false;
  this.lastActionTime = new Date();
  this.debug = true;
  this.appStarted = false;
  this.autoStart = true;
  this.secsToInactivity = 120;
  this.callback = "";

  this.init = function (callBack) {
    this.callback = callBack;

    this.userGuid = this.isNull(dataHandler.getData("userGuid"), -1);

    if (this.debug) {
      console.log("user.init()");

      console.log("...user.init(): guid on file: " + this.userGuid);
    }

    if (this.userGuid == -1) {
      if (this.debug) console.log("...user.init(): no userGuid found");

      window.location.href = "login.html";
    } else {
      console.log("...user.init(): attempting to get userID for guid");

      dataHandler.sendDataAndCallBack(
        this.config.authUrl + "get-user.php?",
        {},
        function (data) {
          user.syncUser(data);

          startAppAfterLogin();
        }
      );
    }

    this.lastActionTime = new Date();
  };

  this.getData = function () {
    return this.config;
  };

  this.loginCheck = function () {
    return this.userID > 0;
  };

  this.syncUser = function (data) {
    this.userID = data.userID;

    this.username = data.username;
  };

  this.checkAndStartApp = function () {
    if (!user.appStarted) {
      console.log("User.sync(): starting app");

      if (user.config.startAppAfterAuth) {
        user.appStarted = true;

        app.loadAfterLogin();
      }

      //startApp();
    }
  };

  this.createGuestAccount = function () {
    this.userGuid = data.generateGuid();

    if (this.debug)
      console.log(
        "...user.createGuestAccount(): new guid gen:" + this.userGuid
      );

    data.save("userGuid", this.userGuid);

    if (this.connectToServer) {
      data.sendDataAndCallBack(
        "api/user-create-guest-account.php",
        {},
        user.sync
      );
    }
  };

  this.login = function (config, userData) {
    var url = config.authUrl + "login.php";
 
    dataHandler.sendPostData(url, userData, function (data) {
      user.userID = data.userID;

      user.userGuid = data.userGuid;
      user.roleID = data.roleID;
      user.userID = data.userID;
      //  alert(user.roleID);
      console.log("userID Set:" + user.userID);

      console.log("userGuid Set:" + user.userGuid);
      console.log("roleID Set: " + user.roleID);

      dataHandler.saveData("userGuid", user.userGuid);

      dataHandler.saveData("userID", user.userID);

      dataHandler.saveData("last-user-guid", user.userGuid);

      dataHandler.saveData("last-user-id", user.userID);

      startApp();
    });
  };

  this.register = function (config, userData) {
    var url = config.authUrl + "/register.php";

    dataHandler.sendPostData(url, userData, function (data) {
      user.userID = data.userID;

      user.userGuid = data.userGuid;

      console.log("userID Set:" + user.userID);

      console.log("userGuid Set:" + user.userGuid);

      dataHandler.saveData("userGuid", user.userGuid);

      dataHandler.saveData("userID", user.userID);

      dataHandler.saveData("last-user-guid", user.userGuid);

      dataHandler.saveData("last-user-id", user.userID);

      startApp();
    });
  };

  this.forgotPassword = function (config, userData) {
    var url = config.authUrl + "forgotPassword.php";

    utils.growl("Loading...", 10000);
    dataHandler.sendPostData(url, userData, function (data) {
      utils.hideGrowl("Loading");
      toastr.success("Password reset link sent successfully."); // Display success message
    });
  };

  this.resetPassword = function (config, userData) {
    var url = config.authUrl + "resetPassword.php";

    dataHandler.sendPostData(url, userData, function (data) {
      user.userID = data.userID;

      user.userGuid = data.userGuid;

      console.log("userID Set:" + user.userID);

      console.log("userGuid Set:" + user.userGuid);

      startLoginApp();
    });
  };

  this.isInactive = function () {
    var secsPast = this.secsSinceLastActivity();

    return secsPast > this.secsToInactivity;
  };

  this.secsSinceLastActivity = function () {
    var currDate = new Date();

    var secsPast = (currDate.getTime() - this.lastActionTime.getTime()) / 1000;

    return secsPast;
  };

  this.tookAction = function () {
    this.lastActionTime = new Date();
  };

  this.logout = function (redirect) {
    this.userID = -1;
    this.userGuid = "";

    var url = config.authUrl + "logout.php";

    dataHandler.sendPostData(url, {}, function (data) {
      dataHandler.saveData("userGuid", "");

      dataHandler.saveData("userID", -1);

      dataHandler.saveData("last-user-guid", this.userGuid);

      dataHandler.saveData("last-user-id", this.userID);

      window.location.href = redirect;
    });
  };

  this.isNull = function (val, defaultVal) {
    if (val) {
      return val;
    }
    return defaultVal;
  };
  this.getUserID = function () {
    return this.userID;
  };
}
