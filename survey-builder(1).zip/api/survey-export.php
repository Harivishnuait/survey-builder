    <?php
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);

    ///////////////////////////////////////////////////////// Prep
    include "_includes.php";

    
    use TCPDF as PDF;
    use PhpOffice\PhpWord\PhpWord;
    use PhpOffice\PhpWord\IOFactory;
    

    //ob_start();

    $out = new DataPacket();

    $auth = new Auth();

    $auth->fromSession($conn);

    $dataOut = new stdClass();

    ///////////////////////////////////////////////////////// Prep

    $exportType = clean($conn, getVar("export-type"));
    $surveyID = clean($conn, getVar("surveyID"));

    $survey = new Survey();


    $survey->loadFromDatabase($conn, $surveyID);
    
    if ($exportType == "EXCEL" || $exportType == "CSV") {

        $fileName = "survey-" . $survey->getSurveyGuid() . ".csv";

        $data = [];

        $headers = ["question_num","question","question_type","answers"];
        
        $data[] = $headers;

        $sections = $survey->surveyDataObj->sections;
        
        foreach ($sections as $section) {
            foreach ($section->questions as $question) {
                $row = [$question->question_num];
                $row[] = $question->question_text;
                $row[] = $question->question_type;

                if (property_exists($question, 'answers')) {
                    foreach ($question->answers as $answer) {
                        $row[] = $answer->answer_text;
                        if($answer->terminate_survey) 
                        {
                            $row[] = "[TERMINATE SURVEY]";
                        }
                        //$row[] = $answer->programming_notes;
                    }
                }
                $data[] = $row;
            }
        }


        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=csv_export.csv');

        $output = fopen('php://output', 'w');

        foreach ($data as $data_item) {
            fputcsv($output, $data_item);
        }

        fclose($output);
        
        exit;
    }



    if ($exportType == "PDF") {
        $fileName = "survey-" . $survey->getSurveyGuid() . ".pdf";

        $questions = $survey->data->surveyObj->survey->survey_sections;

        // Create a new PDF instance
        $pdf = new PDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

        // Set document information
        $pdf->SetCreator(PDF_CREATOR);
        $pdf->SetAuthor('Your Name');
        $pdf->SetTitle('Survey Report');
        $pdf->SetSubject('Survey Data');
        $pdf->SetKeywords('Survey, Data, Report');

        // Remove default header/footer
        $pdf->setPrintHeader(false);
        $pdf->setPrintFooter(false);

        // Add a page
        $pdf->AddPage();

        // Set font
        $pdf->SetFont('helvetica', '', 10);

        $sections = $survey->surveyDataObj->sections;

        foreach ($sections as $section) {
            foreach ($section->questions as $question) {
                $txt = $question->question_num . ": " . $question->question_text;
                $pdf->Cell(0, 10, $txt, 0, 1);

                if (property_exists($question, 'answers')) {
                    foreach ($question->answers as $answer) {
                        $answerTxt = $answer->answer_text;
                        
                        if($answer->terminate_survey) 
                        {
                            $answerTxt.="[TERMINATE SURVEY]";
                        }

                        $pdf->Cell(0, 10, $answerTxt, 0, 1);
                    }
                }
                $data[] = $row;
            }
        }

        // Close and output PDF
        $pdf->Output($fileName, 'D');
        exit;
    }

    if ($exportType == "JSON") {
        $questions = $survey->data->surveyObj->survey->survey_sections;

        ob_start();

        header('Content-Type: text/json; charset=utf-8');
        header('Content-Disposition: attachment; filename=json_export.json');

        ob_end_clean();

        echo json_encode($survey->data->surveyObj, JSON_PRETTY_PRINT);
    }

    if ($exportType == "WORD") {
        $fileName = "survey-" . $survey->data->surveyGuid . ".docx";

        $questions = $survey->data->surveyObj->survey->survey_sections;

        $phpWord = new PhpWord();

        $section = $phpWord->addSection();

        foreach ($questions as $sectionData) {
            foreach ($sectionData->survey_section_questions as $questionData) {
                $section->addText($questionData->question);

                foreach ($questionData->answers as $answer) {
                    $section->addText($answer);
                }
            }
        }

        $objWriter = IOFactory::createWriter($phpWord, 'Word2007');
        header('Content-Type: application/octet-stream');
        header("Content-Disposition: attachment; filename=$fileName");
        $objWriter->save('php://output');
        exit;
    }



    ?>