<?php
class SurveyParams
{
    public $surveyName = "";
    public $researchGoals = "";
    public $surveyType = "";
    public $productStatus = "";
    public $targetAudienceDesc = "";
    public $targetAudienceAttributes = "";
    public $brands = [];
    public $attributes = [];
    public $domains = [];
    public $surveyModules = [];

}


class SurveyDataObj
{
    public $formatVersion = "1.0";
    public $surveyID = 0;
    public $title = "";
    public $loi = 0;
    public $description = "";
    public $sections = [];
    public $params;
}

class SurveySection
{
    public $section_num = 0;
    public $sectionIdx = 0;
    public $sectionType = "";
    public $title = "";
    public $description = "";
    public $moduleCategory = "";
    public $moduleTitle = "";
    public $questions = [];
        
}


class SurveyQuestion
{
    public $question_num = 0;
    public $question_type = "";
    public $question_text = "";
    public $answers = [];
        
}

class SurveyQuestionAnswer
{
    public $answer_num = 0;
    public $answer_text = "";
    public $answer_note = "";
    public $terminate_survey = false;
    public $programming_notes = [];
        
}

class SurveyPrompt
{
    public $sent = "";
    public $responseRaw = "";
    public $response = "";
    public $moduleTitle = "";

}
?>
