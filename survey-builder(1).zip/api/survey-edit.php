<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

///////////////////////////////////////////////////////// Prep
include "_includes.php";

$out = new DataPacket();

$auth = new Auth();

$auth->fromSession($conn);

$dataOut = new stdClass();

///////////////////////////////////////////////////////// Prep

$surveyID = clean($conn, getVar("survey-id"));

$action = clean($conn, getVar("action"));

$survey = new Survey();

$survey->debug = $debug;

$survey->loadFromDatabase($conn, $surveyID);


if($action == "save-objective")
{
    $objectiveTitle = clean($conn, getVar("objective-title"));
    $objectiveText = clean($conn, getVar("objective-text"));

    $survey->saveObjective($conn, $objectiveTitle, $objectiveText);

    $survey->saveSurvey($conn, $auth);

}


if($action == "save-section-header")
{
    $sectionIdx = clean($conn, getVar("section-idx"));
    $title = clean($conn, getVar("section-title"));
    $desc = clean($conn, getVar("section-desc"));

    $survey->saveSectionHeader($conn, $sectionIdx, $title, $desc);

    $survey->saveSurvey($conn, $auth);

}



if($action == "save-question")
{
    $sectionIdx = clean($conn, getVar("section-idx"));
    $questionIdx = clean($conn, getVar("question-idx"));
    $questionText = clean($conn, getVar("question-text"));

    $survey->saveQuestion($conn, $sectionIdx, $questionIdx, $questionText);

    $survey->saveSurvey($conn, $auth);
}



if($action == "save-notes")
{
    $sectionIdx = clean($conn, getVar("section-idx"));
    $questionIdx = clean($conn, getVar("question-idx"));
    $answerIdx = clean($conn, getVar("answer-idx"));
    $answerNote = clean($conn, getVar("answer-notes"));

    $survey->saveAnswerNote($conn, $sectionIdx, $questionIdx, $answerIdx, $answerNote);

    $survey->saveSurvey($conn, $auth);
}


if($action == "save-answer")
{
    $sectionIdx = clean($conn, getVar("section-idx"));
    $questionIdx = clean($conn, getVar("question-idx"));
    $answerIdx = clean($conn, getVar("answer-idx"));
    $answerText = clean($conn, getVar("answer-text"));

    $survey->saveAnswer($conn, $sectionIdx, $questionIdx, $answerIdx, $answerText);

    $survey->saveSurvey($conn, $auth);
}



if($action == "remove-answer")
{
    $sectionIdx = clean($conn, getVar("section-idx"));
    $questionIdx = clean($conn, getVar("question-idx"));
    $answerIdx = clean($conn, getVar("answer-idx"));

    $survey->removeAnswer($conn, $sectionIdx, $questionIdx, $answerIdx);

    $survey->saveSurvey($conn, $auth);

}



$dataOut = $survey->getSurveyData($conn, $surveyID);

///////////////////////////////////////////////////////// Send Data

$out->data = $dataOut;

header('Content-type: application/json');

echo $out->generateOutput($auth);

/////////////////////////////////////////////////////////


?>