<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

///////////////////////////////////////////////////////// Prep
include "_includes.php";

$out = new DataPacket();

$auth = new Auth();

$auth->fromSession($conn);

$dataOut = new stdClass();

///////////////////////////////////////////////////////// Prep

include "../_common/classes/attributes.class.php";

$productStatus = '[
    {"key":"existing","title":"Existing", "desc":"The research is being done on a product or service that has been in the market place for a while"}
    ,{"key":"new","title":"New", "desc":"The research is being done on new product or service"}
    ,{"key":"brainstorming","title":"Brainstorming", "desc":"The research is being done on product that is being researched and not on the market yet"}
 
]';

$domainStatus = getDataObjects($conn, "select * from survey_domains order by domainDefaultDisplayOrder");


$sql = "select moduleCategoryName as name
                ,moduleCategoryTitle as title
                ,moduleCategoryDesc as description
        from survey_modules_category
        where isActive = 'Y'
        and moduleCategoryName NOT in ('Objective','Screener','Feedback','Conclusion') ";

$surveyTypeStatus = getDataObjects($conn, $sql);

$q = executeQuery($conn, $sql);

$i=0;

while($cat = mysqli_fetch_object($q))
{
    $sql = "select moduleID, moduleCategory, moduleTitle from survey_modules where moduleCategory = '$cat->name'";

    $surveyTypeStatus[$i]->modules = getDataObjects($conn, $sql);

    $i++;
}




$dataOut = new stdClass();
$dataOut->productStatus = json_decode($productStatus);
$dataOut->domainStatus = $domainStatus;
$dataOut->surveyTypeStatus = $surveyTypeStatus;

///////////////////////////////////////////////////////// Send Data

$out->data = $dataOut;

header('Content-type: application/json');

echo $out->generateOutput($auth);

/////////////////////////////////////////////////////////
