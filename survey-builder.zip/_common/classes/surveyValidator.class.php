<?php
class SurveyValidator
{

    function validateSurvey($survey)
    {
        for($sectionIdx=0;$sectionIdx<sizeOf($survey->sections);$sectionIdx++)
        {
            $survey->sections[$sectionIdx] = $this->validateSection($survey->sections[$sectionIdx]);
            
        }

        return $survey;
    }

    function validateSection($section)
    {
        for($questionIdx=0;$questionIdx<sizeOf($section->questions);$questionIdx++)
        {
            $section->questions[$questionIdx] = $this->validateQuestion($section->questions[$questionIdx]);
        }

        return $section;
    }

    function validateQuestion($q)
    {
        if($q->question_type == "Yes/No")
        {
            $q->question_type = "Yes or No";
        }

        return $q;
    }
}
?>