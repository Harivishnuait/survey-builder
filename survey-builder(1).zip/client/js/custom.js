
function createPharse()
{
  let surveyName = $("#survey-name").val();
  let researchGoals = $("#research-goals").val();
  let divBrandListHTML = $("#div-brand-list").text();
  let divAttributesListHTML = $("#div-attributes-list").text();
  var error ='';      
  
  if(surveyName){
    document.getElementById("survey_name-error").style.display = "none";   
  
  }else{
    $("#survey_name-error").css("display","block");
    var error = 1;
  }
  if(researchGoals){
    document.getElementById("research-goals-error").style.display = "none";            
  }else{
    $("#research-goals-error").css("display","block");
    var error = 1;   
  }
  if(divBrandListHTML){
    document.getElementById("brand-error").style.display = "none";            
  }else{
    $("#brand-error").css("display","block");
    var error = 1;   
  }
  if(divAttributesListHTML){
    document.getElementById("attribute-error").style.display = "none";            
  }else{
    $("#attribute-error").css("display","block");
    var error = 1;   
  }
  if(error!= 1)
  {
    utils.showView("view-pharse-survey");
  }
  var selectedElement = sessionStorage.getItem('productService');
  if (selectedElement) {
      $('.col-md-4').removeClass('zoomed');
      var selectedDiv = $("#" + selectedElement).closest('.col-md-4');
      selectedDiv.addClass('zoomed');
  }

}
function createDomain()
{
  if($("#product-service-value").val()!='')
  {
    utils.showView("view-domain-survey");
    var selectedElement = sessionStorage.getItem('domain');
    if (selectedElement) {
        $('.col-md-4').removeClass('zoomed');
        var selectedDiv = $("#" + selectedElement).closest('.col-md-4');
        selectedDiv.addClass('zoomed');
    }
  }
  else{
    toastr.error("Please Select Product or Service");
  }     
}
function createSurveytype()
{
  if($("#domain-value").val()!='')
  {
    utils.showView("view-survey-type");      
    var selectedElement = sessionStorage.getItem('surveyType');
    if (selectedElement) {
      $('.col-md-4').removeClass('zoomed');
      var selectedDiv = $("#" + selectedElement).closest('.col-md-4');
      selectedDiv.addClass('zoomed');
    }
  }
  else{
    toastr.error("Please Choose Domain");
  }
 
}
function createTargetAudience()
{
  if( $("#survey-type-value").val()!='')
  {
    utils.showView("view-target-audience");
  }
  else{
    toastr.error("Please Choose Survey Type");
  }
  
}

function setProductService(fieldName)
{
  $("#product-service-value").val($("#"+fieldName).html());
  var selectedValue = $("#" + fieldName).html();
  $("#product-service-value").val(selectedValue);

 
  sessionStorage.setItem('productService', fieldName);

  $('.col-md-4').removeClass('zoomed');
  var selectedDiv = $('#' + fieldName).closest('.col-md-4');
  selectedDiv.addClass('zoomed');    
}

function setDomain(fieldName)
{
  $("#domain-value").val($("#"+fieldName).html());
  var selectedValue = $("#" + fieldName).html();
  $("#domain-value").val(selectedValue);

  sessionStorage.setItem('domain', fieldName);

  $('.col-md-4').removeClass('zoomed');
  var selectedDiv = $('#' + fieldName).closest('.col-md-4');
  selectedDiv.addClass('zoomed');    
}
function setSurveyType(fieldName)
{
  $("#survey-type-value").val($("#"+fieldName).html());
  var selectedValue = $("#" + fieldName).html();
  $("#survey-type-value").val(selectedValue);

  sessionStorage.setItem('surveyType', fieldName);

  $('.col-md-4').removeClass('zoomed');
  var selectedDiv = $('#' + fieldName).closest('.col-md-4');
  selectedDiv.addClass('zoomed');    

}

function goBackstep1()
{
  utils.showView("view-create-survey");      
}
function goBackstep2()
{
  utils.showView("view-pharse-survey");  

  var selectedElement = surveyApp.surveyParams.productService;
  if (selectedElement) {
      $('.col-md-4').removeClass('zoomed');
      var selectedDiv = $("#" + selectedElement).closest('.col-md-4');
      selectedDiv.addClass('zoomed');
  }
}
function goBackstep3()
{ 
  utils.showView("view-domain-survey"); 
  
  var selectedElement = surveyApp.surveyParams.domain;
  if (selectedElement) {
      $('.col-md-4').removeClass('zoomed');
      var selectedDiv = $("#" + selectedElement).closest('.col-md-4');
      selectedDiv.addClass('zoomed');
  }

}
function goBackstep4()
{
  utils.showView("view-survey-type");

  var selectedElement = surveyApp.surveyParams.surveyTargetType;
  if (selectedElement) {
      $('.col-md-4').removeClass('zoomed');
      var selectedDiv = $("#" + selectedElement).closest('.col-md-4');
      selectedDiv.addClass('zoomed');
  }
}
