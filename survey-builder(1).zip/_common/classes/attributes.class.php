<?php
class Attributes
{
    public $data = "";

    
    function __construct() 
    {
        $this->data = new stdClass();
        
    }

    function loadAttributes($conn, $userID, $attributesID)
    {
        
        $sql = "select * from attributes where attributesID = $attributesID and userID = $userID";
        
        $this->data = getDataObject($conn, $sql);

    }

    function createAttributes($conn, $auth, $params)
    {
       
        // Get the current user ID
        $userID = $auth->getUserID();

        // Prepare the SQL query
        $sql = "INSERT INTO survey.attributes (userID, attributesName, createdDate, modifiedDate)
                VALUES ( '$userID', '$params->attributesName', NOW(), NOW())";

        // Execute the SQL query
        executeQuery($conn, $sql);
        $attributesID = getKey($conn, "select max(attributesID) from survey.attributes where userID = " . $auth->getUserID());
        return $attributesID;

    }
    

    function getAttributesData($conn, $attributesID)
    {
        $out = new stdClass();

        $sql = "select *
        from attributes 
        where attributesID = $attributesID
        ";

        $out = getDataObject($conn, $sql);

        return $out;
    }

    function removeAttributes($conn, $userID, $attributesID)
    {
       
        $sql = "delete from attributes where attributesID = $attributesID and userID = $userID";
        
        executeQuery($conn, $sql);

    }

    function attributeDataExist($conn, $attributeName)
    {
        $out = new stdClass();

        $sql = "select *
        from attributes
        where attributesName = '$attributeName'
        ";

        $out = getDataObject($conn, $sql);

        return $out;
    }

}

 
