    <?php
    ///////////////////////////////////////////////////////// Prep
    include "_includes.php";

    require_once '../vendor/autoload.php';
    
    $out = new DataPacket();

    $auth = new Auth();

    $auth->fromSession($conn);

    $dataOut = new stdClass();

    ///////////////////////////////////////////////////////// Prep

    $surveyID = clean($conn, getVar("surveyID"));

    $survey = new Survey();

    $survey->loadFromDatabase($conn, $surveyID);

    $fileName = "survey-" . $survey->getSurveyGuid() . ".docx";
   
    ob_clean();
    $data = [];

    $headers = ["question_num","question","question_type","answers"];
    
    $data[] = $headers;

    $sections = $survey->surveyDataObj->sections;
    
    foreach ($sections as $section) {
        foreach ($section->questions as $question) {
            $row = [$question->question_num];
            $row[] = $question->question_text;
            $row[] = $question->question_type;

            if (property_exists($question, 'answers')) {
                foreach ($question->answers as $answer) {
                    $row[] = $answer->answer_text;
                    if($answer->terminate_survey) 
                    {
                        $row[] = "[TERMINATE SURVEY]";
                    }
                    //$row[] = $answer->programming_notes;
                }
            }
            $data[] = $row;
        }
    }


    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=csv_export.csv');

    $output = fopen('php://output', 'w');

    foreach ($data as $data_item) {
        fputcsv($output, $data_item);
    }

    fclose($output);
    
    ?>